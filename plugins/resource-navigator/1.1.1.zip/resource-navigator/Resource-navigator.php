<?php
/*
 * Plugin Name: Resource Navigator
 * Version: 1.1.1
 * Description: Enables Resource Navigator Forms and Functionality
 * Author: Propaganda3
 * Author URI: http://www.propaganda3.com/
 * Requires at least: 5.5
 * Tested up to: 5.8.1
 * Text Domain: slrn
 * Domain Path: /languages
 *
 */

use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;

include_once 'inc/autoload.php';
if(!function_exists('wp_redirect')) {
    require(ABSPATH . WPINC . '/pluggable.php');
}
$base = ResourceNavigatorBase::Instance();
$base->setupClasses();
//if(class_exists('ET_Builder_Module')){
//    $base->setupDiviClasses();
//}
//add_action('init', [$base, 'setupClasses'], 10);
add_action('admin_menu', [$base, 'setupSettingsClasses'], 10);
//create your rewrite rule
add_action( 'init', 'slrn_init' );
function slrn_init() {


    add_rewrite_rule('resource-navigator/responses/([a-z0-9]+)/?$', 'index.php?slrn_response=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/detail/([\d]*)/([\d]*)?$', 'index.php?slrn_id=$matches[1]&slrn_view=$matches[2]', 'top');

    add_rewrite_rule('resource-navigator/detail/(\d*)$', 'index.php?slrn_id=$matches[1]&slrn_view=0', 'top');
    add_rewrite_rule('resource-navigator/embed/detail/([\d]*)/([\d]*)?$', 'index.php?slrn_chromeless=true&slrn_id=$matches[1]&slrn_view=$matches[2]', 'top');
    add_rewrite_rule('resource-navigator/embed-event', 'index.php?slrn_event_embed=true', 'top');
    add_rewrite_rule('resource-navigator/embed-alt-event', 'index.php?slrn_event_alt_embed=true', 'top');
    add_rewrite_rule('resource-navigator/embed-webform/(\d*)$', 'index.php?slrn_webform_chromeless=true&slrn_webform_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed-profile/(\d*)$', 'index.php?slrn_profile_chromeless=true&slrn_profile_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed/(\d*)$', 'index.php?slrn_chromeless=true&slrn_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed', 'index.php?slrn_chromeless=true', 'top');
    add_rewrite_rule('resource-navigator', 'index.php?slrn', 'top');
    flush_rewrite_rules();
}

// add blackout to the whitelist of variables it wordpress knows and allows
add_filter( 'query_vars', 'slrn_query_vars' );
function slrn_query_vars( $query_vars )
{
    $query_vars[] = 'slrn_id';
    $query_vars[] = 'slrn_view';
    $query_vars[] = 'slrn_webform_chromeless';
    $query_vars[] = 'slrn_webform_view';
    $query_vars[] = 'slrn_profile_chromeless';
    $query_vars[] = 'slrn_profile_view';

    $query_vars[] = 'slrn_chromeless';
    $query_vars[] = 'slrn';
    $query_vars[] = 'slrn_event_embed';
    $query_vars[] = 'slrn_event_alt_embed';
    $query_vars[] = 'slrn_response';
    return $query_vars;
}
function slrn_no_related_posts( $options ) {
    if ( !is_singular( 'post' ) ) {
        $options['enabled'] = false;
    }
    return $options;
}
// If this is done, we can access it later
// This example checks very early in the process:
// if the variable is set, we include our page and stop execution after it
add_action( 'parse_request', 'slrn_parse_request' );
function slrn_parse_request( &$wp ){

    if ( array_key_exists( 'slrn_id', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }
        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_partner' );
    }
    if ( array_key_exists( 'slrn_response', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }
        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_response' );
    }
    if ( array_key_exists( 'slrn', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }

        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_search' );
    }
    if ( array_key_exists( 'slrn_chromeless', $wp->query_vars )) {
        if ( array_key_exists( 'slrn_id', $wp->query_vars )) {
            add_action( 'template_redirect', 'slrn_view_partner' );
        } else {
            add_action( 'template_redirect', 'slrn_chromeless' );
        }
    }
    if ( array_key_exists( 'slrn_webform_chromeless', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_webform_chromeless' );
    }
    if ( array_key_exists( 'slrn_profile_chromeless', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_profile_chromeless' );
    }
    if ( array_key_exists( 'slrn_event_embed', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_event_embed' );
    }
    if ( array_key_exists( 'slrn_event_alt_embed', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_event_alt_embed' );
    }
}
function slrn_view_partner_adjust(&$query){
    $default_page = get_option('slrn_default_page');
    if(!empty($default_page))


    if ( $query->is_main_query() ) {
        $query->set( 'p', intval($default_page) );
        $query->set('post_type', 'page');
        $query->set('is_page', 'true');
        $query->set('is_home', 'false');
        $query->set( 'post_status' , array('publish', 'draft', 'private', ));
    }
}
function slrn_view_partner(){
    remove_filter( 'the_content', 'wpautop' );
    global $wp_query;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include(dirname(__FILE__) . '/inc/sourcelink/resource-navigator/views/single-partner.php');
}
function slrn_view_response(){
    remove_filter( 'the_content', 'wpautop' );
    setup_postdata(get_option('slrn_default_page') ?? 0);
    global $wp_query;
    $wp_query->p = get_option('slrn_default_page') ?? 0;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include(dirname(__FILE__) . '/inc/sourcelink/resource-navigator/views/single-response.php');
}
function slrn_view_search(){
    remove_filter( 'the_content', 'wpautop' );
    global $wp_query;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/default-search.php'  );

}
function slrn_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/chromeless.php'  );
    exit();
}
function slrn_webform_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/webform-chromeless.php'  );
    exit();
}
function slrn_profile_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/profile-chromeless.php'  );
    exit();
}
function slrn_event_embed(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/event-chromeless.php'  );
    exit();
}
function slrn_event_alt_embed(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/event-alt-chromeless.php'  );
    exit();
}
register_deactivation_hook( __FILE__, 'slrn_deactivation' );

function slrn_deactivation() {
    wp_clear_scheduled_hook( 'slrn_cache_cron' );
}

/*
 **********
 ********** 
 ********** 
 ********** 
 */

/**
 * UPDATE CHECKING
 */


require_once(ABSPATH . 'wp-admin/includes/plugin.php');

define("PLUGIN_CHECK_TRANSIENT_EXPIRATION", 43200);
define("PLUGIN_CHECK_TRANSIENT_NAME", "wp_update_check_our_plugin");

add_filter('site_transient_update_plugins', function ($transient) {
    $check_plugin_transient = get_transient(PLUGIN_CHECK_TRANSIENT_NAME);
    $plugin_data = $check_plugin_transient ?: fetch_remote_data();

    // $plugin_data = fetch_remote_data();

    if (!$check_plugin_transient) {
        set_transient(
        PLUGIN_CHECK_TRANSIENT_NAME,
        $plugin_data,
        PLUGIN_CHECK_TRANSIENT_EXPIRATION
        );
    }

    $current_plugin_data = get_plugin_data(__FILE__);
    if (version_compare($plugin_data->new_version, $current_plugin_data["Version"], ">")) {
        $transient->response['resource-navigator/Resource-navigator.php'] = $plugin_data;
    } else {
        $transient->no_update['resource-navigator/Resource-navigator'] = $plugin_data;
    }
    
    return $transient;
});

define("PLUGIN_CHECK_ENDPOINT", "https://localhost:3000/api/resource-navigator");

function fetch_remote_data() {
  $remote_data = wp_remote_get(
    PLUGIN_CHECK_ENDPOINT,
    [
      'headers' => [
        'Accept' => 'application/json'
      ]
    ]
  );

  if (
    is_wp_error($remote_data) ||
    wp_remote_retrieve_response_code($remote_data) !== 200
  ) {
    return null;
  }

   $remote_data = json_decode($remote_data['body']);

   return (object) [
       'id'            => 'resource-navigator/Resource-navigator.php',
       'slug'          => 'resource-navigator',
       'plugin'        => 'resource-navigator/Resource-navigator.php',
       'new_version'   => $remote_data->version,
       'package'       => $remote_data->package,
       'icons'         => [],
       'banners'       => [],
       'banners_rtl'   => [],
       'tested'        => '',
       'requires_php'  => '',
       'compatibility' => new \stdClass(),
   ];
}

// surpassing localhost
add_filter('http_request_args', function ($args) {
    $args['reject_unsafe_urls'] = false;
    return $args;
});