<?php
/*
 * Plugin Name: Resource Navigator
 * Version: 1.1.0
 * Description: Enables Resource Navigator Forms and Functionality
 * Author: Propaganda3
 * Author URI: http://www.propaganda3.com/
 * Requires at least: 5.5
 * Tested up to: 5.8.1
 * Text Domain: slrn
 * Domain Path: /languages
 *
 */

use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;

include_once 'inc/autoload.php';
if(!function_exists('wp_redirect')) {
    require(ABSPATH . WPINC . '/pluggable.php');
}
$base = ResourceNavigatorBase::Instance();
$base->setupClasses();
//if(class_exists('ET_Builder_Module')){
//    $base->setupDiviClasses();
//}
//add_action('init', [$base, 'setupClasses'], 10);
add_action('admin_menu', [$base, 'setupSettingsClasses'], 10);
//create your rewrite rule
add_action( 'init', 'slrn_init' );
function slrn_init() {


    add_rewrite_rule('resource-navigator/responses/([a-z0-9]+)/?$', 'index.php?slrn_response=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/detail/([\d]*)/([\d]*)?$', 'index.php?slrn_id=$matches[1]&slrn_view=$matches[2]', 'top');

    add_rewrite_rule('resource-navigator/detail/(\d*)$', 'index.php?slrn_id=$matches[1]&slrn_view=0', 'top');
    add_rewrite_rule('resource-navigator/embed/detail/([\d]*)/([\d]*)?$', 'index.php?slrn_chromeless=true&slrn_id=$matches[1]&slrn_view=$matches[2]', 'top');
    add_rewrite_rule('resource-navigator/embed-event', 'index.php?slrn_event_embed=true', 'top');
    add_rewrite_rule('resource-navigator/embed-alt-event', 'index.php?slrn_event_alt_embed=true', 'top');
    add_rewrite_rule('resource-navigator/embed-webform/(\d*)$', 'index.php?slrn_webform_chromeless=true&slrn_webform_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed-profile/(\d*)$', 'index.php?slrn_profile_chromeless=true&slrn_profile_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed/(\d*)$', 'index.php?slrn_chromeless=true&slrn_view=$matches[1]', 'top');
    add_rewrite_rule('resource-navigator/embed', 'index.php?slrn_chromeless=true', 'top');
    add_rewrite_rule('resource-navigator', 'index.php?slrn', 'top');
    flush_rewrite_rules();
}

// add blackout to the whitelist of variables it wordpress knows and allows
add_filter( 'query_vars', 'slrn_query_vars' );
function slrn_query_vars( $query_vars )
{
    $query_vars[] = 'slrn_id';
    $query_vars[] = 'slrn_view';
    $query_vars[] = 'slrn_webform_chromeless';
    $query_vars[] = 'slrn_webform_view';
    $query_vars[] = 'slrn_profile_chromeless';
    $query_vars[] = 'slrn_profile_view';

    $query_vars[] = 'slrn_chromeless';
    $query_vars[] = 'slrn';
    $query_vars[] = 'slrn_event_embed';
    $query_vars[] = 'slrn_event_alt_embed';
    $query_vars[] = 'slrn_response';
    return $query_vars;
}
function slrn_no_related_posts( $options ) {
    if ( !is_singular( 'post' ) ) {
        $options['enabled'] = false;
    }
    return $options;
}
// If this is done, we can access it later
// This example checks very early in the process:
// if the variable is set, we include our page and stop execution after it
add_action( 'parse_request', 'slrn_parse_request' );
function slrn_parse_request( &$wp ){

    if ( array_key_exists( 'slrn_id', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }
        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_partner' );
    }
    if ( array_key_exists( 'slrn_response', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }
        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_response' );
    }
    if ( array_key_exists( 'slrn', $wp->query_vars )) {
        $default_page = get_option('slrn_default_page');
        if(!empty($default_page)){
            $wp->query_vars['p'] = get_option('slrn_default_page');
            add_action( 'pre_get_posts', 'slrn_view_partner_adjust' );
        }

        add_filter( 'jetpack_relatedposts_filter_options', 'slrn_no_related_posts' );
        add_action( 'template_redirect', 'slrn_view_search' );
    }
    if ( array_key_exists( 'slrn_chromeless', $wp->query_vars )) {
        if ( array_key_exists( 'slrn_id', $wp->query_vars )) {
            add_action( 'template_redirect', 'slrn_view_partner' );
        } else {
            add_action( 'template_redirect', 'slrn_chromeless' );
        }
    }
    if ( array_key_exists( 'slrn_webform_chromeless', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_webform_chromeless' );
    }
    if ( array_key_exists( 'slrn_profile_chromeless', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_profile_chromeless' );
    }
    if ( array_key_exists( 'slrn_event_embed', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_event_embed' );
    }
    if ( array_key_exists( 'slrn_event_alt_embed', $wp->query_vars )) {
        add_action( 'template_redirect', 'slrn_event_alt_embed' );
    }
}
function slrn_view_partner_adjust(&$query){
    $default_page = get_option('slrn_default_page');
    if(!empty($default_page))


    if ( $query->is_main_query() ) {
        $query->set( 'p', intval($default_page) );
        $query->set('post_type', 'page');
        $query->set('is_page', 'true');
        $query->set('is_home', 'false');
        $query->set( 'post_status' , array('publish', 'draft', 'private', ));
    }
}
function slrn_view_partner(){
    remove_filter( 'the_content', 'wpautop' );
    global $wp_query;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include(dirname(__FILE__) . '/inc/sourcelink/resource-navigator/views/single-partner.php');
}
function slrn_view_response(){
    remove_filter( 'the_content', 'wpautop' );
    setup_postdata(get_option('slrn_default_page') ?? 0);
    global $wp_query;
    $wp_query->p = get_option('slrn_default_page') ?? 0;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include(dirname(__FILE__) . '/inc/sourcelink/resource-navigator/views/single-response.php');
}
function slrn_view_search(){
    remove_filter( 'the_content', 'wpautop' );
    global $wp_query;
    $wp_query->is_home = false;
    $wp_query->is_page = true;
    $wp_query->is_archive = false;
    $wp_query->show_posts = false;
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/default-search.php'  );

}
function slrn_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/chromeless.php'  );
    exit();
}
function slrn_webform_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/webform-chromeless.php'  );
    exit();
}
function slrn_profile_chromeless(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/profile-chromeless.php'  );
    exit();
}
function slrn_event_embed(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/event-chromeless.php'  );
    exit();
}
function slrn_event_alt_embed(){
    include( dirname( __FILE__ ) . '/inc/sourcelink/resource-navigator/views/event-alt-chromeless.php'  );
    exit();
}
register_deactivation_hook( __FILE__, 'slrn_deactivation' );

function slrn_deactivation() {
    wp_clear_scheduled_hook( 'slrn_cache_cron' );
}


// defined( 'ABSPATH' ) || exit;

// if( ! class_exists( 'ResourceNavigatorUpdater' ) ) {

// 	class ResourceNavigatorUpdater{

// 		public $plugin_slug;
// 		public $version;
// 		public $cache_key;
// 		public $cache_allowed;

// 		public function __construct() {

// 			$this->plugin_slug = plugin_basename( __DIR__ );
// 			$this->version = '1.0';
// 			$this->cache_key = 'rn_custom_upd';
// 			$this->cache_allowed = false;

// 			add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
// 			add_filter( 'site_transient_update_plugins', array( $this, 'update' ) );
// 			add_action( 'upgrader_process_complete', array( $this, 'purge' ), 10, 2 );

// 		}

// 		public function request(){
// 			$remote = get_transient( $this->cache_key );

// 			if( false === $remote || ! $this->cache_allowed ) {

// 				$remote = wp_remote_get(
// 					'https://rudrastyh.com/wp-content/uploads/updater/info.json',
//                     // 'https://sourcelink-theme-2.local/wp-content/uploads/updater/info.json',
// 					array(
// 						'timeout' => 10,
// 						'headers' => array(
// 							'Accept' => 'application/json'
// 						)
// 					)
// 				);

// 				if(
// 					is_wp_error( $remote )
// 					|| 200 !== wp_remote_retrieve_response_code( $remote )
// 					|| empty( wp_remote_retrieve_body( $remote ) )
// 				) {
// 					return false;
// 				}

// 				set_transient( $this->cache_key, $remote, 43200 );

// 			}

// 			$remote = json_decode( wp_remote_retrieve_body( $remote ) );
// 			return $remote;

// 		}

// 		function info( $res, $action, $args ) {

// 			// do nothing if you're not getting plugin information right now
// 			if( 'plugin_information' !== $action ) {
// 				return $res;
// 			}

// 			// do nothing if it is not our plugin
// 			if( $this->plugin_slug !== $args->slug ) {
// 				return $res;
// 			}

// 			// get updates
// 			$remote = $this->request();

// 			if( ! $remote ) {
// 				return $res;
// 			}

// 			$res = new stdClass();

// 			$res->name = $remote->name;
// 			$res->slug = $remote->slug;
// 			$res->version = $remote->version;
// 			$res->tested = $remote->tested;
// 			$res->requires = $remote->requires;
// 			$res->author = $remote->author;
// 			$res->author_profile = $remote->author_profile;
// 			$res->download_link = $remote->download_url;
// 			$res->trunk = $remote->download_url;
// 			$res->requires_php = $remote->requires_php;
// 			$res->last_updated = $remote->last_updated;

// 			$res->sections = array(
// 				'description' => $remote->sections->description,
// 				'installation' => $remote->sections->installation,
// 				'changelog' => $remote->sections->changelog
// 			);

// 			if( ! empty( $remote->banners ) ) {
// 				$res->banners = array(
// 					'low' => $remote->banners->low,
// 					'high' => $remote->banners->high
// 				);
// 			}
// 			return $res;

// 		}

// 		public function update( $transient ) {

// 			if ( empty($transient->checked ) ) {
// 				return $transient;
// 			}

// 			$remote = $this->request();

// 			if(
// 				$remote
// 				&& version_compare( $this->version, $remote->version, '<' )
// 				&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<=' )
// 				&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
// 			) {
// 				$res = new stdClass();
// 				$res->slug = $this->plugin_slug;
// 				$res->plugin = plugin_basename( __FILE__ );
// 				$res->new_version = $remote->version;
// 				$res->tested = $remote->tested;
// 				$res->package = $remote->download_url;

// 				$transient->response[ $res->plugin ] = $res;
// 	    }
// 			return $transient;
// 		}

// 		public function purge( $upgrader, $options ){

// 			if (
// 				$this->cache_allowed
// 				&& 'update' === $options['action']
// 				&& 'plugin' === $options[ 'type' ]
// 			) {
// 				// just clean the cache when new plugin version is installed
// 				delete_transient( $this->cache_key );
// 			}

// 		}
// 	}
// 	new ResourceNavigatorUpdater();
// }
