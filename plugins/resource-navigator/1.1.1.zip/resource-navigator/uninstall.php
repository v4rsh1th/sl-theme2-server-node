<?php

// if uninstall.php is not called by WordPress, die
if ( ! defined('WP_UNINSTALL_PLUGIN')) {
    die;
}
//Remove options added by this plugin
delete_option('slrn_api_key');

delete_option('slrn_cached_fields');
delete_option('slrn_cached_services');
delete_option('slrn_gm_api_key');
delete_option('slrn_grc_api_key');
delete_option('slrn_grc_api_key_2');
delete_option('slrn_cached_date');
$delete = get_option('slrn_delete_data');
if ( ! empty($delete)) {
// delete custom post type posts
    $myplugin_cpt_args  = array('post_type' => array('partner_profile_form', 'resource_view'), 'posts_per_page' => -1);
    $myplugin_cpt_posts = get_posts($myplugin_cpt_args);
    foreach ($myplugin_cpt_posts as $post) {
        wp_delete_post($post->ID, false);
    }
    delete_option('slrn_delete_data');
}