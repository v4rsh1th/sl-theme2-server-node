window.ResourceNavigator.Frontend.TrackActivity = function($, w) {
    const _api_route = 'wp-json/slrn_provider/';
    const _function_route = 'send-activity';

    /**
     * Start Sevice based interractions.
     */
    const _init = function() {
        // _TrackActivity(null);
        $(function() {
            $('.slrn-container a[data-event]').on('click', function(event, options) {
                options = options || {
                    event:$(this).data('event'),
                    provider:$(this).data('provider')
                };
                _TrackActivity(event, options);
            });
        });

    };
    /**
     * AJAX Get Services
     */
    let _TrackActivity = function(e, options) {

        if(e !== null){
            e.preventDefault();
        }

        var $target = e != null ? $(e.currentTarget) : null;

        if(options.event === "" || options.provider === 0){
            console.log('Provider and Event Name are required', options.event, options.provider)
            return true;
        }
        var args = {
            id: options.provider,
            type: options.event,
            url: window.location.href,
            referral: $target ? $target.attr('href') : ''
        };
        console.log(args);
        $.ajax({
            type: 'POST',
            url: window.ResourceNavigator.Settings.getBlogUrl() + _api_route + _function_route,
            data:args,
            success: function(data) {
                console.log(data);
            }, error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR + ' :: ' + textStatus + ' :: ' + errorThrown);

            }
        }).then(function(){
            if(e !== null) {
                var windowTarget = $target.attr("target");
                if(windowTarget === "_blank"){
                    window.open($target.attr('href'));
                } else{
                    window.location.href = $target.attr('href');
                }
            }
        });

    };


    //DO INIT
    _init();
    return{
        send:_TrackActivity
    }
}(jQuery, window);