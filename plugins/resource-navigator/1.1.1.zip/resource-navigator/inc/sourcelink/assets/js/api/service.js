window.ResourceNavigator.Frontend.Service = function($, w) {
    const _api_route = 'wp-json/slrn_services/';
    const _function_route = 'get-services/';

    /**
     * Start Sevice based interractions.
     */
    const _init = function() {
        $(function() {

            $('select[name="serviceCategoryIds"]').each(function() {
                $(this).on('change', function() {
                    const serviceDropdown = $('select[name="serviceIds"]', $(this).parent().parent().parent());
                    const serviceDropdownDefault = $('option', serviceDropdown)[0];
                        serviceDropdown.empty();
                    serviceDropdown.append(serviceDropdownDefault);
                    serviceDropdown.parent().addClass('loading');
                    _FetchServicesByCategory(this);
                });

            });
        });

    };
    /**
     * AJAX Get Services
     */
    let _FetchServicesByCategory = function(elm) {
        let str = '?';
        str += 'lang=' + $(elm).data("lang");
        if (elm) {
            str += '&cat=' + $(elm).val();
        }

        return $.ajax({
            type: 'GET', dataType: 'json', url: window.ResourceNavigator.Settings.getBlogUrl() + _api_route + _function_route + str, success: function(data) {
                _change_categories(elm, JSON.parse(data));

            }, error: function(jqXHR, textStatus, errorThrown) {
                const serviceDropdown = $('select[name="serviceIds"]', $(elm).parent().parent().parent());
                serviceDropdown.parent().removeClass('loading');
                console.log(jqXHR + ' :: ' + textStatus + ' :: ' + errorThrown);
            }

        });
    };

    /**
     * Update dropdowns
     */
    let _change_categories = function(elm, data) {
        const serviceDropdown = $('select[name="serviceIds"]', $(elm).parent().parent().parent());

        if (data.items) {
            for (let x = 0; x < data.items.length; x++) {
                serviceDropdown.append('<option value="' + data.items[x].id + '">' + data.items[x].label + '</option>');
            }
        }
        serviceDropdown.parent().removeClass('loading');
    };
    //DO INIT
    _init();
    return{
        FetchServicesByCategory:_FetchServicesByCategory
    };

}(jQuery, window);