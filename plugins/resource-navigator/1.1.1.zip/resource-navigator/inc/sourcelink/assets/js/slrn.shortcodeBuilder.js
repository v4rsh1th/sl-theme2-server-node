//File Uploader Controller for managing media uploads via buttons in admin meta
window.ResourceNavigator.Admin.shortcodeBuilder = function ($, w, d) {
    let _shortcodes = {};
    let _container;
    let _modal;
    let _sc_vals = [];

    function Input(text, id, type) {
        this.text = text;
        this.id = id;
        this.type = type;
    }

    function Shortcode(name, id, inputs) {
        this.name = name;
        this.id = id;
        this.inputs = [];
        for(let inp in inputs){

            let tmp = new Input(inputs[inp].text, inputs[inp].id, inputs[inp].type);
            this.inputs.push(tmp);
        }
    }

    //boot it up
    let _init = function() {
        _container = $('<div></div>').addClass('shortcode-button-wrapper postbox').append($('<div></div>').addClass('inside').append($('<div></div>').addClass('slrn-admin-component').append('<div class="col-sm-12"><h3 class="remove-margin-top">Generate Shortcodes</h3>' +
            '<select name="select-shortcode" id="select-shortcode"><option value="">--Select Shortcode--</option></select>' +
            '</div>')));

        $('#post-body-content').append('<br>').append(_container);
        _container = $('#post-body-content .shortcode-button-wrapper .inside .slrn-admin-component');
        $('#select-shortcode', _container).on('change',_select_shortcode);
        _modal = $('<div></div>').attr('id', "sc-create-modal").append("<form></form>");
        $('body').append(_modal);
        $('#sc-create-modal form').submit(_build_shortcode);
        $('#sc-create-modal').dialog({
            title: 'Create Shortcode',
            dialogClass: 'sc-create-modal',
            autoOpen: false,
            draggable: false,
            width: '500px',
            modal: true,
            resizable: false,
            closeOnEscape: true,
            position: {
                my: "center",
                at: "center",
                of: window
            },
            open: function () {
                // close dialog by clicking the overlay behind it
                $('.ui-widget-overlay').bind('click', function(){
                    $('#my-dialog').dialog('close');
                })
            },
            create: function () {
                // style fix for WordPress admin
                $('.ui-dialog-titlebar-close').addClass('ui-button');
                $('.ui-dialog-titlebar .ui-button-text').remove();
            },
        });
    };

    //adding a shortcode
    let _add_shortcode = function(name,sc,fields){
        _shortcodes[sc] = new Shortcode(name,sc,fields);
        _create_option(_shortcodes[sc]);
    };

    //make a button for the shortcode
    let _create_option = function(sc){
        //build button elm
        let option = $('<option></option>').attr('value', sc.id).text(sc.name);

        $('#select-shortcode', _container).append(option);


    };
    let _select_shortcode = function(e){

        e.preventDefault();
        let theSC = $(e.target).val();
        if(theSC != ""){
            let sc = _shortcodes[theSC];

            //build html for modal form
            let tmp = '<div class="row"><input type="hidden" name="shortcode" value="'+sc.id+'">';
            tmp += '<div class="col-sm-12"><h4>Add ' + sc.name + '</h4></div>';
            for(let input in sc.inputs){
                let input_elm = _getElmForType(sc.inputs[input].type);
                if(input_elm !== ""){
                    input_elm = $('<'+input_elm+'/>');
                    input_elm.attr({'name':sc.inputs[input].id, 'id': sc.inputs[input].id});
                    if(sc.inputs[input].type !== "textarea"){
                        input_elm.attr('type', 'text')
                    }
                    else{
                        input_elm.addClass('tinymce-enabled');
                    }
                    if(sc.inputs[input].type === "color"){
                        input_elm.addClass('cp-spectrum');
                    }
                    if(sc.inputs[input].type === "image"){
                        input_elm.addClass('file-controller');
                    }

                    tmp+= '<div class="col-sm-12"><label>' + sc.inputs[input].text + "</label><br>";
                    tmp+= input_elm[0].outerHTML;
                    if(sc.inputs[input].type === "image"){
                        tmp+= '<button type="button" class="button update_btn">Choose Image</button></div><div class="col-sm-12">';
                    }
                    tmp+= "</div>";
                }
            }
            tmp+= '<div class="col-sm-12"><pre class="shorty"></pre></div>';
            tmp+= '<div class="col-sm-12"><a class="button button-secondary copy-shorty" data-clipboard-target=".shorty">Copy Shortcode</a></div></div>';

            //append form htmp
            $('form',_modal).html(tmp);

            //push inputs to array
            _sc_vals = [];
            $('input,textarea',_modal).each(function(){
                _sc_vals.push($(this));
            });




            //bind input keyup events
            _bindInputs();

            //open modal
            _modal.dialog('open');
            e.target.selectedIndex = 0;
        }
    };
    //bind input keyup event
    let _bindInputs = function(){
        // tinyMCE.init({
        //     mode : "specific_textareas",
        //     theme : "simple",
        //     selector :".tinymce-enabled"
        // });
        ResourceNavigator.Admin.fileLoader.bind();
        $("#sc-create-modal .cp-spectrum").spectrum({
            showPalette: false,
            showInput: true,
            showAlpha: true,
            preferredFormat: "rgb",
            appendTo: '#sc-create-modal',
            change: function(color) {
                _build_shortcode();
            }
        });

        let clipboard = new Clipboard('.copy-shorty');

        $('body').on('keyup change click', '#sc-create-modal form input, #sc-create-modal form textarea',function(){
            _build_shortcode();
        });
    };



    let _build_shortcode = function(){
        let _sc_string = "[";
        let _sc_content = "";
        let _sc_shortcode = "";
        let _sc_atts = [];
        for(let x = 0; x < _sc_vals.length; x++){

            if(_sc_vals[x].attr('name') === "content"){
                _sc_content = _sc_vals[x].val();
            }
            else if(_sc_vals[x].attr('name') === "shortcode"){
                _sc_shortcode = _sc_vals[x].val();
            }
            else{
                if(_sc_vals[x].val() !== ""){
                _sc_atts.push([_sc_vals[x].attr('name'), _sc_vals[x].val()]);
                }
            }
        }
        _sc_string += _sc_shortcode;

        for(let x = 0; x < _sc_atts.length; x++){
            _sc_string += " " + _sc_atts[x][0] + '="' + _sc_atts[x][1] + '"';
        }

        _sc_string += "]";
        if(_sc_content !== ""){
        _sc_string += "\n" + _sc_content + "\n[/"+_sc_shortcode +"]";
        }
        $('.shorty',_modal).html(_sc_string);
    };

    let _getElmForType = function(type){
        let elm = 'input';
        if (type === "textarea"){
            elm = 'textarea';
        }
        return elm;
    };



    _init();
    //Public
    return{
        add_shortcode:_add_shortcode
    }

}(jQuery, window, document);