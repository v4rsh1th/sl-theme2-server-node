//GIVE OURSELVES A DEFINED CUSTOM SCOPE TO DERP IN
window.ResourceNavigator = {Admin:{}, Frontend:{}, Settings:{}};