let currentPage = 1;
const wrappers = jQuery('.resources-control');
const totalPages = wrappers.attr('data-page-count');

const prev = '.slrn-pagination a.prev';
const next = '.slrn-pagination a.next';

jQuery(function(){
    wrappers.each(function(){
        initPagination('#' +jQuery(this).attr('id'));
    })

})

function initPagination(context){
    jQuery(prev,context).on('click', function(e){
        e.preventDefault();
        if(currentPage > 1)
        {
            previousPage(context);
        }
    })
    jQuery(next,context).on('click', function(e){
        e.preventDefault();
        if(currentPage < totalPages){
            nextPage(context)
        }
    })
    buildView(context);

    togglePrevNext(context);
}
function nextPage(context){
    currentPage = jQuery(context).attr('data-current-page');
    currentPage++;
    goToPage(currentPage, context);
}
function previousPage(context){
    currentPage = jQuery(context).attr('data-current-page');
    currentPage--;
    goToPage(currentPage, context);
}
function togglePrevNext(context){
    if(currentPage > 1){
        jQuery(prev,context).removeClass('hide');
    } else {
        jQuery(prev,context).addClass('hide');
    }
    if(currentPage < totalPages){
        jQuery(next,context).removeClass('hide');
    } else {
        jQuery(next,context).addClass('hide');
    }
}
function goToPage(i,context){
    //console.log(i);
    const pages = jQuery('.slrn_results-listing .page', context);
    const targetElm = jQuery('.slrn_results-listing .page[data-page="' + i + '"]', context);
    pages.removeClass("active");
    targetElm.addClass("active");
    jQuery(context).attr('data-current-page', i);
    buildView(context);
    togglePrevNext(context);

}
function buildView(context){

    var minTruncate = 5

    const view = [];
    if(totalPages > minTruncate) {

        var startCount = (currentPage == 1 ? 1 : currentPage -1)
        console.log(startCount)
        if(startCount > totalPages - minTruncate) {
            startCount = totalPages - minTruncate
        }

        for (let x = startCount; x <= totalPages; x++){
            if(view.length <= minTruncate) {
                view.push(x);
            }
        }

        if(startCount < totalPages - (minTruncate + 1)) {
            view.push('...');
        }
        if(startCount < totalPages - minTruncate ) {
            view.push(totalPages);
        }




        // let addedFirstSpacer = false;
        // let addedSecondSpacer = false;
        // for (let x = 1; x <= totalPages; x++){
        //     if(x < 3){
        //         view.push(x);
        //     } else if(x === 3 && currentPage === 3){
        //         view.push(x);
        //     } else if(x === currentPage && currentPage > 3 && !addedFirstSpacer){
        //         view.push('...');
        //         view.push(x);
        //         addedFirstSpacer = true;
        //         if(currentPage < totalPages - 2){
        //             view.push('...');
        //             addedSecondSpacer = true;
        //         }
        //     }  else if((x === currentPage) && x === totalPages - 2){
        //         view.push(x);
        //         addedSecondSpacer = true;
        //     } else if(x > totalPages - 2){
        //         if(!addedSecondSpacer && !addedFirstSpacer){
        //             view.push('...');
        //             addedFirstSpacer = true;
        //             addedSecondSpacer = true;
        //         }
        //         view.push(x);
        //     }
        // }
    } else {
        //console.log(totalPages);
        let count = 1;
        while (count <= totalPages){
            view.push(count);
            count++;
        }
    }
    let str = '';
    for(let v = 0; v < view.length; v++){
        if(view[v] === currentPage){
            str += '<span class="page active">'+view[v]+'</span>';
        }
        else{
            if(isNaN(view[v])){
                str += '<span class="page spacer">'+view[v]+'</span>';
            }
            else{
                str += '<a href="#" class="page active" data-page="'+view[v]+'">'+view[v]+'</a>';
            }
        }
    }
    jQuery('.slrn-pagination-numbers',context).html(str);
    BindPagination(context);
}
function BindPagination(context){
    const items = jQuery('.slrn-pagination-numbers a', context);
    items.on('click', function(e){
        e.preventDefault();
        const targetNum = parseInt(jQuery(this).attr('data-page'));
        currentPage = targetNum;
        goToPage(targetNum, context);
    });
}