window.ResourceNavigator.Service = function($, w) {
    const _api_route = 'wp-json/slrn_services/';
    const _function_route = 'get-services/';

    /**
     * Start Sevice based interractions.
     */
    const _init = function() {
        $(function() {
            if ($('select[name="resource_view_area_of_assistance"]').data('value') !== '') {
                _FetchServicesByCategory('select[name="resource_view_area_of_assistance"]');
            }
            $(document).on('change', 'select[name="resource_view_area_of_assistance"]', function() {
                console.log($(this).val());
                const serviceDropdown = $('select[name="resource_view_specific_need"]');

                serviceDropdown.empty();
                if ($(this).val() == '') {
                    serviceDropdown.append('<option value="">&mdash; Choose Area of Assistance &mdash;</option>');
                }
                else {
                    serviceDropdown.append('<option value="">&mdash; Choose Default &mdash;</option>');
                    serviceDropdown.parent().addClass('loading');
                    _FetchServicesByCategory(this);
                }
            });

            if ($('select[name="resource_view_specific_need"]').data('value') !== '') {
                $('select[name="resource_view_specific_need"]').val($(this).data('value'));
            }
        });

    };

    /**
     * AJAX Get Services
     */
    let _FetchServicesByCategory = function(elm) {
        let str = '';
        if ($(elm).length>0) {
            if($(elm).val() == "") return '';
            str = '?cat=' + $(elm).val();
        }

        return $.ajax({
            type: 'GET', dataType: 'json', url: window.ResourceNavigator.Settings.getBlogUrl() + _api_route + _function_route + str, success: function(data) {
                _change_categories(elm, JSON.parse(data));

            }, error: function(jqXHR, textStatus, errorThrown) {
                const serviceDropdown = $('select[name="resource_view_specific_need"]');
                serviceDropdown.parent().removeClass('loading');
                console.log(jqXHR + ' :: ' + textStatus + ' :: ' + errorThrown);
            }

        });
    };

    /**
     * Update dropdowns
     */
    let _change_categories = function(elm, data) {
        const serviceDropdown = $('select[name="resource_view_specific_need"]');
        let _default = '';
        if(serviceDropdown.data('value') != "")
        {
            _default = serviceDropdown.data('value');
        }
        if (data.items) {
            for (let x = 0; x < data.items.length; x++) {
                serviceDropdown.append('<option value="' + data.items[x].id + '" '+ (data.items[x].id == _default ? 'selected="selected"' : '' ) +'>' + data.items[x].label + '</option>');
            }
        }
        serviceDropdown.parent().removeClass('loading');
    };
    //DO INIT
    _init();
    return{
        FetchServicesByCategory:_FetchServicesByCategory
    };

}(jQuery, window);