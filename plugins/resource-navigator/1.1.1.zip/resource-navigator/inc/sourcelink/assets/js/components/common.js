window.ResourceNavigator.Admin.removeBox = function(e){
    let r = confirm("Are you sure you want to delete this block?");
    if (r === true)  jQuery(e).remove();
};

