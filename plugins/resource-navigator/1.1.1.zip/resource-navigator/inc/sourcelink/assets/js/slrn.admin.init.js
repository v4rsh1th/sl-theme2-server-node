//ON LOAD DO BINDINGS
jQuery(document).ready(function($) {
    //INITS
    window.ResourceNavigator.Admin.fileLoader.bind();
    window.ResourceNavigator.Admin.textareaLinks.bind();
    window.ResourceNavigator.Admin.repeaters.init();

    //FIX MODAL OVER CONTENT MODAL
    jQuery.widget( "ui.dialog", jQuery.ui.dialog, {
        _allowInteraction: function( event ) {
            return !!jQuery( event.target ).closest( ".wp-core-ui" ).length || this._super( event );
        }
    });
});