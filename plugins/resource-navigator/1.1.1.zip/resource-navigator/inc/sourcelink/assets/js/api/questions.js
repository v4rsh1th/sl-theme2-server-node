window.ResourceNavigator.Questions = function($, w) {
    const _api_route = 'wp-json/slrn_web_form/';
    const _function_route = 'get-question-info';

    /**
     * Start Sevice based interractions.
     */
    const _init = function() {
                $(document).on('input', 'div.api-question-wrapper select', function(e) {

                    _FetchAnswersForQuestion(e.currentTarget);
                });

    };
    /**
     * AJAX Get Services
     */
    let _FetchAnswersForQuestion = function(elm) {
        let str = '';
        if (elm) {
            str = '?id=' + $('div.api-question-wrapper').eq(0).data('post-id') + '&question=' + $(elm).val();
        }
        return $.ajax({
            type: 'GET', dataType: 'json', url: window.ResourceNavigator.Settings.getBlogUrl() + _api_route + _function_route + str,
            success: function(data) {
                let obj = JSON.parse(data);
                $(elm).parent().parent().parent().find('.api-answer-wrapper p').html(_createInput(elm,obj));

                window.ResourceNavigator.Admin.multiSelects.bind();
            }, error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR + ' :: ' + textStatus + ' :: ' + errorThrown);
            }

        });
    };

    let _createInput = function(elm,obj){
        let rtn = null;

        let name = $(elm).attr('name') + '_answer';
        if(name.indexOf("[]") > -1){
            name = name.replace('[]', '') + '[]';
        }
        let id = $(elm).attr('id') + '_answer';
        switch(obj.type){
            case "checkbox":
            case "radio":
            case "select":
                let multi_name =  name.replace('[]', '_multi') + '[]';
                let multi_id =  id + '_multi';
                rtn = '<select name="'+multi_name+'" id="'+multi_id+'" multiple data-repeater="true">';
                for(let x = 0; x < obj.values.length; x++){
                    rtn += '<option value="'+obj.values[x].value+'">'+obj.values[x].label+'</option>';
                }
                rtn += '</select>'
                rtn += '<input type="hidden" name="'+name+'" id="'+id+'">'
                break;
            case "textarea":
                rtn = '<textarea name="'+name+'" id="'+id+'"></textarea>'
                break;
            default:
                rtn = '<input type="text" name="'+name+'" id="'+id+'" />'
                break;
        }
        return rtn;
    };



    //DO INIT
    _init();
     return{
    };

}(jQuery, window);