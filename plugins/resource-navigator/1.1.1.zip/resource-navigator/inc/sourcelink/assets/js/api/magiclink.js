window.ResourceNavigator.Frontend.MagicLink = function($, w) {
    const _api_route = 'wp-json/slrn_magic_link/';
    const _request_function_route = 'request-magic-link/';

    /**
     * Start Sevice based interractions.
     */
    const _init = function() {
        $(function() {
            $('.btn-send-magic-link').on('click', _RequestMagicLink);
        });

    };
    /**
     * AJAX Get Services
     */
    let _RequestMagicLink = function(evt) {
        evt.preventDefault();
        let str = '';
        const elm = $(evt.currentTarget);

        const l = document.location.pathname.split('/');
        l.pop();
            console.log(document.location.origin + l.join('/'));
            str = '?url=' + $(elm).data('url') + '&pid=' + $(elm).data('pid');

            // return $.ajax({
            //     type: 'GET', dataType: 'json', url: window.ResourceNavigator.Settings.getBlogUrl() + _api_route + _request_function_route + str, success: function(data) {
            //
            //
            //     }, error: function(jqXHR, textStatus, errorThrown) {
            //         var serviceDropdown = $('select[name="serviceIds"]', $(elm).parent().parent().parent());
            //         serviceDropdown.parent().removeClass('loading');
            //         console.log(jqXHR + ' :: ' + textStatus + ' :: ' + errorThrown);
            //     }
            //
            // });
    };


    //DO INIT
    _init();

}(jQuery, window);