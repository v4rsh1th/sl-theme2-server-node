jQuery(function ($) {
    $('.slrn-container .table td').on('click', function (event) {
        if (!$(event.target).is('input')) {
            const obj = $(this).find('input');
            if(!$(obj).attr('readOnly')){

                obj.click();

            }

        }
    });
    $('.slrn-container .table td input[readonly]').on('click', function (event) {
        event.preventDefault();
    });
    $('.slrn-container .table .col-spec input').on('change', function (e) {
       if($(this).is(':checked')) {
           $(this).parent().prev().find('input').prop('checked', true);
       }
    });
    $('.slrn-container .table .col-supp input').on('change', function (e) {
        if(!$(this).is(':checked')) {
            $(this).parent().next().find('input').prop('checked', false);
        }
    });
});
function getCookie(cname) {
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
