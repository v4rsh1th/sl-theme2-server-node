window.ResourceNavigator.Admin.repeaters = function ($, imageLoader, textareaLinks){
    let _all_repeaters = [];
    let _index = [];

    //TOGGLER - UNIQUE TO EACH COLLAPSER... NONE OF THESE ARE WORDS
    let _collapser = function(elem){
        let _this = jQuery(elem);
        console.log(jQuery(_this).is('checked'),elem, '#'+ _this.attr('id') +'', '[data-group='+ _this.attr('id') +']');
        if(jQuery(_this).is(':checked')){
            jQuery('[data-group='+ _this.attr('id') +']').show();
        } else {
            jQuery('[data-group='+ _this.attr('id') +']').hide();
        }
    }
    let _doStuff = function( m_prefix, m_repeater, m_dupes) {
        let idx = ($('.panel', $('.'+m_dupes)).length + 1);
        let clone = $('.master-block', m_repeater).clone();
        clone.removeClass('master-block').removeClass('hidden');
        $('.slrn-admin-component', clone).addClass('panel panel-default')
        $('input,textarea,select', clone).each(function() {
            $(this).attr('id', ($(this).attr('id') + '_' + idx ) );
        });
        $('.panel-heading', clone).attr('id', '#'+m_prefix + '_collapse_heading_' + idx);
        $('.panel-heading .title', clone).attr('data-parent', '#'+m_dupes).attr('data-target', '#'+m_prefix + '_collapse_' + idx).attr('aria-controls', m_prefix + '_collapse_' + idx).text('New');
        $('.panel-collapse', clone).attr('id', m_prefix + '_collapse_' + idx).attr('aria-labelledby', m_prefix + '_collapse_heading_' + idx);

        let textarea_content_id = $(this).attr('id') + '_' + idx ;
        $('[data-content-id]', clone).each(function() {
            let newData = $(this).data('content-id')+ '_' + idx;
            $(this).attr('data-content-id', newData );
        });
        $('[data-group]', clone).each(function() {
            let newData = $(this).data('group')+ '_' + idx;
            $(this).attr('data-group', newData );
            $('[data-content-area]', clone).each(function() {
                $(this).attr('data-content-area', newData );
            });
        });

        $('.collapser-toggle',m_repeater).on('change', function() {
            _collapser(this);
        });

        $('.dupes', m_repeater).append(clone.html());

        imageLoader.bind();
        $('.dupes', m_repeater).sortable({handle:'.handle'});
        textareaLinks.bind();
        return idx;
    };
    let _init = function()
    {
        let me = this;
        _all_repeaters = $('.repeater-blocks');

        _all_repeaters.each(function() {
            let m_repeater = $(this);
            let m_prefix = $(this).data('prefix');
            let m_dupes = m_prefix+'_dupes';
            $('.add-more',m_repeater).click(function() {
                me.doStuff( m_prefix, m_repeater, m_dupes);
            });

            if($('.panel', m_repeater).length === 0) {
                me.doStuff( m_prefix, m_repeater, m_dupes);
            }
            $('.dupes', m_repeater).attr('id', m_dupes).addClass(m_dupes);

            $('.dupes', m_repeater).sortable({handle:'.handle'});
        });
        $('.collapser-toggle').on('change', function() {
            _collapser(this);
        });
        $('.is-condition').on('change', function() {
            $('[data-condition]').each(function(){
                var conditions = $(this).data('condition');
                conditions = JSON.parse(conditions);
                for(var x = 0; x < conditions.length; x++){
                    console.log(conditions[x]);
                }
            });
        });
    };
    return {
        doStuff:_doStuff,
        init:_init
    }
}(jQuery, window.ResourceNavigator.Admin.fileLoader, window.ResourceNavigator.Admin.textareaLinks);