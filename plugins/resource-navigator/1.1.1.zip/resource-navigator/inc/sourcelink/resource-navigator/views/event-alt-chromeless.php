<?php
global $wp_query;
global $wpdb;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;


$validOpts = [
    'design' => 'string',
    'fgthumb' => 'string',
    'bgthumb' => 'string',
    'eventbg' => 'string',
    'eventfg' => 'string',
    'eventborder' => 'string',
    'titlesize' => 'string',
    'button' => 'string',
    'buttonlink' => 'string',
    'buttonbg' => 'string',
    'buttonfg' => 'string',
    'startdate' => 'string',
    'fromdate' => 'string',
    'topdate' => 'string',
    'first_day_of_week' => 'int',
    'filterbar' => 'bool',
    'filterorder' => 'string',
    'filterbar-category-title' => 'string',
    'filterbar-fromdate-title' => 'string',
    'filterbar-venue-title' => 'string',
    'filterbar-tag-title' => 'string',
    'day' => 'string',
    'days' => 'int',
    'month' => 'string',
    'year' => 'string',
    'futureonly' => 'bool',
    'hide_finished' => 'bool',
    'include_in_progress' => 'bool',
    'limit' => 'int',
    'offset' => 'int',
    'pagination' => 'bool',
    'cat' => 'string',
    'exclude_cat' => 'string',
    'tag_cat_operator' => 'string',
    'tag' => 'string',
    'exclude_tag' => 'string',
    'author_id' => 'int',
    'key' => 'string',
    'featured_only' => 'bool',
    'exclude_featured' => 'bool',
    'past' => 'bool',
    'hide_soldout' => 'bool',
    'show_hidden' => 'bool',
    'hiderecurring' => 'bool',
    'id' => 'int',
    'exclude_id' => 'string',
    'series_id' => 'string',
    'parent_id' => 'string',
    'order' => 'string',
    'orderby' => 'string',
    'eventdetails' => 'bool',
    'thumb' => 'bool',
    'excerpt' => 'string',
    'raw_excerpt' => 'bool',
    'venue' => 'bool',
    'venue_id' => 'string',
    'organizer_id' => 'string',
    'timeonly' => 'bool',
    'description' => 'bool',
    'raw_description' => 'bool',
    'thumbsize' => 'string',
    'thumbwidth' => 'int',
    'thumbheight' => 'int',
    'message' => 'string',
    'cost' => 'bool',
    'viewall' => 'bool',
    'contentorder' => 'string',
    'city' => 'string',
    'state' => 'string',
    'country' => 'string',
    '_ecp_custom_1' => 'string',
    '_ecp_custom_2' => 'string',
    '_ecp_custom_3' => 'string',
    '_ecp_custom_4' => 'string',
    '_ecp_custom_5' => 'string',
    'ecp_operator' => 'string',
];

$shortcodeArgs = [];
foreach($validOpts as $key=>$opt) {
    if(!empty($_GET[$key])) {
        if($opt == 'string') {
            $shortcodeArgs[$key] = htmlspecialchars($_GET[$key]);
        } else if($opt == 'bool' && in_array($_GET[$key], ['true', 'false']) ) {
            $shortcodeArgs[$key] = $_GET[$key];
        } else if ($opt == 'int') {
            $shortcodeArgs[$key] = preg_replace('/[^0-9]/', '', $_GET[$key]);
        } else if (is_array($opt) && in_array($_GET[$key], $opt) ) {
            $shortcodeArgs[$key] = $_GET[$key];
        }
    }
}
$sortcodeArgs = http_build_query($shortcodeArgs, '', ' ');


print '<!DOCTYPE html><html lang="en-US">';
print '<head>';
print '<title></title>';
wp_head();

print '</head>';
print '<body>';
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BODY
/// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
print  apply_filters( 'the_content', "[ecs-list-events {$sortcodeArgs}]" );
wp_footer();
print '<script type="text/javascript" defer src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/iframeResizer.contentWindow.min.js').'"></script>';

print '</body>';
print '</html>';
exit();



