<?php
global $wp_query;
global $wpdb;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;


$validOpts = [
    'view' => [
        'month',
        'list',
        'day',
        'photo',
        'week',
        'map',
        'summary',
    ],
    'category' => 'string',
    'exclude-category' => 'string',
    'featured' => 'bool',
    'tribe-bar' => 'bool',
    'keyword' => 'string',
    'tag' => 'string',
    'exclude-tag' => 'string',
    'tax-operand' => [
        'AND',
        'OR'
    ],
    'author' => 'string',
    'venue' => 'string',
    'organizer' => 'string',
    'month_events_per_day' => 'int',
    'events_per_page' => 'int',
];

$shortcodeArgs = [];
foreach($validOpts as $key=>$opt) {
    if(!empty($_GET[$key])) {
        if($opt == 'string') {
            $shortcodeArgs[$key] = htmlspecialchars($_GET[$key]);
        } else if($opt == 'bool' && in_array($_GET[$key], ['true', 'false']) ) {
            $shortcodeArgs[$key] = $_GET[$key];
        } else if ($opt == 'int') {
            $shortcodeArgs[$key] = preg_replace('/[^0-9]/', '', $_GET[$key]);
        } else if (is_array($opt) && in_array($_GET[$key], $opt) ) {
            $shortcodeArgs[$key] = $_GET[$key];
        }
    }
}
$sortcodeArgs = http_build_query($shortcodeArgs, '', ' ');


print '<!DOCTYPE html><html lang="en-US">';
print '<head>';
print '<title></title>';
wp_head();

print '</head>';
print '<body>';
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// BODY
/// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
print  apply_filters( 'the_content', "[tribe_events {$sortcodeArgs}]" );
wp_footer();
print '<script type="text/javascript" defer src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/iframeResizer.contentWindow.min.js').'"></script>';

print '</body>';
print '</html>';
exit();



