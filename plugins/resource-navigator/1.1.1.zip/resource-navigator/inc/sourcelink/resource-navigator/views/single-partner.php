<?php
global $wp_query;
global $wpdb;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;

if (empty(get_option('slrn_api_key'))) {
    wp_redirect(get_page_by_path('/'));
}
$login = new Login(get_option('slrn_api_key'));
if (empty($_COOKIE['slrn_session'])) {
    $loginResult = $login->DoLogin();
    if ((isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)) {
        wp_redirect(get_page_by_path('/'));
    }
}
global $post;
$providerApi = new Provider(get_option('slrn_api_key'));
$userOrgApi  = new \Sourcelink\ResourceNavigator\API\UserOrg(get_option('slrn_api_key'));
$providerID  = intval(get_query_var('slrn_id'));
$viewID      = intval(get_query_var('slrn_view'));
$chromeless  = get_query_var('slrn_chromeless');

if ($viewID === 0) {
    $results = $wpdb->get_results("select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'resource_view_default_view'", ARRAY_A);
    $viewID  = $results[0]['post_id'];
}
$view    = get_post($viewID);
$results = $providerApi->GetProviderById($providerID);

//post.meta.hide_optional_services


$data = json_decode($results["body"], true);

//$data = $data["result"]; //used to work, API changed
$data = $data["result"][0];


$data['view'] = ResourceNavigatorUtilityBase::GetPostProperties($view, 'Sourcelink\ResourceNavigator\Post\ResourceViewPost');
//Send magic link
$data['slrn_id']  = $providerID;
$user_org_result  = $userOrgApi->GetMyUserOrg();
$user_org_data    = json_decode($user_org_result["body"], true);
$user_org_data    = $user_org_data["result"];
$data['user_org'] = $user_org_data;
if (isset($_GET['magic_link'])) {
    $url        = ! empty($data['view']['meta']['partner_update']) ? $data['view']['meta']['partner_update'] . '?provider=' . $providerID : get_option('siteurl') . '/resource-navigator/detail/' . $providerID . '/' . $viewID . '/';
    $sendResult = $providerApi->SendMagicLink(['providerDetailUrl' => get_option('siteurl') . '/resource-navigator/detail/' . $providerID . '/' . $viewID . '/', 'providerLoginUrl' => $url, 'providerId' => $data['ProviderID']]);


    if ( ! empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif ( ! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    $protocol     = (( ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url          = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $trackingArgs = [
        'clientId'     => $providerID,
        'activityType' => 'Send Magic Link Click',
        'activityUrl'  => $url,
        'referralUrl'  => '',
        'ip'           => $ip
    ];

    $trackingResults = $providerApi->SaveNavigatorActivity($trackingArgs);


    $sendBody = json_decode($sendResult["body"], true);
    if ($sendBody['isError'] === false || $sendBody['IsError'] === false) {
        $data['magic_link_status']  = 200;
        $data['magic_link_message'] = 'Magic Link Sent! Please check your email.';
    }
    else if ($sendBody['isError'] === true && $sendBody['Title'] === "Link has already been emailed" || $sendBody['IsError'] === true && $sendBody['Title'] === "Link has already been emailed") {
        $data['magic_link_status']  = 200;
        $data['magic_link_message'] = 'Magic Link has already been Sent! Please check your email.';
    }
    else {
        $data['magic_link_status']  = 500;
        $data['magic_link_message'] = 'Magic Link could not be sent. Something went wrong.';
    }
}
if (isset($_POST['slrn-submit-wf']) && ! empty(filter_var($_POST['slrn-submit-wf'], FILTER_SANITIZE_NUMBER_INT))) {

    $data['wf_id'] = filter_var($_POST['slrn-submit-wf'], FILTER_SANITIZE_NUMBER_INT);

}
global $wpdb;
$update_form = $wpdb->get_results("select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'partner_profile_form_default_update'", ARRAY_A);
//Authenticate magic link
if (isset($_GET['publicToken']) && isset($_GET['jwtToken'])) {
    if (filter_var($_GET['publicToken'], FILTER_SANITIZE_URL) != '' && filter_var($_GET['jwtToken'], FILTER_SANITIZE_URL) != '') {
        $tokens = ['jwtToken' => filter_var($_GET['jwtToken'], FILTER_SANITIZE_URL), 'publicToken' => filter_var($_GET['publicToken'], FILTER_SANITIZE_URL)];

        $sendResult = $login->AuthenticateMagicLink(['jwtToken' => filter_var($_GET['jwtToken'], FILTER_SANITIZE_URL), 'publicToken' => filter_var($_GET['publicToken'], FILTER_SANITIZE_URL)]);
        $sendBody   = json_decode($sendResult["body"], true);

        if (count($sendBody['result']) > 1) {
            foreach ($sendBody['result'] as $magic_provider) {
                $data['form_choices'][] = [
                    'ProviderID'    => $magic_provider['ProviderID'],
                    'ProviderName'  => $magic_provider['ProviderName'],
                    'provider_form' => PartnerProfileFormPost::Render(['id' => $update_form[0]['post_id'], 'providerId' => $magic_provider['ProviderID'], 'isMagicLink' => true]),
                ];
                sleep(1);
            }

            $data['magic_link_login']  = true;
            $data['magic_link_select'] = true;
        } else {
            if (isset($sendBody['result'][0]['ProviderID']) && $sendBody['result'][0]['ProviderID'] === $providerID) {

                $data['provider_form']    = PartnerProfileFormPost::Render(['id' => $update_form[0]['post_id'], 'providerId' => $providerID, 'isMagicLink' => true]);
                $data['magic_link_login'] = true;
            }
        }
    }
}
$form_args = [
    'providerName'     => $data['ProviderName'],
    'contactFirstName' => $data['ContactFirstName'],
    'contactLastName'  => $data['ContactLastName'],
];

$data['contact_form']     = \Sourcelink\ResourceNavigator\Post\WebFormPost::RenderProviderContact($providerID, $form_args);
$data['contact_form_id']  = \Sourcelink\ResourceNavigator\Post\WebFormPost::GetProviderContactFormID();
$data['feedback_form']    = \Sourcelink\ResourceNavigator\Post\WebFormPost::RenderProviderFeedback($providerID, $form_args);
$data['feedback_form_id'] = \Sourcelink\ResourceNavigator\Post\WebFormPost::GetProviderFeedbackFormID();


$data['LongDescription'] = html_entity_decode($data['LongDescription']);
$data['chromeless']      = ! empty($chromeless);
//if ( ! $data['chromeless']) {
//    ob_start();
//    get_header();
//    $header = ob_get_clean();
//    $header = do_shortcode(preg_replace('#<title>(.*?)<\/title>#', '<title>' . $data['ProviderName'] . ' - Resource Navigator - ' . get_bloginfo('name') . '</title>', $header));
//    echo $header;
//}
if ($data['chromeless']) {
    print '<!DOCTYPE html><html lang="en-US">';
    print '<head>';
    print '<title></title>';
    print '<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/pristine.min.js') . '"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/frontend/common.js') . '"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/datepicker-full.min.js') . '"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/slrn.admin.base.js') . '"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/slrn.settings.js') . '"></script>';
    print '<script>window.ResourceNavigator.Settings.setBlogUrl("' . get_bloginfo("url") . '/");</script>';
    $url_in_use = "https://api.joinsourcelink.com/api/";
    if ( ! empty(get_option('slrn_use_staging'))) {
        $url_in_use = 'https://apitest.joinsourcelink.com/api/';
    }
    print '<script>window.ResourceNavigator.Settings.setAPIUrl("' . $url_in_use . '");</script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/api/service.js') . '"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/api/track-activity.js') . '"></script>';
    print '<script src="//polyfill.io/v3/polyfill.min.js?features=default"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/bootstrap4.min.js') . '"></script>';

    print '<link type="text/css" rel="stylesheet" href="' . ResourceNavigatorUtilityBase::GetAsset('css/libs/datepicker.min.css') . '">';
    print '<link type="text/css" rel="stylesheet" href="' . ResourceNavigatorUtilityBase::GetAsset('css/frontend-style.min.css') . '">';

    print '<script src="//maps.googleapis.com/maps/api/js?key=' . get_option('slrn_gm_api_key') . '&callback=initMap&libraries=&v=weekly" defer></script>';


    print '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">';
    print '<link type="text/css" rel="stylesheet" href="' . get_bloginfo('url') . '/wp-content/plugins/resource-navigator/inc/sourcelink/assets/css/frontend-style.min.css">';
    print '</head>';
    print '<body>';
    print (TwigManager::Twig()->Render('provider/single.twig', $data));
    print '';
    print '<script type="text/javascript" defer src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/iframeResizer.contentWindow.min.js') . '"></script>';

    print '</body>';
    print '</html>';
    exit();
} else {

    if ($view) {

        $hide_optional_services = $wpdb->get_var("select meta_value from {$wpdb->prefix}postmeta where post_id = '{$view->ID}' AND meta_key = 'resource_view_hide_optional_services'");

        if ( ! empty($hide_optional_services)) {
            unset($data['Services']);
        }
    }


    $post->post_title   = $data['ProviderName'];
    $post->post_content = TwigManager::Twig()->Render('provider/single.twig', $data);
}
$scripts = [];
if ( ! empty($results['Services'])) {
    usort($results['Services'], function ($a, $b) {
        return ($a['ServiceCategoryID'] <=> $b['ServiceCategoryID']);
    });
}
$scripts['slrn-google-maps-polyfill'] = [
    'type'   => 'script',
    'src'    => '//polyfill.io/v3/polyfill.min.js?features=default',
    'deps'   => [],
    'footer' => true,
    'ver'    => ResourceNavigatorBase::GetCacheVersion(),
];
$scripts['slrn-google-maps']          = [
    'type'   => 'script',
    'src'    => '//maps.googleapis.com/maps/api/js?key=' . get_option('slrn_gm_api_key') . '&callback=initMap&libraries=&v=weekly',
    'deps'   => ['slrn-google-maps-polyfill'],
    'footer' => true,
    'ver'    => ResourceNavigatorBase::GetCacheVersion(),
];
$scripts['slrn-bootstrap-js']         = [
    'type'   => 'script',
    'src'    => ResourceNavigatorUtilityBase::GetAsset('js/libs/bootstrap.min.js'),
    'deps'   => ['jquery'],
    'footer' => true,
    'ver'    => ResourceNavigatorBase::GetCacheVersion(),
];
ResourceNavigatorUtilityBase::EnqueueAdditional($scripts);

