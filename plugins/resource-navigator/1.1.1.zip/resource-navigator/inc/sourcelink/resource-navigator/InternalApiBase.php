<?php
/*
 * @desctiption :
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator;

use WP_Error;

class InternalApiBase
{
    protected $namespace;

    public function __construct()
    {
        $class           = get_called_class();
        $this->namespace = '/' . $class::MachineName() . '/v1';
    }

    /**
     * Default initiation call. All classes in WPO engine use ::Bootstrap to set the initial hooks and filters for that
     * class. Register will handle instance specific hooks and filters while this class handles global default registrations
     *
     * @param mixed $input Ignored by the engine, but required to Bootstrap.
     *
     * @return mixed $customPost
     */
    public static function Bootstrap($input = '')
    {
        $class      = get_called_class();
        $customPost = new $class();
        $customPost->Register($input);

        return $customPost;
    }

    /**
     * Name in the wordprss DB for object
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'endpoint';
    }

    // Register all of the post lifecycle callbacks inside wordpress.
    public function Register()
    {
        $this->register_routes();
    }

    /**
     * Instances will override this function to return a structured array of inputs used to establish the endpoint.
     *
     * @return array
     */
    public function RouteArray()
    {
        return [];
    }

    public function register_routes()
    {
        $class = get_called_class();

        foreach ($this->RouteArray() as $route) {
            $endpoint = $route['endpoint'];
            unset($route['endpoint']);

            add_action(
                'rest_api_init',
                function () use ($class, $endpoint, $route) {
                    register_rest_route($class::MachineName(), '/' . $endpoint, $route);
                }
            );
        }
    }

    /**
     * Check permissions for the posts. This is the default check, but this function can be overridden with current_user_can
     * specific to write / admin permission. This can be used to make sure api endpoints are only available to logged in
     * users or admins.
     *
     * @param object $request Current request.
     *
     * @return WP_Error|bool
     */
    public function get_items_permissions_check(object $request)
    {
        if ( ! current_user_can('read')) {
            return new WP_Error('rest_forbidden', esc_html__('You cannot view the post resource.'), array('status' => $this->authorization_status_code()));
        }

        return true;
    }

    /**
     * Sets up the proper HTTP status code for authorization.
     *
     * @return int: $status
     */
    public function authorization_status_code()
    {
        $status = 401;
        if (is_user_logged_in()) {
            $status = 403;
        }

        return $status;
    }

}
