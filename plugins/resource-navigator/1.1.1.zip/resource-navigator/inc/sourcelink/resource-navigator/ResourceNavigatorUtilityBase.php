<?php

namespace Sourcelink\ResourceNavigator;

use DateTime;
use Sourcelink\ResourceNavigator\API\DemographicFilter;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Service;
use Sourcelink\ResourceNavigator\API\ServiceCategories;
use WP_Post;
use WP_Term;

class ResourceNavigatorUtilityBase
{


    /**
     * Default master blog is always 1 in wordpress.
     * This is used to toggle between base site and sub-sites in wpmu instances.
     */
    public function __construct()
    {
    }

    /**
     * Hook into wordpress lifecycle and inject scripts and functionality
     * all shortcodes should live in the shortcode object
     */
    public static function Bootstrap()
    {
    }

    /**
     *
     */
    public static function IsDev()
    {
        return preg_match("/(dev.propaganda)/", $_SERVER['HTTP_HOST']);
    }


    /**
     *
     * Determine the correct variant with machine name, type, extension and layout.
     *
     *
     * @param string $machine_name Pulled from object you're trying to find asset for
     * @param string $type Type of object you're trying to find. [block, meta, post, inline-single, single]
     * @param string $extension
     * @param string $variant
     *
     * @return string Full path to asset
     */
    public static function FindVariant(string $machine_name, string $type, string $extension = 'twig', string $variant = ''): string
    {
        $rtn = '';

        //GET TWIG IF IT EXISTS
        $possibleTwig = $type . '/' . $machine_name . '.' . $extension;

        // var_dump(  self::GetAssetURI($extension.'/' . $possibleTwig));
        if (is_file(get_template_directory() . '/' . $extension . '/' . $possibleTwig) || is_file(self::GetAssetURI($extension . '/' . $possibleTwig))) {
            $rtn = $possibleTwig;
        }

        // SO MANY FALLBACKS!
        //GET VARIANT TWIG IF IT EXISTS
        if ( ! empty($variant)) {
            $possibleVariantTwig = $type . '/variants/' . $machine_name . '/' . $variant . '.' . $extension;
            if (is_file(get_template_directory() . '/' . $extension . '/' . $possibleVariantTwig) || is_file(self::GetAssetURI($extension . '/' . $possibleVariantTwig))) {
                $rtn = $possibleVariantTwig;
            }
        }

        return $rtn;
    }


    /**
     * Update tied meta on both associated post types
     *
     * @param $post_id
     * @param $newIds
     * @param $local_var
     * @param $remote_var
     *
     * @return array $structuredIds
     */
    public static function UpdateTies($post_id, $newIds, $local_var, $remote_var): array
    {
        global $wpdb;
        $old_local_vars = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id = %d AND meta_key = %s", array($post_id, $local_var)));
        $old_local_vars = unserialize($old_local_vars);
        $structuredIds  = array();

        foreach ($newIds as $newId) {
            // add the staff member to the service"s meta
            $update_remote_vars           = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id = %d AND meta_key = %s", array($newId, $remote_var)));
            $update_remote_vars           = unserialize($update_remote_vars);
            $update_remote_vars[$post_id] = $post_id;

            if (isset($old_local_vars[$newId])) {
                unset($old_local_vars[$newId]);
            }
            $wpdb->delete("{$wpdb->prefix}postmeta", array('post_id' => $newId, 'meta_key' => $remote_var));

            $wpdb->insert("{$wpdb->prefix}postmeta", array(
                'meta_value' => serialize($update_remote_vars),
                'post_id'    => $newId,
                'meta_key'   => $remote_var
            ));
            $structuredIds[$newId] = $newId;
        }

        if ( ! empty($old_local_vars)) {
            foreach ($old_local_vars as $oldId) {
                $delete_remote_vars = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id = %d AND meta_key = %s", array($oldId, $remote_var)));
                $delete_remote_vars = unserialize($delete_remote_vars);
                if (isset($delete_remote_vars[$post_id])) {
                    unset($delete_remote_vars[$post_id]);
                }
                $wpdb->delete("{$wpdb->prefix}postmeta", array('post_id' => $oldId, 'meta_key' => $remote_var));

                $wpdb->insert("{$wpdb->prefix}postmeta", array(
                    'meta_value' => serialize($delete_remote_vars),
                    'post_id'    => $oldId,
                    'meta_key'   => $remote_var
                ));
            }
        }

        return $structuredIds;
    }


    /**
     * Enqueue additional scripts or stylesheets
     *
     * @param array $arr
     */
    public static function EnqueueAdditional(array $arr = array())
    {
        foreach ($arr as $name => $item) {
            if ($item['type'] == "style") {
                if ( ! isset($item['deps'])) {
                    $item['deps'] = array();
                }
                if ( ! isset($item['ver'])) {
                    $item['ver'] = false;
                }
                if ( ! isset($item['media'])) {
                    $item['media'] = 'all';
                }
                wp_enqueue_style($name, $item['src'], $item['deps'], $item['ver'], $item['media']);
            }
            if ($item['type'] == "script") {
                if ( ! isset($item['deps'])) {
                    $item['deps'] = array();
                }
                if ( ! isset($item['ver'])) {
                    $item['ver'] = false;
                }
                if ( ! isset($item['footer'])) {
                    $item['footer'] = true;
                }
                wp_enqueue_script($name, $item['src'], $item['deps'], $item['ver'], $item['footer']);
            }
        }
    }

    public static function EnqueueMaps($map, $callback)
    {
        global $base;
        $base::addMap($map, $callback);
    }
    // ************** //
    // ************** //


// ************** //
    /**
     * MONTH SELECT LIST HELPER FUNCTION
     *
     * @return string[] $months: array of months
     */
    public static function MonthArray(): array
    {
        return [
            '01' => 'January',
            '02' => 'February',
            '03' => 'March',
            '04' => 'April',
            '05' => 'May',
            '06' => 'June',
            '07' => 'July',
            '08' => 'August',
            '09' => 'September',
            '10' => 'October',
            '11' => 'November',
            '12' => 'December',
        ];
    }

    /**
     * Sets the month number to its actual name.
     *
     * @param int $month
     *
     * @return string $monthName
     */
    public static function GetMonthFromNumber(int $month = 0): string
    {
        $dateObj = DateTime::createFromFormat('!m', $month);

        return $dateObj->format('F');
    }

    /**
     * Get Breadcrumbs for a given page or post id
     *
     * @param int $id
     *
     * @return array $rtn
     */
    public static function GetBreadcrumbs(int $id): array
    {
        $terms = get_the_terms($id, 'product_category');
        $rtn   = [];
        foreach ($terms as $child_term) {
            $rtn[] = ResourceNavigatorUtilityBase::GetTaxRoot($child_term);
        }

        return $rtn;
    }

    public static function GetTaxRoot(WP_Term $term, $path = [])
    {
        array_unshift($path, '<a href="' . get_term_link($term->term_id) . '">' . $term->name . '</a>');

        if ( ! empty($term->parent)) {
            $path = ResourceNavigatorUtilityBase::GetTaxRoot(get_term($term->parent, 'product_category'), $path);
        }

        return $path;
    }

    /**
     * Creates a drop down list of months
     *
     * @param string $inValue
     * @param bool $useAbbr
     *
     * @return string $tmpSelect
     */
    public static function ReturnMonthSelect(string $inValue = '', bool $useAbbr = true): string
    {
        $tmpSelect = '';
        $tmpArray  = self::MonthArray();

        foreach ($tmpArray as $key => $value) {
            $tmpSelect .= '<option value="' . $key . '" ';
            if ($inValue == $key) {
                $tmpSelect .= 'selected';
            }
            $tmpSelect .= '>';
            if ($useAbbr == false) {
                $tmpSelect .= $value;
            } else {
                $tmpSelect .= $key;
            }
            $tmpSelect .= '</option>' . "\n";
        }
        unset($tmpArray);

        return $tmpSelect;
    }


    /**
     * Returns a select list of years
     *
     * @param string $inValue
     * @param int $history
     *
     * @return string $tmpSelect
     */
    public static function ReturnYearSelect(string $inValue = '', int $history = 20): string
    {
        $tmpSelect    = '';
        $current_year = date('Y');
        $date_range   = range($current_year, $current_year - $history);
        foreach ($date_range as $key => $value) {
            $tmpSelect .= '<option value="' . $value . '" ';
            if ($inValue == $value) {
                $tmpSelect .= 'selected';
            }
            $tmpSelect .= '>';
            $tmpSelect .= $value;
            $tmpSelect .= '</option>' . "\n";
        }
        unset($tmpArray);

        return $tmpSelect;
    }
    // ************** //

    /**
     * Returns a select list of years
     *
     * @param string $link
     *
     * @return bool $tmpSelect
     */
    public static function IsOffsiteLink(string $link): bool
    {
        $url          = get_bloginfo('url');
        $partial_link = substr($link, 0, strlen($url));

        return ! ($url == $partial_link);
    }

    /**
     * STATE SELECT LIST HELPER FUNCTION
     *
     * @return string[]: $states
     */
    public static function StateArray(): array
    {
        return [
            'AL' => 'Alabama',
            'AK' => 'Alaska',
            'AZ' => 'Arizona',
            'AR' => 'Arkansas',
            'CA' => 'California',
            'CO' => 'Colorado',
            'CT' => 'Connecticut',
            'DE' => 'Delaware',
            'DC' => 'District of Columbia',
            'FL' => 'Florida',
            'GA' => 'Georgia',
            'HI' => 'Hawaii',
            'ID' => 'Idaho',
            'IL' => 'Illinois',
            'IN' => 'Indiana',
            'IA' => 'Iowa',
            'KS' => 'Kansas',
            'KY' => 'Kentucky',
            'LA' => 'Louisiana',
            'ME' => 'Maine',
            'MD' => 'Maryland',
            'MA' => 'Massachusetts',
            'MI' => 'Michigan',
            'MN' => 'Minnesota',
            'MS' => 'Mississippi',
            'MO' => 'Missouri',
            'MT' => 'Montana',
            'NE' => 'Nebraska',
            'NV' => 'Nevada',
            'NH' => 'New Hampshire',
            'NJ' => 'New Jersey',
            'NM' => 'New Mexico',
            'NY' => 'New York',
            'NC' => 'North Carolina',
            'ND' => 'North Dakota',
            'OH' => 'Ohio',
            'OK' => 'Oklahoma',
            'OR' => 'Oregon',
            'PA' => 'Pennsylvania',
            'RI' => 'Rhode Island',
            'SC' => 'South Carolina',
            'SD' => 'South Dakota',
            'TN' => 'Tennessee',
            'TX' => 'Texas',
            'UT' => 'Utah',
            'VT' => 'Vermont',
            'VA' => 'Virginia',
            'WA' => 'Washington',
            'WV' => 'West Virginia',
            'WI' => 'Wisconsin',
            'WY' => 'Wyoming'
        ];
    }

    //State array as select options
    public static function StateOptions($val = ""): string
    {
        $states = ResourceNavigatorUtilityBase::StateArray();
        $rtn    = '';
        foreach ($states as $abbr => $name) {
            $rtn .= '<option value="' . $abbr . '" ' . ($val == $abbr ? ' selected="selected"' : '') . '>' . $name . '</option>';
        }

        return $rtn;
    }

    /**
     * STATE SELECT LIST HELPER FUNCTION
     *
     * @return string[]: $states
     */
    public static function CountyArray($state = ""): array
    {
        $counties = [
            "AL" => [
                "Autauga County",
                "Baldwin County",
                "Barbour County",
                "Bibb County",
                "Blount County",
                "Bullock County",
                "Butler County",
                "Calhoun County",
                "Chambers County",
                "Cherokee County",
                "Chilton County",
                "Choctaw County",
                "Clarke County",
                "Clay County",
                "Cleburne County",
                "Coffee County",
                "Colbert County",
                "Conecuh County",
                "Coosa County",
                "Covington County",
                "Crenshaw County",
                "Cullman County",
                "Dale County",
                "Dallas County",
                "DeKalb County",
                "Elmore County",
                "Escambia County",
                "Etowah County",
                "Fayette County",
                "Franklin County",
                "Geneva County",
                "Greene County",
                "Hale County",
                "Henry County",
                "Houston County",
                "Jackson County",
                "Jefferson County",
                "Lamar County",
                "Lauderdale County",
                "Lawrence County",
                "Lee County",
                "Limestone County",
                "Lowndes County",
                "Macon County",
                "Madison County",
                "Marengo County",
                "Marion County",
                "Marshall County",
                "Mobile County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Perry County",
                "Pickens County",
                "Pike County",
                "Randolph County",
                "Russell County",
                "Shelby County",
                "St. Clair County",
                "Sumter County",
                "Talladega County",
                "Tallapoosa County",
                "Tuscaloosa County",
                "Walker County",
                "Washington County",
                "Wilcox County",
                "Winston County"
            ],
            "AK" => [
                "Anchorage Borough",
                "Bethel Census Area",
                "Bristol Bay Borough",
                "Dillingham Census Area",
                "Fairbanks North Star Borough",
                "Haines Borough",
                "Juneau Borough",
                "Kenai Peninsula Borough",
                "Ketchikan Gateway Borough",
                "Kodiak Island Borough",
                "Matanuska-Susitna Borough",
                "Nome Census Area",
                "North Slope Borough",
                "Prince of Wales-Outer Ketchikan Census A",
                "Sitka Borough",
                "Skagway-Hoonah-Angoon Census Area",
                "Southeast Fairbanks Census Area",
                "Valdez-Cordova Census Area",
                "Wade Hampton Census Area",
                "Wrangell-Petersburg Census Area",
                "Yakutat Borough",
                "Yukon-Koyukuk Census Area"
            ],
            "AZ" => [
                "Apache County",
                "Cochise County",
                "Coconino County",
                "Gila County",
                "Graham County",
                "Greenlee County",
                "La Paz County",
                "Maricopa County",
                "Mohave County",
                "Navajo County",
                "Pima County",
                "Pinal County",
                "Santa Cruz County",
                "Yavapai County",
                "Yuma County"
            ],
            "AR" => [
                "Arkansas County",
                "Ashley County",
                "Baxter County",
                "Benton County",
                "Boone County",
                "Bradley County",
                "Calhoun County",
                "Carroll County",
                "Chicot County",
                "Clark County",
                "Clay County",
                "Cleburne County",
                "Cleveland County",
                "Columbia County",
                "Conway County",
                "Craighead County",
                "Crawford County",
                "Crittenden County",
                "Cross County",
                "Dallas County",
                "Desha County",
                "Drew County",
                "Faulkner County",
                "Franklin County",
                "Fulton County",
                "Garland County",
                "Grant County",
                "Greene County",
                "Hempstead County",
                "Hot Spring County",
                "Howard County",
                "Independence County",
                "Izard County",
                "Jackson County",
                "Jefferson County",
                "Johnson County",
                "Lafayette County",
                "Lawrence County",
                "Lee County",
                "Lincoln County",
                "Little River County",
                "Logan County",
                "Lonoke County",
                "Madison County",
                "Marion County",
                "Miller County",
                "Mississippi County",
                "Monroe County",
                "Montgomery County",
                "Nevada County",
                "Newton County",
                "Ouachita County",
                "Perry County",
                "Phillips County",
                "Pike County",
                "Poinsett County",
                "Polk County",
                "Pope County",
                "Prairie County",
                "Pulaski County",
                "Randolph County",
                "Saline County",
                "Scott County",
                "Searcy County",
                "Sebastian County",
                "Sevier County",
                "Sharp County",
                "St. Francis County",
                "Stone County",
                "Union County",
                "Van Buren County",
                "Washington County",
                "White County",
                "Woodruff County",
                "Yell County"
            ],
            "CA" => [
                "Alameda County",
                "Alpine County",
                "Amador County",
                "Butte County",
                "Calaveras County",
                "Colusa County",
                "Contra Costa County",
                "Del Norte County",
                "El Dorado County",
                "Fresno County",
                "Glenn County",
                "Humboldt County",
                "Imperial County",
                "Inyo County",
                "Kern County",
                "Kings County",
                "Lake County",
                "Lassen County",
                "Los Angeles County",
                "Madera County",
                "Marin County",
                "Mariposa County",
                "Mendocino County",
                "Merced County",
                "Modoc County",
                "Mono County",
                "Monterey County",
                "Napa County",
                "Nevada County",
                "Orange County",
                "Placer County",
                "Plumas County",
                "Riverside County",
                "Sacramento County",
                "San Benito County",
                "San Bernardino County",
                "San Diego County",
                "San Francisco County",
                "San Joaquin County",
                "San Luis Obispo County",
                "San Mateo County",
                "Santa Barbara County",
                "Santa Clara County",
                "Santa Cruz County",
                "Shasta County",
                "Sierra County",
                "Siskiyou County",
                "Solano County",
                "Sonoma County",
                "Stanislaus County",
                "Sutter County",
                "Tehama County",
                "Trinity County",
                "Tulare County",
                "Tuolumne County",
                "Ventura County",
                "Yolo County",
                "Yuba County"
            ],
            "CO" => [
                "Adams County",
                "Alamosa County",
                "Arapahoe County",
                "Archuleta County",
                "Baca County",
                "Bent County",
                "Boulder County",
                "Broomfield County",
                "Chaffee County",
                "Cheyenne County",
                "Clear Creek County",
                "Conejos County",
                "Costilla County",
                "Crowley County",
                "Custer County",
                "Delta County",
                "Denver County",
                "Dolores County",
                "Douglas County",
                "Eagle County",
                "El Paso County",
                "Elbert County",
                "Fremont County",
                "Garfield County",
                "Gilpin County",
                "Grand County",
                "Gunnison County",
                "Hinsdale County",
                "Huerfano County",
                "Jackson County",
                "Jefferson County",
                "Kiowa County",
                "Kit Carson County",
                "La Plata County",
                "Lake County",
                "Larimer County",
                "Las Animas County",
                "Lincoln County",
                "Logan County",
                "Mesa County",
                "Mineral County",
                "Moffat County",
                "Montezuma County",
                "Montrose County",
                "Morgan County",
                "Otero County",
                "Ouray County",
                "Park County",
                "Phillips County",
                "Pitkin County",
                "Prowers County",
                "Pueblo County",
                "Rio Blanco County",
                "Rio Grande County",
                "Routt County",
                "Saguache County",
                "San Juan County",
                "San Miguel County",
                "Sedgwick County",
                "Summit County",
                "Teller County",
                "Washington County",
                "Weld County",
                "Yuma County"
            ],
            "CT" => [
                "Fairfield County",
                "Hartford County",
                "Litchfield County",
                "Middlesex County",
                "New Haven County",
                "New London County",
                "Tolland County",
                "Windham County"
            ],
            "DE" => [
                "Kent County",
                "New Castle County",
                "Sussex County"
            ],
            "FL" => [
                "Alachua County",
                "Baker County",
                "Bay County",
                "Bradford County",
                "Brevard County",
                "Broward County",
                "Calhoun County",
                "Charlotte County",
                "Citrus County",
                "Clay County",
                "Collier County",
                "Columbia County",
                "DeSoto County",
                "Dixie County",
                "Duval County",
                "Escambia County",
                "Flagler County",
                "Franklin County",
                "Gadsden County",
                "Gilchrist County",
                "Glades County",
                "Gulf County",
                "Hamilton County",
                "Hardee County",
                "Hendry County",
                "Hernando County",
                "Highlands County",
                "Hillsborough County",
                "Holmes County",
                "Indian River County",
                "Jackson County",
                "Jefferson County",
                "Lafayette County",
                "Lake County",
                "Lee County",
                "Leon County",
                "Levy County",
                "Liberty County",
                "Madison County",
                "Manatee County",
                "Marion County",
                "Martin County",
                "Miami-Dade County",
                "Monroe County",
                "Nassau County",
                "Okaloosa County",
                "Okeechobee County",
                "Orange County",
                "Osceola County",
                "Palm Beach County",
                "Pasco County",
                "Pinellas County",
                "Polk County",
                "Putnam County",
                "Santa Rosa County",
                "Sarasota County",
                "Seminole County",
                "St. Johns County",
                "St. Lucie County",
                "Sumter County",
                "Suwannee County",
                "Taylor County",
                "Union County",
                "Volusia County",
                "Wakulla County",
                "Walton County",
                "Washington County"
            ],
            "GA" => [
                "Appling County",
                "Atkinson County",
                "Bacon County",
                "Baker County",
                "Baldwin County",
                "Banks County",
                "Barrow County",
                "Bartow County",
                "Ben Hill County",
                "Berrien County",
                "Bibb County",
                "Bleckley County",
                "Brantley County",
                "Brooks County",
                "Bryan County",
                "Bulloch County",
                "Burke County",
                "Butts County",
                "Calhoun County",
                "Camden County",
                "Candler County",
                "Carroll County",
                "Catoosa County",
                "Charlton County",
                "Chatham County",
                "Chattahoochee County",
                "Chattooga County",
                "Cherokee County",
                "Clarke County",
                "Clay County",
                "Clayton County",
                "Clinch County",
                "Cobb County",
                "Coffee County",
                "Colquitt County",
                "Columbia County",
                "Cook County",
                "Coweta County",
                "Crawford County",
                "Crisp County",
                "Dade County",
                "Dawson County",
                "Decatur County",
                "DeKalb County",
                "Dodge County",
                "Dooly County",
                "Dougherty County",
                "Douglas County",
                "Early County",
                "Echols County",
                "Effingham County",
                "Elbert County",
                "Emanuel County",
                "Evans County",
                "Fannin County",
                "Fayette County",
                "Floyd County",
                "Forsyth County",
                "Franklin County",
                "Fulton County",
                "Gilmer County",
                "Glascock County",
                "Glynn County",
                "Gordon County",
                "Grady County",
                "Greene County",
                "Gwinnett County",
                "Habersham County",
                "Hall County",
                "Hancock County",
                "Haralson County",
                "Harris County",
                "Hart County",
                "Heard County",
                "Henry County",
                "Houston County",
                "Irwin County",
                "Jackson County",
                "Jasper County",
                "Jeff Davis County",
                "Jefferson County",
                "Jenkins County",
                "Johnson County",
                "Jones County",
                "Lamar County",
                "Lanier County",
                "Laurens County",
                "Lee County",
                "Liberty County",
                "Lincoln County",
                "Long County",
                "Lowndes County",
                "Lumpkin County",
                "Macon County",
                "Madison County",
                "Marion County",
                "McDuffie County",
                "McIntosh County",
                "Meriwether County",
                "Miller County",
                "Mitchell County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Murray County",
                "Muscogee County",
                "Newton County",
                "Oconee County",
                "Oglethorpe County",
                "Paulding County",
                "Peach County",
                "Pickens County",
                "Pierce County",
                "Pike County",
                "Polk County",
                "Pulaski County",
                "Putnam County",
                "Quitman County",
                "Rabun County",
                "Randolph County",
                "Richmond County",
                "Rockdale County",
                "Schley County",
                "Screven County",
                "Seminole County",
                "Spalding County",
                "Stephens County",
                "Stewart County",
                "Sumter County",
                "Talbot County",
                "Taliaferro County",
                "Tattnall County",
                "Taylor County",
                "Telfair County",
                "Terrell County",
                "Thomas County",
                "Tift County",
                "Toombs County",
                "Towns County",
                "Treutlen County",
                "Troup County",
                "Turner County",
                "Twiggs County",
                "Union County",
                "Upson County",
                "Walker County",
                "Walton County",
                "Ware County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Wheeler County",
                "White County",
                "Whitfield County",
                "Wilcox County",
                "Wilkes County",
                "Wilkinson County",
                "Worth County"
            ],
            "HI" => [
                "Hawaii County",
                "Honolulu County",
                "Kalawao County",
                "Kauai County",
                "Maui County"
            ],
            "ID" => [
                "Ada County",
                "Adams County",
                "Bannock County",
                "Bear Lake County",
                "Benewah County",
                "Bingham County",
                "Blaine County",
                "Boise County",
                "Bonner County",
                "Bonneville County",
                "Boundary County",
                "Butte County",
                "Camas County",
                "Canyon County",
                "Caribou County",
                "Cassia County",
                "Clark County",
                "Clearwater County",
                "Custer County",
                "Elmore County",
                "Franklin County",
                "Fremont County",
                "Gem County",
                "Gooding County",
                "Idaho County",
                "Jefferson County",
                "Jerome County",
                "Kootenai County",
                "Latah County",
                "Lemhi County",
                "Lewis County",
                "Lincoln County",
                "Madison County",
                "Minidoka County",
                "Nez Perce County",
                "Oneida County",
                "Owyhee County",
                "Payette County",
                "Power County",
                "Shoshone County",
                "Teton County",
                "Twin Falls County",
                "Valley County",
                "Washington County"
            ],
            "IL" => [
                "Adams County",
                "Alexander County",
                "Bond County",
                "Boone County",
                "Brown County",
                "Bureau County",
                "Calhoun County",
                "Carroll County",
                "Cass County",
                "Champaign County",
                "Christian County",
                "Clark County",
                "Clay County",
                "Clinton County",
                "Coles County",
                "Cook County",
                "Crawford County",
                "Cumberland County",
                "De Witt County",
                "DeKalb County",
                "Douglas County",
                "DuPage County",
                "Edgar County",
                "Edwards County",
                "Effingham County",
                "Fayette County",
                "Ford County",
                "Franklin County",
                "Fulton County",
                "Gallatin County",
                "Greene County",
                "Grundy County",
                "Hamilton County",
                "Hancock County",
                "Hardin County",
                "Henderson County",
                "Henry County",
                "Iroquois County",
                "Jackson County",
                "Jasper County",
                "Jefferson County",
                "Jersey County",
                "Jo Daviess County",
                "Johnson County",
                "Kane County",
                "Kankakee County",
                "Kendall County",
                "Knox County",
                "La Salle County",
                "Lake County",
                "Lawrence County",
                "Lee County",
                "Livingston County",
                "Logan County",
                "Macon County",
                "Macoupin County",
                "Madison County",
                "Marion County",
                "Marshall County",
                "Mason County",
                "Massac County",
                "McDonough County",
                "McHenry County",
                "McLean County",
                "Menard County",
                "Mercer County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Moultrie County",
                "Ogle County",
                "Peoria County",
                "Perry County",
                "Piatt County",
                "Pike County",
                "Pope County",
                "Pulaski County",
                "Putnam County",
                "Randolph County",
                "Richland County",
                "Rock Island County",
                "Saline County",
                "Sangamon County",
                "Schuyler County",
                "Scott County",
                "Shelby County",
                "St. Clair County",
                "Stark County",
                "Stephenson County",
                "Tazewell County",
                "Union County",
                "Vermilion County",
                "Wabash County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "White County",
                "Whiteside County",
                "Will County",
                "Williamson County",
                "Winnebago County",
                "Woodford County"
            ],
            "IN" => [
                "Adams County",
                "Allen County",
                "Bartholomew County",
                "Benton County",
                "Blackford County",
                "Boone County",
                "Brown County",
                "Carroll County",
                "Cass County",
                "Clark County",
                "Clay County",
                "Clinton County",
                "Crawford County",
                "Daviess County",
                "De Kalb County",
                "Dearborn County",
                "Decatur County",
                "Delaware County",
                "Dubois County",
                "Elkhart County",
                "Fayette County",
                "Floyd County",
                "Fountain County",
                "Franklin County",
                "Fulton County",
                "Gibson County",
                "Grant County",
                "Greene County",
                "Hamilton County",
                "Hancock County",
                "Harrison County",
                "Hendricks County",
                "Henry County",
                "Howard County",
                "Huntington County",
                "Jackson County",
                "Jasper County",
                "Jay County",
                "Jefferson County",
                "Jennings County",
                "Johnson County",
                "Knox County",
                "Kosciusko County",
                "La Porte County",
                "Lagrange County",
                "Lake County",
                "Lawrence County",
                "Madison County",
                "Marion County",
                "Marshall County",
                "Martin County",
                "Miami County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Newton County",
                "Noble County",
                "Ohio County",
                "Orange County",
                "Owen County",
                "Parke County",
                "Perry County",
                "Pike County",
                "Porter County",
                "Posey County",
                "Pulaski County",
                "Putnam County",
                "Randolph County",
                "Ripley County",
                "Rush County",
                "Scott County",
                "Shelby County",
                "Spencer County",
                "St. Joseph County",
                "Starke County",
                "Steuben County",
                "Sullivan County",
                "Switzerland County",
                "Tippecanoe County",
                "Tipton County",
                "Union County",
                "Vanderburgh County",
                "Vermillion County",
                "Vigo County",
                "Wabash County",
                "Warren County",
                "Warrick County",
                "Washington County",
                "Wayne County",
                "Wells County",
                "White County",
                "Whitley County"
            ],
            "IA" => [
                "Adair County",
                "Adams County",
                "Allamakee County",
                "Appanoose County",
                "Audubon County",
                "Benton County",
                "Black Hawk County",
                "Boone County",
                "Bremer County",
                "Buchanan County",
                "Buena Vista County",
                "Butler County",
                "Calhoun County",
                "Carroll County",
                "Cass County",
                "Cedar County",
                "Cerro Gordo County",
                "Cherokee County",
                "Chickasaw County",
                "Clarke County",
                "Clay County",
                "Clayton County",
                "Clinton County",
                "Crawford County",
                "Dallas County",
                "Davis County",
                "Decatur County",
                "Delaware County",
                "Des Moines County",
                "Dickinson County",
                "Dubuque County",
                "Emmet County",
                "Fayette County",
                "Floyd County",
                "Franklin County",
                "Fremont County",
                "Greene County",
                "Grundy County",
                "Guthrie County",
                "Hamilton County",
                "Hancock County",
                "Hardin County",
                "Harrison County",
                "Henry County",
                "Howard County",
                "Humboldt County",
                "Ida County",
                "Iowa County",
                "Jackson County",
                "Jasper County",
                "Jefferson County",
                "Johnson County",
                "Jones County",
                "Keokuk County",
                "Kossuth County",
                "Lee County",
                "Linn County",
                "Louisa County",
                "Lucas County",
                "Lyon County",
                "Madison County",
                "Mahaska County",
                "Marion County",
                "Marshall County",
                "Mills County",
                "Mitchell County",
                "Monona County",
                "Monroe County",
                "Montgomery County",
                "Muscatine County",
                "O'Brien County",
                "Osceola County",
                "Page County",
                "Palo Alto County",
                "Plymouth County",
                "Pocahontas County",
                "Polk County",
                "Pottawattamie County",
                "Poweshiek County",
                "Ringgold County",
                "Sac County",
                "Scott County",
                "Shelby County",
                "Sioux County",
                "Story County",
                "Tama County",
                "Taylor County",
                "Union County",
                "Van Buren County",
                "Wapello County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Winnebago County",
                "Winneshiek County",
                "Woodbury County",
                "Worth County",
                "Wright County"
            ],
            "KS" => [
                "Allen County",
                "Anderson County",
                "Atchison County",
                "Barber County",
                "Barton County",
                "Bourbon County",
                "Brown County",
                "Butler County",
                "Chase County",
                "Chautauqua County",
                "Cherokee County",
                "Cheyenne County",
                "Clark County",
                "Clay County",
                "Cloud County",
                "Coffey County",
                "Comanche County",
                "Cowley County",
                "Crawford County",
                "Decatur County",
                "Dickinson County",
                "Doniphan County",
                "Douglas County",
                "Edwards County",
                "Elk County",
                "Ellis County",
                "Ellsworth County",
                "Finney County",
                "Ford County",
                "Franklin County",
                "Geary County",
                "Gove County",
                "Graham County",
                "Grant County",
                "Gray County",
                "Greeley County",
                "Greenwood County",
                "Hamilton County",
                "Harper County",
                "Harvey County",
                "Haskell County",
                "Hodgeman County",
                "Jackson County",
                "Jefferson County",
                "Jewell County",
                "Johnson County",
                "Kearny County",
                "Kingman County",
                "Kiowa County",
                "Labette County",
                "Lane County",
                "Leavenworth County",
                "Lincoln County",
                "Linn County",
                "Logan County",
                "Lyon County",
                "Marion County",
                "Marshall County",
                "McPherson County",
                "Meade County",
                "Miami County",
                "Mitchell County",
                "Montgomery County",
                "Morris County",
                "Morton County",
                "Nemaha County",
                "Neosho County",
                "Ness County",
                "Norton County",
                "Osage County",
                "Osborne County",
                "Ottawa County",
                "Pawnee County",
                "Phillips County",
                "Pottawatomie County",
                "Pratt County",
                "Rawlins County",
                "Reno County",
                "Republic County",
                "Rice County",
                "Riley County",
                "Rooks County",
                "Rush County",
                "Russell County",
                "Saline County",
                "Scott County",
                "Sedgwick County",
                "Seward County",
                "Shawnee County",
                "Sheridan County",
                "Sherman County",
                "Smith County",
                "Stafford County",
                "Stanton County",
                "Stevens County",
                "Sumner County",
                "Thomas County",
                "Trego County",
                "Wabaunsee County",
                "Wallace County",
                "Washington County",
                "Wichita County",
                "Wilson County",
                "Woodson County",
                "Wyandotte County"
            ],
            "KY" => [
                "Adair County",
                "Allen County",
                "Anderson County",
                "Ballard County",
                "Barren County",
                "Bath County",
                "Bell County",
                "Boone County",
                "Bourbon County",
                "Boyd County",
                "Boyle County",
                "Bracken County",
                "Breathitt County",
                "Breckenridge County",
                "Bullitt County",
                "Butler County",
                "Caldwell County",
                "Calloway County",
                "Campbell County",
                "Carlisle County",
                "Carroll County",
                "Carter County",
                "Casey County",
                "Christian County",
                "Clark County",
                "Clay County",
                "Clinton County",
                "Crittenden County",
                "Cumberland County",
                "Daviess County",
                "Edmonson County",
                "Elliott County",
                "Estill County",
                "Fayette County",
                "Fleming County",
                "Floyd County",
                "Franklin County",
                "Fulton County",
                "Gallatin County",
                "Garrard County",
                "Grant County",
                "Graves County",
                "Grayson County",
                "Green County",
                "Greenup County",
                "Hancock County",
                "Hardin County",
                "Harlan County",
                "Harrison County",
                "Hart County",
                "Henderson County",
                "Henry County",
                "Hickman County",
                "Hopkins County",
                "Jackson County",
                "Jefferson County",
                "Jessamine County",
                "Johnson County",
                "Kenton County",
                "Knott County",
                "Knox County",
                "Larue County",
                "Laurel County",
                "Lawrence County",
                "Lee County",
                "Leslie County",
                "Letcher County",
                "Lewis County",
                "Lincoln County",
                "Livingston County",
                "Logan County",
                "Lyon County",
                "Madison County",
                "Magoffin County",
                "Marion County",
                "Marshall County",
                "Martin County",
                "Mason County",
                "McCracken County",
                "McCreary County",
                "McLean County",
                "Meade County",
                "Menifee County",
                "Mercer County",
                "Metcalfe County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Muhlenberg County",
                "Nelson County",
                "Nicholas County",
                "Ohio County",
                "Oldham County",
                "Owen County",
                "Owsley County",
                "Pendleton County",
                "Perry County",
                "Pike County",
                "Powell County",
                "Pulaski County",
                "Robertson County",
                "Rockcastle County",
                "Rowan County",
                "Russell County",
                "Scott County",
                "Shelby County",
                "Simpson County",
                "Spencer County",
                "Taylor County",
                "Todd County",
                "Trigg County",
                "Trimble County",
                "Union County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Whitley County",
                "Wolfe County",
                "Woodford County"
            ],
            "LA" => [
                "Acadia Parish",
                "Allen Parish",
                "Ascension Parish",
                "Assumption Parish",
                "Avoyelles Parish",
                "Beauregard Parish",
                "Bienville Parish",
                "Bossier Parish",
                "Caddo Parish",
                "Calcasieu Parish",
                "Caldwell Parish",
                "Cameron Parish",
                "Catahoula Parish",
                "Claiborne Parish",
                "Concordia Parish",
                "De Soto Parish",
                "East Baton Rouge Parish",
                "East Carroll Parish",
                "East Feliciana Parish",
                "Evangeline Parish",
                "Franklin Parish",
                "Grant Parish",
                "Iberia Parish",
                "Iberville Parish",
                "Jackson Parish",
                "Jefferson Davis Parish",
                "Jefferson Parish",
                "La Salle Parish",
                "Lafayette Parish",
                "Lafourche Parish",
                "Lincoln Parish",
                "Livingston Parish",
                "Madison Parish",
                "Morehouse Parish",
                "Natchitoches Parish",
                "Orleans Parish",
                "Ouachita Parish",
                "Plaquemines Parish",
                "Pointe Coupee Parish",
                "Rapides Parish",
                "Red River Parish",
                "Richland Parish",
                "Sabine Parish",
                "St. Bernard Parish",
                "St. Charles Parish",
                "St. Helena Parish",
                "St. James Parish",
                "St. John the Baptist Parish",
                "St. Landry Parish",
                "St. Martin Parish",
                "St. Mary Parish",
                "St. Tammany Parish",
                "Tangipahoa Parish",
                "Tensas Parish",
                "Terrebonne Parish",
                "Union Parish",
                "Vermilion Parish",
                "Vernon Parish",
                "Washington Parish",
                "Webster Parish",
                "West Baton Rouge Parish",
                "West Carroll Parish",
                "West Feliciana Parish",
                "Winn Parish"
            ],
            "ME" => [
                "Androscoggin County",
                "Aroostook County",
                "Cumberland County",
                "Franklin County",
                "Hancock County",
                "Kennebec County",
                "Knox County",
                "Lincoln County",
                "Oxford County",
                "Penobscot County",
                "Piscataquis County",
                "Sagadahoc County",
                "Somerset County",
                "Waldo County",
                "Washington County",
                "York County"
            ],
            "MD" => [
                "Allegany County",
                "Anne Arundel County",
                "Baltimore City",
                "Baltimore County",
                "Calvert County",
                "Caroline County",
                "Carroll County",
                "Cecil County",
                "Charles County",
                "Dorchester County",
                "Frederick County",
                "Garrett County",
                "Harford County",
                "Howard County",
                "Kent County",
                "Montgomery County",
                "Prince George's County",
                "Queen Anne's County",
                "Somerset County",
                "St. Mary's County",
                "Talbot County",
                "Washington County",
                "Wicomico County",
                "Worcester County",
                "Massachusetts",
                "Barnstable County",
                "Berkshire County",
                "Bristol County",
                "Dukes County",
                "Essex County",
                "Franklin County",
                "Hampden County",
                "Hampshire County",
                "Middlesex County",
                "Nantucket County",
                "Norfolk County",
                "Plymouth County",
                "Suffolk County",
                "Worcester County"
            ],
            'MA' => [
                "Barnstable County",
                "Bristol County",
                "Dukes County",
                "Nantucket County",
                "Norfolk County",
                "Plymouth County",
                "Suffolk County"
            ],
            "MI" => [
                "Alcona County",
                "Alger County",
                "Allegan County",
                "Alpena County",
                "Antrim County",
                "Arenac County",
                "Baraga County",
                "Barry County",
                "Bay County",
                "Benzie County",
                "Berrien County",
                "Branch County",
                "Calhoun County",
                "Cass County",
                "Charlevoix County",
                "Cheboygan County",
                "Chippewa County",
                "Clare County",
                "Clinton County",
                "Crawford County",
                "Delta County",
                "Dickinson County",
                "Eaton County",
                "Emmet County",
                "Genesee County",
                "Gladwin County",
                "Gogebic County",
                "Grand Traverse County",
                "Gratiot County",
                "Hillsdale County",
                "Houghton County",
                "Huron County",
                "Ingham County",
                "Ionia County",
                "Iosco County",
                "Iron County",
                "Isabella County",
                "Jackson County",
                "Kalamazoo County",
                "Kalkaska County",
                "Kent County",
                "Keweenaw County",
                "Lake County",
                "Lapeer County",
                "Leelanau County",
                "Lenawee County",
                "Livingston County",
                "Luce County",
                "Mackinac County",
                "Macomb County",
                "Manistee County",
                "Marquette County",
                "Mason County",
                "Mecosta County",
                "Menominee County",
                "Midland County",
                "Missaukee County",
                "Monroe County",
                "Montcalm County",
                "Montmorency County",
                "Muskegon County",
                "Newaygo County",
                "Oakland County",
                "Oceana County",
                "Ogemaw County",
                "Ontonagon County",
                "Osceola County",
                "Oscoda County",
                "Otsego County",
                "Ottawa County",
                "Presque Isle County",
                "Roscommon County",
                "Saginaw County",
                "Sanilac County",
                "Schoolcraft County",
                "Shiawassee County",
                "St. Clair County",
                "St. Joseph County",
                "Tuscola County",
                "Van Buren County",
                "Washtenaw County",
                "Wayne County",
                "Wexford County"
            ],
            "MN" => [
                "Aitkin County",
                "Anoka County",
                "Becker County",
                "Beltrami County",
                "Benton County",
                "Big Stone County",
                "Blue Earth County",
                "Brown County",
                "Carlton County",
                "Carver County",
                "Cass County",
                "Chippewa County",
                "Chisago County",
                "Clay County",
                "Clearwater County",
                "Cook County",
                "Cottonwood County",
                "Crow Wing County",
                "Dakota County",
                "Dodge County",
                "Douglas County",
                "Faribault County",
                "Fillmore County",
                "Freeborn County",
                "Goodhue County",
                "Grant County",
                "Hennepin County",
                "Houston County",
                "Hubbard County",
                "Isanti County",
                "Itasca County",
                "Jackson County",
                "Kanabec County",
                "Kandiyohi County",
                "Kittson County",
                "Koochiching County",
                "Lac qui Parle County",
                "Lake of the Woods County",
                "Lake County",
                "Le Sueur County",
                "Lincoln County",
                "Lyon County",
                "Mahnomen County",
                "Marshall County",
                "Martin County",
                "McLeod County",
                "Meeker County",
                "Mille Lacs County",
                "Morrison County",
                "Mower County",
                "Murray County",
                "Nicollet County",
                "Nobles County",
                "Norman County",
                "Olmsted County",
                "Otter Tail County",
                "Pennington County",
                "Pine County",
                "Pipestone County",
                "Polk County",
                "Pope County",
                "Ramsey County",
                "Red Lake County",
                "Redwood County",
                "Renville County",
                "Rice County",
                "Rock County",
                "Roseau County",
                "Scott County",
                "Sherburne County",
                "Sibley County",
                "St. Louis County",
                "Stearns County",
                "Steele County",
                "Stevens County",
                "Swift County",
                "Todd County",
                "Traverse County",
                "Wabasha County",
                "Wadena County",
                "Waseca County",
                "Washington County",
                "Watonwan County",
                "Wilkin County",
                "Winona County",
                "Wright County",
                "Yellow Medicine County"
            ],
            "MS" => [
                "Adams County",
                "Alcorn County",
                "Amite County",
                "Attala County",
                "Benton County",
                "Bolivar County",
                "Calhoun County",
                "Carroll County",
                "Chickasaw County",
                "Choctaw County",
                "Claiborne County",
                "Clarke County",
                "Clay County",
                "Coahoma County",
                "Copiah County",
                "Covington County",
                "DeSoto County",
                "Forrest County",
                "Franklin County",
                "George County",
                "Greene County",
                "Grenada County",
                "Hancock County",
                "Harrison County",
                "Hinds County",
                "Holmes County",
                "Humphreys County",
                "Issaquena County",
                "Itawamba County",
                "Jackson County",
                "Jasper County",
                "Jefferson County",
                "Jefferson Davis County",
                "Jones County",
                "Kemper County",
                "Lafayette County",
                "Lamar County",
                "Lauderdale County",
                "Lawrence County",
                "Leake County",
                "Lee County",
                "Leflore County",
                "Lincoln County",
                "Lowndes County",
                "Madison County",
                "Marion County",
                "Marshall County",
                "Monroe County",
                "Montgomery County",
                "Neshoba County",
                "Newton County",
                "Noxubee County",
                "Oktibbeha County",
                "Panola County",
                "Pearl River County",
                "Perry County",
                "Pike County",
                "Pontotoc County",
                "Prentiss County",
                "Quitman County",
                "Rankin County",
                "Scott County",
                "Sharkey County",
                "Simpson County",
                "Smith County",
                "Stone County",
                "Sunflower County",
                "Tallahatchie County",
                "Tate County",
                "Tippah County",
                "Tishomingo County",
                "Tunica County",
                "Union County",
                "Walthall County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Wilkinson County",
                "Winston County",
                "Yalobusha County",
                "Yazoo County"
            ],
            "MO" => [
                "Adair County",
                "Andrew County",
                "Atchison County",
                "Audrain County",
                "Barry County",
                "Barton County",
                "Bates County",
                "Benton County",
                "Bollinger County",
                "Boone County",
                "Buchanan County",
                "Butler County",
                "Caldwell County",
                "Callaway County",
                "Camden County",
                "Cape Girardeau County",
                "Carroll County",
                "Carter County",
                "Cass County",
                "Cedar County",
                "Chariton County",
                "Christian County",
                "Clark County",
                "Clay County",
                "Clinton County",
                "Cole County",
                "Cooper County",
                "Crawford County",
                "Dade County",
                "Dallas County",
                "Daviess County",
                "Dent County",
                "DeKalb County",
                "Douglas County",
                "Dunklin County",
                "Franklin County",
                "Gasconade County",
                "Gentry County",
                "Greene County",
                "Grundy County",
                "Harrison County",
                "Henry County",
                "Hickory County",
                "Holt County",
                "Howard County",
                "Howell County",
                "Iron County",
                "Jackson County",
                "Jasper County",
                "Jefferson County",
                "Johnson County",
                "Knox County",
                "Laclede County",
                "Lafayette County",
                "Lawrence County",
                "Lewis County",
                "Lincoln County",
                "Linn County",
                "Livingston County",
                "Macon County",
                "Madison County",
                "Maries County",
                "Marion County",
                "McDonald County",
                "Mercer County",
                "Miller County",
                "Mississippi County",
                "Moniteau County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "New Madrid County",
                "Newton County",
                "Nodaway County",
                "Oregon County",
                "Osage County",
                "Ozark County",
                "Pemiscot County",
                "Perry County",
                "Pettis County",
                "Phelps County",
                "Pike County",
                "Platte County",
                "Polk County",
                "Pulaski County",
                "Putnam County",
                "Ralls County",
                "Randolph County",
                "Ray County",
                "Reynolds County",
                "Ripley County",
                "Saline County",
                "Schuyler County",
                "Scotland County",
                "Scott County",
                "Shannon County",
                "Shelby County",
                "St. Charles County",
                "St. Clair County",
                "St. Francois County",
                "St. Louis city",
                "St. Louis County",
                "Ste. Genevieve County",
                "Stoddard County",
                "Stone County",
                "Sullivan County",
                "Taney County",
                "Texas County",
                "Vernon County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Worth County",
                "Wright County"
            ],
            "MT" => [
                "Beaverhead County",
                "Big Horn County",
                "Blaine County",
                "Broadwater County",
                "Carbon County",
                "Carter County",
                "Cascade County",
                "Chouteau County",
                "Custer County",
                "Daniels County",
                "Dawson County",
                "Deer Lodge County",
                "Fallon County",
                "Fergus County",
                "Flathead County",
                "Gallatin County",
                "Garfield County",
                "Glacier County",
                "Golden Valley County",
                "Granite County",
                "Hill County",
                "Jefferson County",
                "Judith Basin County",
                "Lake County",
                "Lewis and Clark County",
                "Liberty County",
                "Lincoln County",
                "Madison County",
                "McCone County",
                "Meagher County",
                "Mineral County",
                "Missoula County",
                "Musselshell County",
                "Park County",
                "Petroleum County",
                "Phillips County",
                "Pondera County",
                "Powder River County",
                "Powell County",
                "Prairie County",
                "Ravalli County",
                "Richland County",
                "Roosevelt County",
                "Rosebud County",
                "Sanders County",
                "Sheridan County",
                "Silver Bow County",
                "Stillwater County",
                "Sweet Grass County",
                "Teton County",
                "Toole County",
                "Treasure County",
                "Valley County",
                "Wheatland County",
                "Wibaux County",
                "Yellowstone County"
            ],
            "NE" => [
                "Adams County",
                "Antelope County",
                "Arthur County",
                "Banner County",
                "Blaine County",
                "Boone County",
                "Box Butte County",
                "Boyd County",
                "Brown County",
                "Buffalo County",
                "Burt County",
                "Butler County",
                "Cass County",
                "Cedar County",
                "Chase County",
                "Cherry County",
                "Cheyenne County",
                "Clay County",
                "Colfax County",
                "Cuming County",
                "Custer County",
                "Dakota County",
                "Dawes County",
                "Dawson County",
                "Deuel County",
                "Dixon County",
                "Dodge County",
                "Douglas County",
                "Dundy County",
                "Fillmore County",
                "Franklin County",
                "Frontier County",
                "Furnas County",
                "Gage County",
                "Garden County",
                "Garfield County",
                "Gosper County",
                "Grant County",
                "Greeley County",
                "Hall County",
                "Hamilton County",
                "Harlan County",
                "Hayes County",
                "Hitchcock County",
                "Holt County",
                "Hooker County",
                "Howard County",
                "Jefferson County",
                "Johnson County",
                "Kearney County",
                "Keith County",
                "Keya Paha County",
                "Kimball County",
                "Knox County",
                "Lancaster County",
                "Lincoln County",
                "Logan County",
                "Loup County",
                "Madison County",
                "McPherson County",
                "Merrick County",
                "Morrill County",
                "Nance County",
                "Nemaha County",
                "Nuckolls County",
                "Otoe County",
                "Pawnee County",
                "Perkins County",
                "Phelps County",
                "Pierce County",
                "Platte County",
                "Polk County",
                "Red Willow County",
                "Richardson County",
                "Rock County",
                "Saline County",
                "Sarpy County",
                "Saunders County",
                "Scotts Bluff County",
                "Seward County",
                "Sheridan County",
                "Sherman County",
                "Sioux County",
                "Stanton County",
                "Thayer County",
                "Thomas County",
                "Thurston County",
                "Valley County",
                "Washington County",
                "Wayne County",
                "Webster County",
                "Wheeler County",
                "York County"
            ],
            "NV" => [
                "Churchill County",
                "Clark County",
                "Douglas County",
                "Elko County",
                "Esmeralda County",
                "Eureka County",
                "Humboldt County",
                "Lander County",
                "Lincoln County",
                "Lyon County",
                "Mineral County",
                "Nye County",
                "Pershing County",
                "Storey County",
                "Washoe County",
                "White Pine County"
            ],
            "NH" => [
                "Belknap County",
                "Carroll County",
                "Cheshire County",
                "Coos County",
                "Grafton County",
                "Hillsboro County",
                "Merrimack County",
                "Rockingham County",
                "Strafford County",
                "Sullivan County"
            ],
            "NJ" => [
                "Atlantic County",
                "Bergen County",
                "Burlington County",
                "Camden County",
                "Cape May County",
                "Cumberland County",
                "Essex County",
                "Gloucester County",
                "Hudson County",
                "Hunterdon County",
                "Mercer County",
                "Middlesex County",
                "Monmouth County",
                "Morris County",
                "Ocean County",
                "Passaic County",
                "Salem County",
                "Somerset County",
                "Sussex County",
                "Union County",
                "Warren County"
            ],
            "NM" => [
                "Bernalillo County",
                "Catron County",
                "Chaves County",
                "Cibola County",
                "Colfax County",
                "Curry County",
                "DeBaca County",
                "Dona Ana County",
                "Eddy County",
                "Grant County",
                "Guadalupe County",
                "Harding County",
                "Hidalgo County",
                "Lea County",
                "Lincoln County",
                "Los Alamos County",
                "Luna County",
                "McKinley County",
                "Mora County",
                "Otero County",
                "Quay County",
                "Rio Arriba County",
                "Roosevelt County",
                "San Juan County",
                "San Miguel County",
                "Sandoval County",
                "Santa Fe County",
                "Sierra County",
                "Socorro County",
                "Taos County",
                "Torrance County",
                "Union County",
                "Valencia County"
            ],
            "NY" => [
                "Albany County",
                "Allegany County",
                "Bronx County",
                "Broome County",
                "Cattaraugus County",
                "Cayuga County",
                "Chautauqua County",
                "Chemung County",
                "Chenango County",
                "Clinton County",
                "Columbia County",
                "Cortland County",
                "Delaware County",
                "Dutchess County",
                "Erie County",
                "Essex County",
                "Franklin County",
                "Fulton County",
                "Genesee County",
                "Greene County",
                "Hamilton County",
                "Herkimer County",
                "Jefferson County",
                "Kings County",
                "Lewis County",
                "Livingston County",
                "Madison County",
                "Monroe County",
                "Montgomery County",
                "Nassau County",
                "New York County",
                "Niagara County",
                "Oneida County",
                "Onondaga County",
                "Ontario County",
                "Orange County",
                "Orleans County",
                "Oswego County",
                "Otsego County",
                "Putnam County",
                "Queens County",
                "Rensselaer County",
                "Richmond County",
                "Rockland County",
                "Saratoga County",
                "Schenectady County",
                "Schoharie County",
                "Schuyler County",
                "Seneca County",
                "St. Lawrence County",
                "Steuben County",
                "Suffolk County",
                "Sullivan County",
                "Tioga County",
                "Tompkins County",
                "Ulster County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Westchester County",
                "Wyoming County",
                "Yates County"
            ],
            "NC" => [
                "Alamance County",
                "Alexander County",
                "Alleghany County",
                "Anson County",
                "Ashe County",
                "Avery County",
                "Beaufort County",
                "Bertie County",
                "Bladen County",
                "Brunswick County",
                "Buncombe County",
                "Burke County",
                "Cabarrus County",
                "Caldwell County",
                "Camden County",
                "Carteret County",
                "Caswell County",
                "Catawba County",
                "Chatham County",
                "Cherokee County",
                "Chowan County",
                "Clay County",
                "Cleveland County",
                "Columbus County",
                "Craven County",
                "Cumberland County",
                "Currituck County",
                "Dare County",
                "Davidson County",
                "Davie County",
                "Duplin County",
                "Durham County",
                "Edgecombe County",
                "Forsyth County",
                "Franklin County",
                "Gaston County",
                "Gates County",
                "Graham County",
                "Granville County",
                "Greene County",
                "Guilford County",
                "Halifax County",
                "Harnett County",
                "Haywood County",
                "Henderson County",
                "Hertford County",
                "Hoke County",
                "Hyde County",
                "Iredell County",
                "Jackson County",
                "Johnston County",
                "Jones County",
                "Lee County",
                "Lenoir County",
                "Lincoln County",
                "Macon County",
                "Madison County",
                "Martin County",
                "McDowell County",
                "Mecklenburg County",
                "Mitchell County",
                "Montgomery County",
                "Moore County",
                "Nash County",
                "New Hanover County",
                "Northampton County",
                "Onslow County",
                "Orange County",
                "Pamlico County",
                "Pasquotank County",
                "Pender County",
                "Perquimans County",
                "Person County",
                "Pitt County",
                "Polk County",
                "Randolph County",
                "Richmond County",
                "Robeson County",
                "Rockingham County",
                "Rowan County",
                "Rutherford County",
                "Sampson County",
                "Scotland County",
                "Stanly County",
                "Stokes County",
                "Surry County",
                "Swain County",
                "Transylvania County",
                "Tyrrell County",
                "Union County",
                "Vance County",
                "Wake County",
                "Warren County",
                "Washington County",
                "Watauga County",
                "Wayne County",
                "Wilkes County",
                "Wilson County",
                "Yadkin County",
                "Yancey County"
            ],
            "ND" => [
                "Adams County",
                "Barnes County",
                "Benson County",
                "Billings County",
                "Bottineau County",
                "Bowman County",
                "Burke County",
                "Burleigh County",
                "Cass County",
                "Cavalier County",
                "Dickey County",
                "Divide County",
                "Dunn County",
                "Eddy County",
                "Emmons County",
                "Foster County",
                "Golden Valley County",
                "Grand Forks County",
                "Grant County",
                "Griggs County",
                "Hettinger County",
                "Kidder County",
                "LaMoure County",
                "Logan County",
                "McHenry County",
                "McIntosh County",
                "McKenzie County",
                "McLean County",
                "Mercer County",
                "Morton County",
                "Mountrail County",
                "Nelson County",
                "Oliver County",
                "Pembina County",
                "Pierce County",
                "Ramsey County",
                "Ransom County",
                "Renville County",
                "Richland County",
                "Rolette County",
                "Sargent County",
                "Sheridan County",
                "Sioux County",
                "Slope County",
                "Stark County",
                "Steele County",
                "Stutsman County",
                "Towner County",
                "Traill County",
                "Walsh County",
                "Ward County",
                "Wells County",
                "Williams County"
            ],
            "OH" => [
                "Adams County",
                "Allen County",
                "Ashland County",
                "Ashtabula County",
                "Athens County",
                "Auglaize County",
                "Belmont County",
                "Brown County",
                "Butler County",
                "Carroll County",
                "Champaign County",
                "Clark County",
                "Clermont County",
                "Clinton County",
                "Columbiana County",
                "Coshocton County",
                "Crawford County",
                "Cuyahoga County",
                "Darke County",
                "Defiance County",
                "Delaware County",
                "Erie County",
                "Fairfield County",
                "Fayette County",
                "Franklin County",
                "Fulton County",
                "Gallia County",
                "Geauga County",
                "Greene County",
                "Guernsey County",
                "Hamilton County",
                "Hancock County",
                "Hardin County",
                "Harrison County",
                "Henry County",
                "Highland County",
                "Hocking County",
                "Holmes County",
                "Huron County",
                "Jackson County",
                "Jefferson County",
                "Knox County",
                "Lake County",
                "Lawrence County",
                "Licking County",
                "Logan County",
                "Lorain County",
                "Lucas County",
                "Madison County",
                "Mahoning County",
                "Marion County",
                "Medina County",
                "Meigs County",
                "Mercer County",
                "Miami County",
                "Monroe County",
                "Montgomery County",
                "Morgan County",
                "Morrow County",
                "Muskingum County",
                "Noble County",
                "Ottawa County",
                "Paulding County",
                "Perry County",
                "Pickaway County",
                "Pike County",
                "Portage County",
                "Preble County",
                "Putnam County",
                "Richland County",
                "Ross County",
                "Sandusky County",
                "Scioto County",
                "Seneca County",
                "Shelby County",
                "Stark County",
                "Summit County",
                "Trumbull County",
                "Tuscarawas County",
                "Union County",
                "Van Wert County",
                "Vinton County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Williams County",
                "Wood County",
                "Wyandot County"
            ],
            "OK" => [
                "Adair County",
                "Alfalfa County",
                "Atoka County",
                "Beaver County",
                "Beckham County",
                "Blaine County",
                "Bryan County",
                "Caddo County",
                "Canadian County",
                "Carter County",
                "Cherokee County",
                "Choctaw County",
                "Cimarron County",
                "Cleveland County",
                "Coal County",
                "Comanche County",
                "Cotton County",
                "Craig County",
                "Creek County",
                "Custer County",
                "Delaware County",
                "Dewey County",
                "Ellis County",
                "Garfield County",
                "Garvin County",
                "Grady County",
                "Grant County",
                "Greer County",
                "Harmon County",
                "Harper County",
                "Haskell County",
                "Hughes County",
                "Jackson County",
                "Jefferson County",
                "Johnston County",
                "Kay County",
                "Kingfisher County",
                "Kiowa County",
                "Latimer County",
                "Le Flore County",
                "Lincoln County",
                "Logan County",
                "Love County",
                "Major County",
                "Marshall County",
                "Mayes County",
                "McClain County",
                "McCurtain County",
                "McIntosh County",
                "Murray County",
                "Muskogee County",
                "Noble County",
                "Nowata County",
                "Okfuskee County",
                "Oklahoma County",
                "Okmulgee County",
                "Osage County",
                "Ottawa County",
                "Pawnee County",
                "Payne County",
                "Pittsburg County",
                "Pontotoc County",
                "Pottawatomie County",
                "Pushmataha County",
                "Roger Mills County",
                "Rogers County",
                "Seminole County",
                "Sequoyah County",
                "Stephens County",
                "Texas County",
                "Tillman County",
                "Tulsa County",
                "Wagoner County",
                "Washington County",
                "Washita County",
                "Woods County",
                "Woodward County"
            ],
            "OR" => [
                "Baker County",
                "Benton County",
                "Clackamas County",
                "Clatsop County",
                "Columbia County",
                "Coos County",
                "Crook County",
                "Curry County",
                "Deschutes County",
                "Douglas County",
                "Gilliam County",
                "Grant County",
                "Harney County",
                "Hood River County",
                "Jackson County",
                "Jefferson County",
                "Josephine County",
                "Klamath County",
                "Lake County",
                "Lane County",
                "Lincoln County",
                "Linn County",
                "Malheur County",
                "Marion County",
                "Morrow County",
                "Multnomah County",
                "Polk County",
                "Sherman County",
                "Tillamook County",
                "Umatilla County",
                "Union County",
                "Wallowa County",
                "Wasco County",
                "Washington County",
                "Wheeler County",
                "Yamhill County"
            ],
            "PA" => [
                "Adams County",
                "Allegheny County",
                "Armstrong County",
                "Beaver County",
                "Bedford County",
                "Berks County",
                "Blair County",
                "Bradford County",
                "Bucks County",
                "Butler County",
                "Cambria County",
                "Cameron County",
                "Carbon County",
                "Centre County",
                "Chester County",
                "Clarion County",
                "Clearfield County",
                "Clinton County",
                "Columbia County",
                "Crawford County",
                "Cumberland County",
                "Dauphin County",
                "Delaware County",
                "Elk County",
                "Erie County",
                "Fayette County",
                "Forest County",
                "Franklin County",
                "Fulton County",
                "Greene County",
                "Huntingdon County",
                "Indiana County",
                "Jefferson County",
                "Juniata County",
                "Lackawanna County",
                "Lancaster County",
                "Lawrence County",
                "Lebanon County",
                "Lehigh County",
                "Luzerne County",
                "Lycoming County",
                "McKean County",
                "Mercer County",
                "Mifflin County",
                "Monroe County",
                "Montgomery County",
                "Montour County",
                "Northampton County",
                "Northumberland County",
                "Perry County",
                "Philadelphia County",
                "Pike County",
                "Potter County",
                "Schuylkill County",
                "Snyder County",
                "Somerset County",
                "Sullivan County",
                "Susquehanna County",
                "Tioga County",
                "Union County",
                "Venango County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Westmoreland County",
                "Wyoming County",
                "York County"
            ],
            "RI" => [
                "Bristol County",
                "Kent County",
                "Newport County",
                "Providence County",
                "Washington County"
            ],
            "SC" => [
                "Abbeville County",
                "Aiken County",
                "Allendale County",
                "Anderson County",
                "Bamberg County",
                "Barnwell County",
                "Beaufort County",
                "Berkeley County",
                "Calhoun County",
                "Charleston County",
                "Cherokee County",
                "Chester County",
                "Chesterfield County",
                "Clarendon County",
                "Colleton County",
                "Darlington County",
                "Dillon County",
                "Dorchester County",
                "Edgefield County",
                "Fairfield County",
                "Florence County",
                "Georgetown County",
                "Greenville County",
                "Greenwood County",
                "Hampton County",
                "Horry County",
                "Jasper County",
                "Kershaw County",
                "Lancaster County",
                "Laurens County",
                "Lee County",
                "Lexington County",
                "Marion County",
                "Marlboro County",
                "McCormick County",
                "Newberry County",
                "Oconee County",
                "Orangeburg County",
                "Pickens County",
                "Richland County",
                "Saluda County",
                "Spartanburg County",
                "Sumter County",
                "Union County",
                "Williamsburg County",
                "York County"
            ],
            "SD" => [
                "Aurora County",
                "Beadle County",
                "Bennett County",
                "Bon Homme County",
                "Brookings County",
                "Brown County",
                "Brule County",
                "Buffalo County",
                "Butte County",
                "Campbell County",
                "Charles Mix County",
                "Clark County",
                "Clay County",
                "Codington County",
                "Corson County",
                "Custer County",
                "Davison County",
                "Day County",
                "Deuel County",
                "Dewey County",
                "Douglas County",
                "Edmunds County",
                "Fall River County",
                "Faulk County",
                "Grant County",
                "Gregory County",
                "Haakon County",
                "Hamlin County",
                "Hand County",
                "Hanson County",
                "Harding County",
                "Hughes County",
                "Hutchinson County",
                "Hyde County",
                "Jackson County",
                "Jerauld County",
                "Jones County",
                "Kingsbury County",
                "Lake County",
                "Lawrence County",
                "Lincoln County",
                "Lyman County",
                "Marshall County",
                "McCook County",
                "McPherson County",
                "Meade County",
                "Mellette County",
                "Miner County",
                "Minnehaha County",
                "Moody County",
                "Pennington County",
                "Perkins County",
                "Potter County",
                "Roberts County",
                "Sanborn County",
                "Shannon County",
                "Spink County",
                "Stanley County",
                "Sully County",
                "Todd County",
                "Tripp County",
                "Turner County",
                "Union County",
                "Walworth County",
                "Yankton County",
                "Ziebach County"
            ],
            "TN" => [
                "Anderson County",
                "Bedford County",
                "Benton County",
                "Bledsoe County",
                "Blount County",
                "Bradley County",
                "Campbell County",
                "Cannon County",
                "Carroll County",
                "Carter County",
                "Cheatham County",
                "Chester County",
                "Claiborne County",
                "Clay County",
                "Cocke County",
                "Coffee County",
                "Crockett County",
                "Cumberland County",
                "Davidson County",
                "Decatur County",
                "DeKalb County",
                "Dickson County",
                "Dyer County",
                "Fayette County",
                "Fentress County",
                "Franklin County",
                "Gibson County",
                "Giles County",
                "Grainger County",
                "Greene County",
                "Grundy County",
                "Hamblen County",
                "Hamilton County",
                "Hancock County",
                "Hardeman County",
                "Hardin County",
                "Hawkins County",
                "Haywood County",
                "Henderson County",
                "Henry County",
                "Hickman County",
                "Houston County",
                "Humphreys County",
                "Jackson County",
                "Jefferson County",
                "Johnson County",
                "Knox County",
                "Lake County",
                "Lauderdale County",
                "Lawrence County",
                "Lewis County",
                "Lincoln County",
                "Loudon County",
                "Macon County",
                "Madison County",
                "Marion County",
                "Marshall County",
                "Maury County",
                "McMinn County",
                "McNairy County",
                "Meigs County",
                "Monroe County",
                "Montgomery County",
                "Moore County",
                "Morgan County",
                "Obion County",
                "Overton County",
                "Perry County",
                "Pickett County",
                "Polk County",
                "Putnam County",
                "Rhea County",
                "Roane County",
                "Robertson County",
                "Rutherford County",
                "Scott County",
                "Sequatchie County",
                "Sevier County",
                "Shelby County",
                "Smith County",
                "Stewart County",
                "Sullivan County",
                "Sumner County",
                "Tipton County",
                "Trousdale County",
                "Unicoi County",
                "Union County",
                "Van Buren County",
                "Warren County",
                "Washington County",
                "Wayne County",
                "Weakley County",
                "White County",
                "Williamson County",
                "Wilson County"
            ],
            "TX" => [
                "Anderson County",
                "Andrews County",
                "Angelina County",
                "Aransas County",
                "Archer County",
                "Armstrong County",
                "Atascosa County",
                "Austin County",
                "Bailey County",
                "Bandera County",
                "Bastrop County",
                "Baylor County",
                "Bee County",
                "Bell County",
                "Bexar County",
                "Blanco County",
                "Borden County",
                "Bosque County",
                "Bowie County",
                "Brazoria County",
                "Brazos County",
                "Brewster County",
                "Briscoe County",
                "Brooks County",
                "Brown County",
                "Burleson County",
                "Burnet County",
                "Caldwell County",
                "Calhoun County",
                "Callahan County",
                "Cameron County",
                "Camp County",
                "Carson County",
                "Cass County",
                "Castro County",
                "Chambers County",
                "Cherokee County",
                "Childress County",
                "Clay County",
                "Cochran County",
                "Coke County",
                "Coleman County",
                "Collin County",
                "Collingsworth County",
                "Colorado County",
                "Comal County",
                "Comanche County",
                "Concho County",
                "Cooke County",
                "Coryell County",
                "Cottle County",
                "Crane County",
                "Crockett County",
                "Crosby County",
                "Culberson County",
                "Dallam County",
                "Dallas County",
                "Dawson County",
                "Deaf Smith County",
                "Delta County",
                "Denton County",
                "DeWitt County",
                "Dickens County",
                "Dimmit County",
                "Donley County",
                "Duval County",
                "Eastland County",
                "Ector County",
                "Edwards County",
                "El Paso County",
                "Ellis County",
                "Erath County",
                "Falls County",
                "Fannin County",
                "Fayette County",
                "Fisher County",
                "Floyd County",
                "Foard County",
                "Fort Bend County",
                "Franklin County",
                "Freestone County",
                "Frio County",
                "Gaines County",
                "Galveston County",
                "Garza County",
                "Gillespie County",
                "Glasscock County",
                "Goliad County",
                "Gonzales County",
                "Gray County",
                "Grayson County",
                "Gregg County",
                "Grimes County",
                "Guadalupe County",
                "Hale County",
                "Hall County",
                "Hamilton County",
                "Hansford County",
                "Hardeman County",
                "Hardin County",
                "Harris County",
                "Harrison County",
                "Hartley County",
                "Haskell County",
                "Hays County",
                "Hemphill County",
                "Henderson County",
                "Hidalgo County",
                "Hill County",
                "Hockley County",
                "Hood County",
                "Hopkins County",
                "Houston County",
                "Howard County",
                "Hudspeth County",
                "Hunt County",
                "Hutchinson County",
                "Irion County",
                "Jack County",
                "Jackson County",
                "Jasper County",
                "Jeff Davis County",
                "Jefferson County",
                "Jim Hogg County",
                "Jim Wells County",
                "Johnson County",
                "Jones County",
                "Karnes County",
                "Kaufman County",
                "Kendall County",
                "Kenedy County",
                "Kent County",
                "Kerr County",
                "Kimble County",
                "King County",
                "Kinney County",
                "Kleberg County",
                "Knox County",
                "La Salle County",
                "Lamar County",
                "Lamb County",
                "Lampasas County",
                "Lavaca County",
                "Lee County",
                "Leon County",
                "Liberty County",
                "Limestone County",
                "Lipscomb County",
                "Live Oak County",
                "Llano County",
                "Loving County",
                "Lubbock County",
                "Lynn County",
                "Madison County",
                "Marion County",
                "Martin County",
                "Mason County",
                "Matagorda County",
                "Maverick County",
                "McCulloch County",
                "McLennan County",
                "McMullen County",
                "Medina County",
                "Menard County",
                "Midland County",
                "Milam County",
                "Mills County",
                "Mitchell County",
                "Montague County",
                "Montgomery County",
                "Moore County",
                "Morris County",
                "Motley County",
                "Nacogdoches County",
                "Navarro County",
                "Newton County",
                "Nolan County",
                "Nueces County",
                "Ochiltree County",
                "Oldham County",
                "Orange County",
                "Palo Pinto County",
                "Panola County",
                "Parker County",
                "Parmer County",
                "Pecos County",
                "Polk County",
                "Potter County",
                "Presidio County",
                "Rains County",
                "Randall County",
                "Reagan County",
                "Real County",
                "Red River County",
                "Reeves County",
                "Refugio County",
                "Roberts County",
                "Robertson County",
                "Rockwall County",
                "Runnels County",
                "Rusk County",
                "Sabine County",
                "San Augustine County",
                "San Jacinto County",
                "San Patricio County",
                "San Saba County",
                "Schleicher County",
                "Scurry County",
                "Shackelford County",
                "Shelby County",
                "Sherman County",
                "Smith County",
                "Somervell County",
                "Starr County",
                "Stephens County",
                "Sterling County",
                "Stonewall County",
                "Sutton County",
                "Swisher County",
                "Tarrant County",
                "Taylor County",
                "Terrell County",
                "Terry County",
                "Throckmorton County",
                "Titus County",
                "Tom Green County",
                "Travis County",
                "Trinity County",
                "Tyler County",
                "Upshur County",
                "Upton County",
                "Uvalde County",
                "Val Verde County",
                "Van Zandt County",
                "Victoria County",
                "Walker County",
                "Waller County",
                "Ward County",
                "Washington County",
                "Webb County",
                "Wharton County",
                "Wheeler County",
                "Wichita County",
                "Wilbarger County",
                "Willacy County",
                "Williamson County",
                "Wilson County",
                "Winkler County",
                "Wise County",
                "Wood County",
                "Yoakum County",
                "Young County",
                "Zapata County",
                "Zavala County"
            ],
            "UT" => [
                "Beaver County",
                "Box Elder County",
                "Cache County",
                "Carbon County",
                "Daggett County",
                "Davis County",
                "Duchesne County",
                "Emery County",
                "Garfield County",
                "Grand County",
                "Iron County",
                "Juab County",
                "Kane County",
                "Millard County",
                "Morgan County",
                "Piute County",
                "Rich County",
                "Salt Lake County",
                "San Juan County",
                "Sanpete County",
                "Sevier County",
                "Summit County",
                "Tooele County",
                "Uintah County",
                "Utah County",
                "Wasatch County",
                "Washington County",
                "Wayne County",
                "Weber County"
            ],
            "VT" => [
                "Addison County",
                "Bennington County",
                "Caledonia County",
                "Chittenden County",
                "Essex County",
                "Franklin County",
                "Grand Isle County",
                "Lamoille County",
                "Orange County",
                "Orleans County",
                "Rutland County",
                "Washington County",
                "Windham County",
                "Windsor County"
            ],
            "VA" => [
                "Accomack County",
                "Albemarle County",
                "Alleghany County",
                "Amelia County",
                "Amherst County",
                "Appomattox County",
                "Arlington County",
                "Augusta County",
                "Bath County",
                "Bedford County",
                "Bland County",
                "Botetourt County",
                "Brunswick County",
                "Buchanan County",
                "Buckingham County",
                "Campbell County",
                "Caroline County",
                "Carroll County",
                "Charles City County",
                "Charlotte County",
                "Chesterfield County",
                "Clarke County",
                "Craig County",
                "Culpeper County",
                "Cumberland County",
                "Dickenson County",
                "Dinwiddie County",
                "Essex County",
                "Fairfax County",
                "Fauquier County",
                "Floyd County",
                "Fluvanna County",
                "Franklin County",
                "Frederick County",
                "Giles County",
                "Gloucester County",
                "Goochland County",
                "Grayson County",
                "Greene County",
                "Greensville County",
                "Halifax County",
                "Hanover County",
                "Henrico County",
                "Henry County",
                "Highland County",
                "Isle of Wight County",
                "James City County",
                "King and Queen County",
                "King George County",
                "King William County",
                "Lancaster County",
                "Lee County",
                "Loudoun County",
                "Louisa County",
                "Lunenburg County",
                "Madison County",
                "Mathews County",
                "Mecklenburg County",
                "Middlesex County",
                "Montgomery County",
                "Nelson County",
                "New Kent County",
                "Northampton County",
                "Northumberland County",
                "Nottoway County",
                "Orange County",
                "Page County",
                "Patrick County",
                "Pittsylvania County",
                "Powhatan County",
                "Prince Edward County",
                "Prince George County",
                "Prince William County",
                "Pulaski County",
                "Rappahannock County",
                "Richmond County",
                "Roanoke County",
                "Rockbridge County",
                "Rockingham County",
                "Russell County",
                "Scott County",
                "Shenandoah County",
                "Smyth County",
                "Southampton County",
                "Spotsylvania County",
                "Stafford County",
                "Surry County",
                "Sussex County",
                "Tazewell County",
                "Warren County",
                "Washington County",
                "Westmoreland County",
                "Wise County",
                "Wythe County",
                "York County"
            ],
            "WA" => [
                "Adams County",
                "Asotin County",
                "Benton County",
                "Chelan County",
                "Clallam County",
                "Clark County",
                "Columbia County",
                "Cowlitz County",
                "Douglas County",
                "Ferry County",
                "Franklin County",
                "Garfield County",
                "Grant County",
                "Grays Harbor County",
                "Island County",
                "Jefferson County",
                "King County",
                "Kitsap County",
                "Kittitas County",
                "Klickitat County",
                "Lewis County",
                "Lincoln County",
                "Mason County",
                "Okanogan County",
                "Pacific County",
                "Pend Oreille County",
                "Pierce County",
                "San Juan County",
                "Skagit County",
                "Skamania County",
                "Snohomish County",
                "Spokane County",
                "Stevens County",
                "Thurston County",
                "Wahkiakum County",
                "Walla Walla County",
                "Whatcom County",
                "Whitman County",
                "Yakima County"
            ],
            "WV" => [
                "Barbour County",
                "Berkeley County",
                "Boone County",
                "Braxton County",
                "Brooke County",
                "Cabell County",
                "Calhoun County",
                "Clay County",
                "Doddridge County",
                "Fayette County",
                "Gilmer County",
                "Grant County",
                "Greenbrier County",
                "Hampshire County",
                "Hancock County",
                "Hardy County",
                "Harrison County",
                "Jackson County",
                "Jefferson County",
                "Kanawha County",
                "Lewis County",
                "Lincoln County",
                "Logan County",
                "Marion County",
                "Marshall County",
                "Mason County",
                "McDowell County",
                "Mercer County",
                "Mineral County",
                "Mingo County",
                "Monongalia County",
                "Monroe County",
                "Morgan County",
                "Nicholas County",
                "Ohio County",
                "Pendleton County",
                "Pleasants County",
                "Pocahontas County",
                "Preston County",
                "Putnam County",
                "Raleigh County",
                "Randolph County",
                "Ritchie County",
                "Roane County",
                "Summers County",
                "Taylor County",
                "Tucker County",
                "Tyler County",
                "Upshur County",
                "Wayne County",
                "Webster County",
                "Wetzel County",
                "Wirt County",
                "Wood County",
                "Wyoming County"
            ],
            "WI" => [
                "Adams County",
                "Ashland County",
                "Barron County",
                "Bayfield County",
                "Brown County",
                "Buffalo County",
                "Burnett County",
                "Calumet County",
                "Chippewa County",
                "Clark County",
                "Columbia County",
                "Crawford County",
                "Dane County",
                "Dodge County",
                "Door County",
                "Douglas County",
                "Dunn County",
                "Eau Claire County",
                "Florence County",
                "Fond du Lac County",
                "Forest County",
                "Grant County",
                "Green County",
                "Green Lake County",
                "Iowa County",
                "Iron County",
                "Jackson County",
                "Jefferson County",
                "Juneau County",
                "Kenosha County",
                "Kewaunee County",
                "La Crosse County",
                "Lafayette County",
                "Langlade County",
                "Lincoln County",
                "Manitowoc County",
                "Marathon County",
                "Marinette County",
                "Marquette County",
                "Menominee County",
                "Milwaukee County",
                "Monroe County",
                "Oconto County",
                "Oneida County",
                "Outagamie County",
                "Ozaukee County",
                "Pepin County",
                "Pierce County",
                "Polk County",
                "Portage County",
                "Price County",
                "Racine County",
                "Richland County",
                "Rock County",
                "Rusk County",
                "Sauk County",
                "Sawyer County",
                "Shawano County",
                "Sheboygan County",
                "St. Croix County",
                "Taylor County",
                "Trempealeau County",
                "Vernon County",
                "Vilas County",
                "Walworth County",
                "Washburn County",
                "Washington County",
                "Waukesha County",
                "Waupaca County",
                "Waushara County",
                "Winnebago County",
                "Wood County"
            ],
            "WY" => [
                "Albany County",
                "Big Horn County",
                "Campbell County",
                "Carbon County",
                "Converse County",
                "Crook County",
                "Fremont County",
                "Goshen County",
                "Hot Springs County",
                "Johnson County",
                "Laramie County",
                "Lincoln County",
                "Natrona County",
                "Niobrara County",
                "Park County",
                "Platte County",
                "Sheridan County",
                "Sublette County",
                "Sweetwater County",
                "Teton County",
                "Uinta County",
                "Washakie County",
                "Weston County"
            ]
        ];
    }

    public static function GetStateByZip($zipString): array
    {
        $data = [
            'abbr' => '',
            'name' => ''
        ];

        $zip_regex = "/^[0-9]{5}(?:-[0-9]{4})?$/";
        if (preg_match($zip_regex, $zipString)) {
            $zipcode = intval($zipString);

            if ($zipcode >= 35000 && $zipcode <= 36999) {
                $data['abbr'] = 'AL';
                $data['name'] = 'Alabama';
            } elseif ($zipcode >= 99500 && $zipcode <= 99999) {
                $data['abbr'] = 'AK';
                $data['name'] = 'Alaska';
            } elseif ($zipcode >= 85000 && $zipcode <= 86999) {
                $data['abbr'] = 'AZ';
                $data['name'] = 'Arizona';
            } elseif ($zipcode >= 71600 && $zipcode <= 72999) {
                $data['abbr'] = 'AR';
                $data['name'] = 'Arkansas';
            } elseif ($zipcode >= 90000 && $zipcode <= 96699) {
                $data['abbr'] = 'CA';
                $data['name'] = 'California';
            } elseif ($zipcode >= 80000 && $zipcode <= 81999) {
                $data['abbr'] = 'CO';
                $data['name'] = 'Colorado';
            } elseif (($zipcode >= 6000 && $zipcode <= 6389) || ($zipcode >= 6391 && $zipcode <= 6999)) {
                $data['abbr'] = 'CT';
                $data['name'] = 'Connecticut';
            } elseif ($zipcode >= 19700 && $zipcode <= 19999) {
                $data['abbr'] = 'DE';
                $data['name'] = 'Delaware';
            } elseif ($zipcode >= 32000 && $zipcode <= 34999) {
                $data['abbr'] = 'FL';
                $data['name'] = 'Florida';
            } elseif (($zipcode >= 30000 && $zipcode <= 31999) || ($zipcode >= 39800 && $zipcode <= 39999)) {
                $data['abbr'] = 'GA';
                $data['name'] = 'Georgia';
            } elseif ($zipcode >= 96700 && $zipcode <= 96999) {
                $data['abbr'] = 'HI';
                $data['name'] = 'Hawaii';
            } elseif ($zipcode >= 83200 && $zipcode <= 83999) {
                $data['abbr'] = 'ID';
                $data['name'] = 'Idaho';
            } elseif ($zipcode >= 60000 && $zipcode <= 62999) {
                $data['abbr'] = 'IL';
                $data['name'] = 'Illinois';
            } elseif ($zipcode >= 46000 && $zipcode <= 47999) {
                $data['abbr'] = 'IN';
                $data['name'] = 'Indiana';
            } elseif ($zipcode >= 50000 && $zipcode <= 52999) {
                $data['abbr'] = 'IA';
                $data['name'] = 'Iowa';
            } elseif ($zipcode >= 66000 && $zipcode <= 67999) {
                $data['abbr'] = 'KS';
                $data['name'] = 'Kansas';
            } elseif ($zipcode >= 40000 && $zipcode <= 42999) {
                $data['abbr'] = 'KY';
                $data['name'] = 'Kentucky';
            } elseif ($zipcode >= 70000 && $zipcode <= 71599) {
                $data['abbr'] = 'LA';
                $data['name'] = 'Louisiana';
            } elseif ($zipcode >= 3900 && $zipcode <= 4999) {
                $data['abbr'] = 'ME';
                $data['name'] = 'Maine';
            } elseif ($zipcode >= 20600 && $zipcode <= 21999) {
                $data['abbr'] = 'MD';
                $data['name'] = 'Maryland';
            } elseif (($zipcode >= 1000 && $zipcode <= 2799) || ($zipcode == 5501) || ($zipcode == 5544)) {
                $data['abbr'] = 'MA';
                $data['name'] = 'Massachusetts';
            } elseif ($zipcode >= 48000 && $zipcode <= 49999) {
                $data['abbr'] = 'MI';
                $data['name'] = 'Michigan';
            } elseif ($zipcode >= 55000 && $zipcode <= 56899) {
                $data['abbr'] = 'MN';
                $data['name'] = 'Minnesota';
            } elseif ($zipcode >= 38600 && $zipcode <= 39999) {
                $data['abbr'] = 'MS';
                $data['name'] = 'Mississippi';
            } elseif ($zipcode >= 63000 && $zipcode <= 65999) {
                $data['abbr'] = 'MO';
                $data['name'] = 'Missouri';
            } elseif ($zipcode >= 59000 && $zipcode <= 59999) {
                $data['abbr'] = 'MT';
                $data['name'] = 'Montana';
            } elseif ($zipcode >= 27000 && $zipcode <= 28999) {
                $data['abbr'] = 'NC';
                $data['name'] = 'North Carolina';
            } elseif ($zipcode >= 58000 && $zipcode <= 58999) {
                $data['abbr'] = 'ND';
                $data['name'] = 'North Dakota';
            } elseif ($zipcode >= 68000 && $zipcode <= 69999) {
                $data['abbr'] = 'NE';
                $data['name'] = 'Nebraska';
            } elseif ($zipcode >= 88900 && $zipcode <= 89999) {
                $data['abbr'] = 'NV';
                $data['name'] = 'Nevada';
            } elseif ($zipcode >= 3000 && $zipcode <= 3899) {
                $data['abbr'] = 'NH';
                $data['name'] = 'New Hampshire';
            } elseif ($zipcode >= 7000 && $zipcode <= 8999) {
                $data['abbr'] = 'NJ';
                $data['name'] = 'New Jersey';
            } elseif ($zipcode >= 87000 && $zipcode <= 88499) {
                $data['abbr'] = 'NM';
                $data['name'] = 'New Mexico';
            } elseif (($zipcode >= 10000 && $zipcode <= 14999) || ($zipcode == 6390) || ($zipcode == 501) || ($zipcode == 544)) {
                $data['abbr'] = 'NY';
                $data['name'] = 'New York';
            } elseif ($zipcode >= 43000 && $zipcode <= 45999) {
                $data['abbr'] = 'OH';
                $data['name'] = 'Ohio';
            } elseif (($zipcode >= 73000 && $zipcode <= 73199) || ($zipcode >= 73400 && $zipcode <= 74999)) {
                $data['abbr'] = 'OK';
                $data['name'] = 'Oklahoma';
            } elseif ($zipcode >= 97000 && $zipcode <= 97999) {
                $data['abbr'] = 'OR';
                $data['name'] = 'Oregon';
            } elseif ($zipcode >= 15000 && $zipcode <= 19699) {
                $data['abbr'] = 'PA';
                $data['name'] = 'Pennsylvania';
            } elseif ($zipcode >= 300 && $zipcode <= 999) {
                $data['abbr'] = 'PR';
                $data['name'] = 'Puerto Rico';
            } elseif ($zipcode >= 2800 && $zipcode <= 2999) {
                $data['abbr'] = 'RI';
                $data['name'] = 'Rhode Island';
            } elseif ($zipcode >= 29000 && $zipcode <= 29999) {
                $data['abbr'] = 'SC';
                $data['name'] = 'South Carolina';
            } elseif ($zipcode >= 57000 && $zipcode <= 57999) {
                $data['abbr'] = 'SD';
                $data['name'] = 'South Dakota';
            } elseif ($zipcode >= 37000 && $zipcode <= 38599) {
                $data['abbr'] = 'TN';
                $data['name'] = 'Tennessee';
            } elseif (($zipcode >= 75000 && $zipcode <= 79999) || ($zipcode >= 73301 && $zipcode <= 73399) || ($zipcode >= 88500 && $zipcode <= 88599)) {
                $data['abbr'] = 'TX';
                $data['name'] = 'Texas';
            } elseif ($zipcode >= 84000 && $zipcode <= 84999) {
                $data['abbr'] = 'UT';
                $data['name'] = 'Utah';
            } elseif ($zipcode >= 5000 && $zipcode <= 5999) {
                $data['abbr'] = 'VT';
                $data['name'] = 'Vermont';
            } elseif (($zipcode >= 20100 && $zipcode <= 20199) || ($zipcode >= 22000 && $zipcode <= 24699) || ($zipcode == 20598)) {
                $data['abbr'] = 'VA';
                $data['name'] = 'Virginia';
            } elseif (($zipcode >= 20000 && $zipcode <= 20099) || ($zipcode >= 20200 && $zipcode <= 20599) || ($zipcode >= 56900 && $zipcode <= 56999)) {
                $data['abbr'] = 'DC';
                $data['name'] = 'Washington DC';
            } elseif ($zipcode >= 98000 && $zipcode <= 99499) {
                $data['abbr'] = 'WA';
                $data['name'] = 'Washington';
            } elseif ($zipcode >= 24700 && $zipcode <= 26999) {
                $data['abbr'] = 'WV';
                $data['name'] = 'West Virginia';
            } elseif ($zipcode >= 53000 && $zipcode <= 54999) {
                $data['abbr'] = 'WI';
                $data['name'] = 'Wisconsin';
            } elseif ($zipcode >= 82000 && $zipcode <= 83199) {
                $data['abbr'] = 'WY';
                $data['name'] = 'Wyoming';
            } else {
                $data['abbr'] = '';
                $data['name'] = '';
            }
        }

        return $data;
    }

    //State array as select options
    public static function CountyOptions($val = ""): string
    {
        $states = ResourceNavigatorUtilityBase::StateArray();
        $rtn    = '';
        foreach ($states as $abbr => $name) {
            $rtn .= '<option value="' . $abbr . '" ' . ($val == $abbr ? ' selected="selected"' : '') . '>' . $name . '</option>';
        }

        return $rtn;
    }

    /**
     * Returns a state as a string
     *
     * @param array $inValue
     * @param bool $useAbbr
     *
     * @return string
     */
    public static function ReturnStateSelect(array $inValue = array(), bool $useAbbr = true): string
    {
        if ( ! is_array($inValue)) {
            $inValue = array($inValue);
        }

        $tmpSelect = '';
        $tmpArray  = self::StateArray();

        foreach ($tmpArray as $key => $value) {
            $tmpSelect .= '<option value="' . $key . '" ';
            if (in_array($key, $inValue)) {
                $tmpSelect .= 'selected';
            }
            $tmpSelect .= '>';
            if ($useAbbr == false) {
                $tmpSelect .= $value;
            } else {
                $tmpSelect .= $key;
            }
            $tmpSelect .= '</option>' . "\n";
        }
        unset($tmpArray);

        return $tmpSelect;
    }

    /**
     * Return the parent page's slug. If no id is passed, null is returned
     *
     * @param int $parent_id
     *
     * @return string $post_name
     */
    public static function GetTheParentSlug(int $parent_id = 0): string
    {
        if ($parent_id == 0) {
            global $post;
            if ($post->post_parent == 0) {
                return '';
            }
        }
        $post_data = get_post($parent_id);

        return $post_data->post_name;
    }

    /**
     * Prints the parent page's slug. If no id is passed, null is returned
     *
     * @param int $parent_id
     */
    public static function TheParentSlug(int $parent_id = 0)
    {
        print self::GetTheParentSlug($parent_id);
    }





    // ************** //

    /**
     * Reads contents of icomoon.css and outputs an option list of different icons.
     *
     * @param string $default - selected option
     * @param string $match - regex to match against
     *
     * @return string $rtn - options
     */
    public static function IconSelect(string $default = "", string $match = '/(\.icon-.*?):/'): string
    {
        $rtn   = "";
        $input = file_get_contents(get_template_directory() . '/css/icomoon.css');

        preg_match_all($match, $input, $matches);

        foreach ($matches[1] as $class) {
            $class = str_replace(".", "", $class);
            $rtn   .= '<option value="' . $class . '" ' . (($class == $default) ? 'selected' : '') . ' >' . $class . '</option>';
        }

        return $rtn;
    }

    /**
     * Return the options of a select list for each increment between 2 numbers.
     *
     * @param string $default - selected option
     * @param int $start - beginning number
     * @param int $end - ending number
     * @param float $increment - number to increase by per iteration
     *
     * @return string - options
     */
    public static function IncrementOptions(string $default = "", int $start = 0, int $end = 5, float $increment = 0.5): string
    {
        $current = $start;
        $rtn     = "";
        while ($current <= $end) {
            $rtn .= '<option value="' . $current . '" ' . ($default == $current ? 'selected' : '') . ' >' . $current . '</option>';

            $current += $increment;
        }

        return $rtn;
    }

    /**
     * Return the lat long of an address as array. If no address passed, empty array is returned
     *
     * @param string $address - URL Encoded string of address
     *
     * @return array - Lat Long Array
     */
    public static function GetLatLongFromAddress(string $address = ""): array
    {
        $rtn = array();
        if ($address == "") {
            return $rtn;
        }
        $geocode     = file_get_contents('https://maps.google.com/maps/api/geocode/json?address=' . $address . '&sensor=false');
        $output      = json_decode($geocode);
        $rtn['lat']  = $output->results[0]->geometry->location->lat;
        $rtn['long'] = $output->results[0]->geometry->location->lng;

        return $rtn;
    }

    /**
     * Return current IP address
     *
     * @return string
     */
    public static function GetIP(): string
    {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip) {
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }

        return '';
    }

    /**
     * Return true if a page has children and false if it doesnt
     *
     * @param string $id - id of the post being checked
     *
     * @return bool
     */
    public static function GetHasChildren(string $id): bool
    {
        $children = get_pages(array('child_of' => $id));
        if (count($children) == 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Prints the transient image url.
     *
     * @param $url
     */
    public static function TransientImage($url)
    {
        print self::GetTransientImage($url);
    }

    /**
     * Get the transient image url.
     *
     * @param $url
     *
     * @return  string
     */
    public static function GetTransientImage($url): ?string
    {
        $id = base64_encode($url);
        // Get any existing copy of our transient data
        if (false === ($special_query_results = get_transient($id))) {
            // It wasn't there, so regenerate the data and save the transient
            $special_query_results = null;
            $resource              = fopen(ABSPATH . str_replace(get_bloginfo('url') . '/', '', $url), 'r');
            while ( ! feof($resource)) {
                $special_query_results .= fread($resource, 4096);
            }
            set_transient('special_query_results', $special_query_results, 36 * HOUR_IN_SECONDS);
        }

        return $special_query_results;
    }

    // ************** //

    /**
     * Prepends and prints the resource navigator plugin asset directory to the passed path.
     *
     * @param $path - Path to prepend. Include beginning slash
     */
    public static function Asset($path)
    {
        print (self::GetAsset($path));
    }

    /**
     * Prepends and returns the resource navigator plugin asset directory to the passed path.
     *
     * @param $path - Path to prepend. Include beginning slash
     *
     * @return string -- Full path of asset
     */
    public static function GetAsset($path): string
    {
        return plugins_url('resource-navigator/inc/sourcelink/assets/' . $path);
    }


    /**
     * Prepends and returns the resource navigator plugin asset directory to the passed path.
     *
     * @param $path - Path to prepend. Include beginning slash
     *
     * @return string -- Full path of asset
     */
    public static function GetAssetURI($path): string
    {
        return plugin_dir_path(__DIR__) . 'assets/' . $path;
    }



    // ************** //
    // ************** //


    /**
     * GetPostProperties
     *
     * @param WP_Post|null $the_post WP_Post - post object to fetch data for
     * @param $static_class string|PostBase - String name of class
     *
     * @return null|array
     */
    public static function GetPostProperties(WP_Post $the_post = null, string $static_class = ''): ?array
    {
        if ($the_post == null || $static_class == "") {
            return null;
        }

        //Image info
        $image_id = get_post_thumbnail_id($the_post->ID);
        $image    = wp_get_attachment_image_src($image_id, 'full');
        if (is_array($image)) {
            $image = $image[0];
        }
        if ($the_post->post_type != "post") {
            $rtn = array_merge($the_post->to_array(), $static_class::MetaValues($the_post->ID));
        } else {
            $rtn  = $the_post->to_array();
            $meta = get_post_meta($the_post->ID, '', true);
            foreach ($meta as $meta_key => $meta_val) {
                $true_name = explode("_", $meta_key, 3);

                if ($true_name[0] == "post" && $true_name[1] == "meta") {
                    $rtn['meta'][$true_name[2]] = $meta_val[0];
                }
            }
        }
        $rtn['image']    = $image;
        $rtn['image_id'] = $image_id;
        $rtn['link_url'] = get_the_permalink($the_post->ID);

        $taxonomy_objects = get_object_taxonomies($the_post->post_type, 'names');
        $rtn['terms']     = [];
        foreach (wp_get_post_terms($the_post->ID, $taxonomy_objects) as $eachTerm) {
            $rtn['terms'][$eachTerm->taxonomy][] = $eachTerm;
        }

        return $rtn;
    }

    public static function CurrentUserHasRole($role): bool
    {
        $user = get_userdata(get_current_user_id());
        if ( ! $user || ! $user->roles) {
            return false;
        }

        if (is_array($role)) {
            return (bool)array_intersect($role, (array)$user->roles);
        }

        return in_array($role, (array)$user->roles);
    }

    public static function GetExtensionForFileType($ext): string
    {
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/gif'  => 'gif',
            'image/png'  => 'png'
        ];

        return $allowed[$ext] ?? '';
    }

    public static function ParseConditionalQuery(string $querys): array
    {
        $result = [];
        parse_str($querys, $result);
        $rtn = [];
        foreach ($result as $index => $item) {
            $rtn[][$index][] = $item;
        }

        return $rtn;

    }

    public static function TranslateES($string)
    {
        $translations = [
            "You cannot view the post resource." => "No puede ver el recurso de publicación.",
            "Settings"                           => "Ajustes",
            "SourceLink Web Form" => "Formulario web de SourceLink",
            "Content" => "Contenido",
            "Web Form" => "Formulario",
            "App Settings" => "Ajustes de la aplicación",
            "Dev Tools" => "Herramientas de desarrollo",
            "Need Help?" => "¿Necesitas ayuda?",
            "SourceLink"                  => "SourceLink",
            "Select the web form to use." => "Seleccione el formulario web que desea utilizar.",
            "Organization Name" => "Nombre de la organización",
            "Organization Name 2" => "Nombre de la organización 2",
            "Contact Information" => "Información de contacto",
            "First Name"          => "Nombre",
            "Last Name" => "Apellido",
            "Business Phone" => "Teléfono del negocio",
            "Phone" => "Teléfono",
            "Ext" => "Extensión",
            "Fax" => "Faxear",
            "Email" => "Correo electrónico",
            "Location" => "Ubicación",
            "Address Line 1" => "Dirección línea 1",
            "Address Line 2" => "Dirección línea 2",
            "City" => "Ciudad",
            "State" => "Estado",
            "Zip" => "CP",
            "On The Web" => "En la Web",
            "Website" => "Sitio web",
            "Organization Facebook Page" => "Página de Facebook de la organización",
            "Organization Twitter Page" => "Página de Twitter de la organización",
            "Organization LinkedIn Page" => "Página de LinkedIn de la organización",
            "Organization Instagram Page" => "Página de Instagram de la organización",
            "Quick Description" => "Descripción rápida",
            "Your quick description will be displayed in the directory listing." => "Su descripción rápida se mostrará en la lista del directorio.",
            "characters remaining" => "caracteres restantes",
            "Full Description" => "Descripción completa",
            "Your full description will be displayed on your profile page." => "Su descripción completa se mostrará en su página de perfil.",
            "Logo" => "Logo",
            "Logo restrictions: the image must be a jpeg, gif or png and no larger than 1mb in size." => "Restricciones del logotipo: la imagen debe ser jpeg, gif o png y no mayor de 1mb de tamaño.",
            "Overview" => "Resumen",
            "Example" => "Ejemplo",
            "Support" => "Soporte",
            "Specialize" => "Especializarse",
            "Description" => "Descripción",
            "Offer" => "Oferta",
            "Your organization provides this option" => "Su organización ofrece esta opción",
            "Your organization specializes in providing this option" => "Su organización se especializa en proporcionar esta opción",
            "Your organization does not provide this option" => "Su organización no proporciona esta opción",
            "Which of these is the primary %s served?" => "¿Cuál de estos es el %s principal al que se sirve?",
            "Services You Offer" => "Servicios que ofreces",
            "Provide Service" => "Proporcionar servicio",
            "Specialize in Service" => "Especializarse en Servicio",
            "Service" => "Servicio",
            "I understand that the information I have provided will be used both online and in print form to help area entrepreneurs find my organization's services." => "Entiendo que la información que he proporcionado se utilizará tanto en línea como en forma impresa para ayudar a los empresarios del área a encontrar los servicios de mi organización.",
            "Submit My Profile" => "Enviar mi perfil",
            "Resource Navigator" => "Navegador de recursos",
            "Enables Resource Navigator Forms and Functionality" => "Habilita los formularios y la funcionalidad del Explorador de recursos",
            "Propaganda3" => "Propaganda3",
            "Zip Code or City, State" => "Código postal o ciudad, estado",
            "Area of Assistance" => "Área de asistencia",
            "Specific Need" => "Necesidad específica",
            "Keyword" => "Palabra clave",
            "Distance (in miles)" => "Distancia (en millas)",
            "County (sublist from state)" => "Condado (sublista del estado)",
            "-- Select --" => "-- Seleccionar --",
            "Select" => "Seleccionar",
            "Select State" => "Seleccionar Estado",
            "mile radius" => "Millas a la redonda",
            "Sort" => "Ordenar",
            "Provider Name (A-Z)" => "Nombre del proveedor (A-Z)",
            "Provider Name (Z-A)" => "Nombre del proveedor (Z-A)",
            "Distance (closest first)" => "Distancia (más cercana primero)",
            "List View" => "Vista de lista",
            "Map View" => "Vista de Mapa",
            "items in" => "elementos en",
            "page(s)" => "páginas",
            "Miles" => "Millas",
            "Specializes in" => "Se especializa en",
            "Distance" => "Distancia",
            "Connect" => "Conectar",
            "Filter Resources" => "Recursos de filtro",
            "About" => "Acerca",
            "Services Provided" => "Servicios prestados",
            "Primary Contact" => "Contacto Principal",
            "Address" => "Dirección",
            "Directions" => "Direcciones",
            "Are you" => "¿Eres",
            "Update your profile" => "Actualiza tu perfil",
            "Send Yourself a Magic Link" => "Envíate un Enlace Mágico",
            "We will send you a link by mail that will sign you in instantly!" => "¡Le enviaremos un enlace por correo electrónico que lo iniciará al instante!",
            "The email will be sent to" => "El correo electrónico se enviará a",
            "Send Magic Link" => "EEnviar Enlace Mágico",
            "See something we should change? Suggest an edit." => "¿Ves algo que deberíamos cambiar? Sugerir una edición.",
            "Connect Me With This Organization" => "Conécteme con esta organización",
            "Show All" => "Mostrar todo",
            "The magic link email will be sent to the manager email address on file." => "El correo electrónico del enlace mágico se enviará a la dirección de correo electrónico del administrador registrada.",
            "The magic link email will be sent to the email address on file." => "El correo electrónico del enlace mágico se enviará a la dirección de correo electrónico registrada.",
            "Profile Manager Email" => "Correo electrónico del administrador de perfil",
            "Select Profile to Update" => "Seleccionar perfil para actualizar",
        ];
        if(isset($translations[$string])){
            return $translations[$string];
        }

        return $string;
    }
}
