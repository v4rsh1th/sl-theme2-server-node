<?php


namespace Sourcelink\ResourceNavigator;

use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;

class SettingsTabs
{



    /**
     * Default initiation call. All classes in Resource Navigator engine use ::Bootstrap to set the initial hooks and filters for that
     * class. Register will handle instance specific hooks and filters while this class handles global default registrations
     *
     * @param mixed $input Ignored by the engine, but required to Bootstrap.
     *
     * @return mixed $customPost
     */
    public static function Bootstrap($input = '')
    {
        $class      = get_called_class();
        $customPost = new $class();
        add_action('admin_menu',[$customPost,'Register'], 11);
        return $customPost;
    }

    /**
     * Name in the WordPress DB for object
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'settings_tabs';
    }

    // Register all the post lifecycle callbacks inside WordPress.
    public function Register()
    {
        add_submenu_page(
            'admin.php?page=resource_navigator',
            __( 'Settings', 'slrn' ),
            __( 'Settings', 'slrn' ),
            'manage_options',
            'resource_navigator_' . $this->MachineName(),
            [$this,'Display']
        );
    }

    public static function Display(){
        $settings_pages = [
            'general_settings' => '\Sourcelink\ResourceNavigator\Settings\MainSettings',
            'referral_regions' => '\Sourcelink\ResourceNavigator\Settings\ReferralRegions',
            'api_cache_settings' => '\Sourcelink\ResourceNavigator\Settings\APICacheSettings',
        ];


        $rtn = [];

        foreach ($settings_pages as $key=>$val){
            $eachObj = new $val();
            $tabs[] =[
                'id'=>$key,
                'label'=>$eachObj->Name(),
                'display'=>$eachObj->DisplayTab(),

            ];
        }
        print TwigManager::Twig()->Render('admin/tabs.twig', ['tabs'=>$tabs]);
    }
}
