<?php

namespace Sourcelink\ResourceNavigator\InternalAPI;

use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Service;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\InternalApiBase;
use Sourcelink\ResourceNavigator\Post\WebFormPost;

/**
 * Class RecipeSearchAPI
 * @package Propaganda3\WPO\InternalAPI
 */
class WebFormAPI extends InternalApiBase
{
    /**
     * Registers a single endpoint for searching recipes.
     *
     * @return array Used by WPO engine to generate endpoint
     */
    public function RouteArray(): array
    {
        return [
            [
                'endpoint' => 'get-question-info',
                'method'   => 'GET',
                'callback' => array($this, 'GetQuestion'),
                'args'     => [
                    'id' => [
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        },
                        'required'          => true
                    ],
                    'question' => [
                        'validate_callback' => function ($param, $request, $key) {
                            return !empty(filter_var($param, FILTER_SANITIZE_STRING));
                        },
                        'required'          => true
                    ],
                ]
            ]
        ];
    }

    /**
     * Name of common directory for all endpoints in this group. Must be unique.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'slrn_web_form';
    }

    /**
     * Search db for recipes matching the provided parameters. All parameters except s are optional and added to the query
     * only if provided. Attributes are specific to Certified Hereford Beef, but can be customized for any recipe kit.
     *
     * @param $request
     *
     * @return string
     */
    public function GetQuestion($request)
    {
        return json_encode(WebFormPost::GetQuestionDetailsByID($request['id'],$request['question']));

    }
}