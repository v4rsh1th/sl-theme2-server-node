<?php
/*
 * @desctiption : Manages display and control of event objects in the wp admin. This is the simple version with basic
 *                date, venue string and url. Subclass for more complex functionality
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\Block;
use Sourcelink\ResourceNavigator\BlockBase;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\Post\WebFormPost;

class WebFormBlock extends BlockBase {
    public function MachineName(): string
    {
        return 'web-form-block';
    }

    public function Name() {
        return 'Web Form Block';
    }



    public function GetSidebarInputs(): array
    {
        $forms = WebFormPost::SelectOptions();
        return [
            'id' => [
                'title' => 'Web Form',
                'type' => 'select',
                'values' => [0=>'Select'] + $forms
            ],
        ];
    }
    /**
     * @param array $attributes
     * @param string|null $content
     *
     * @return string
     */
    public function Display(array $attributes, string $content = null): string
    {
        return WebFormPost::Render($attributes);
    }
    /* -----------------   END SEE OVERRIDDEN PARENT CLASS METHODS   ----------------------- */
}
