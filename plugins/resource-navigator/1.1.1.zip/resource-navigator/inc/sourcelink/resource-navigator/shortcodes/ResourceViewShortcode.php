<?php
/*
 * @desctiption : Manages display and control of event objects in the wp admin. This is the simple version with basic
 *                date, venue string and url. Subclass for more complex functionality
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\Shortcode;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\ShortcodeBase;

class ResourceViewShortcode extends ShortcodeBase {

	/**
     * Name in wordpress DB for object.
     * 
     * @return string
     */
	public function MachineName() {
		return 'resource_view';
	}
	/**
     * Name for the admin panel.
     * 
     * @return string
     */
	public function Name() {
		return 'Resource View';
	}



    /**
     *
     *
     * @param $attributes
     * @param string|null $content
     *
     * @return string
     */
	public  function Display($attributes, string $content = null) {

        $data= [];
        return ResourceViewPost::Render($attributes, $data);
	}

}