<?php
/*
 * @desctiption : Manages display and control of event objects in the wp admin. This is the simple version with basic
 *                date, venue string and url. Subclass for more complex functionality
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\Shortcode;
use Sourcelink\ResourceNavigator\Post\WebFormPost;
use Sourcelink\ResourceNavigator\ShortcodeBase;

class WebFormShortcode extends ShortcodeBase {

    /**
     * Name in wordpress DB for object.
     *
     * @return string
     */
    public function MachineName() {
        return 'web_form';
    }
    /**
     * Name for the admin panel.
     *
     * @return string
     */
    public function Name() {
        return 'Web Form';
    }


//    public function WPBakery()
//    {
//        if(function_exists('vc_map')){
//            vc_map( array(
//                "name" => __("SourceLink Web Form"),
//                "base" => "web_form",
//                "category" => __('Content'),
//                "params" => array(
//                    array(
//                        "type" => "dropdown",
//                        "holder" => "div",
//                        "class" => "",
//                        "heading" => __("Web Form"),
//                        "param_name" => "id",
//                        "value" => WebFormPost::SelectOptions(),
//                        "description" => __("Select the web form to use.")
//                    )
//                )
//            ) );
//        }
//    }

    /**
     *
     *
     * @param $attributes
     * @param string|null $content
     *
     * @return string
     */
    public  function Display( $attributes = [], ?string $content = null) {
        if(is_array($attributes)){
            $data=[];
            return WebFormPost::Render($attributes, $data);
        }
    }

}