<?php

namespace Sourcelink\ResourceNavigator\Post;

use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\PostBase as PostBase;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;

class PartnerProfileFormPost extends PostBase
{
    private static function Redirect($url)
    {
        var_dump($url);
        //echo '<script>location.href = "' . $url . '";</script>';
        die();
    }
    public static function posts_columns( $columns ) {
        $columns['shortcode'] = 'Shortcode';
        $columns['form_type'] = 'Form Type';
        $columns['note'] = 'Note';

        return $columns;
    }

    public static function posts_column_data( $column, $post_id ) {
        if($column == 'shortcode'){
            echo '<pre>[partner_profile_form id="'.$post_id.'"]</pre>';
        }
        if($column == 'form_type'){
            $type = get_post_meta($post_id, 'partner_profile_form_layout', true);
            echo $type == '' ? 'Create' : 'Update';
        }
        if($column == 'note'){
            $note = get_post_meta($post_id, 'partner_profile_form_admin_note', true);
            echo $note ;
        }
    }
    /**
     * Edit the default args for resource-navigator objects to add excerpt and change visibility.
     *
     * @param array $overrides
     *
     * @return array $overrides
     */
    public function GetArgs(array $overrides = array()): array
    {
        $overrides = array_merge(
            $overrides,
            array(
                'supports'           => array('title', 'page_attributes'),
                'show_in_menu'       => 'admin.php?page=resource_navigator',
                'publicly_queryable' => false

            )
        );

        return parent::GetArgs($overrides);
    }

    /**
     * Name for the admin panel.
     *
     * @return string
     */
    public function Name(): string
    {
        return 'Partner Profile Form';
    }

    /**
     * Plural Name for the admin panel.
     *
     * @return string
     */
    public function PluralName(): string
    {
        return 'Partner Profile Forms';
    }

    /**
     * Name in WordPress DB for object.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'partner_profile_form';
    }

    /**
     * Array used to build meta field inputs.
     *
     * @return array
     */
    public function GetInputs(): array
    {
        return [
            [
                'type'      => 'panel',
                'id'        => 'general-section',
                'shortcode' => $this->MachineName(),
                'embed'     => true,
                'header'    => 'General Settings',
                'inputs'    => [
                    'layout'         => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'Create', 'update' => 'Update'],
                        'text'   => 'Form Type',
                        'size'   => 'col-12',
                        'hint'   => 'Create vs Update Profile.',
                    ],
                    'language'         => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'English', 'spanish' => 'Spanish'],
                        'text'   => 'Language',
                        'size'   => 'col-12',
                    ],
                    'redirect_url'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Not Logged In Redirect URL',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'URL to redirect to if the user is not logged in. If no url is provided the form will not show on the page.',
                    ],
                    'default_update' => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Use as Default Update Form for Magic Link',
                        'size'   => 'col-12',
                        'hint'   => 'When the magic link is validated this form will be displayed to the provider for making updates.',
                    ],
                    'admin_note' => [
                        'type'   => 'text',
                        'value'  => '',
                        'text'   => 'Note',
                        'size'   => 'col-12',
                        'hint'   => 'Add a note to the listing columns in the admin.',
                    ],
                    'header_code'   => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Header Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the header of the profile page.',
                    ],
                    'footer_code'   => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Footer Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the footer of the profile page.',
                    ],

                ]
            ],
            [
                'type'   => 'panel',
                'id'     => 'email-section',
                'header' => 'Email Settings',
                'inputs' => [
                    'admin_emails'          => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Admin Emails',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'These emails will be notified upon form submission. Separate multiple emails with commas (,). *Admin email will automatically send to ops@joinsourcelink.com.',
                    ],
                    'reply_emails'          => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Reply to Emails',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'Email address to use when the applicant clicks "Reply".',
                    ],
                    'receipt_email'         => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'text'   => 'Send Receipt to Applicant?',
                        'values' => ['1' => 'Yes'],
                        'default' => '1',
                        'size'   => 'col-12',
                        'hint'   => 'If checked, the email address provided in the form will receive a copy of the information in their submission.',
                    ],
                    'admin_email_header'    => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Admin Email Header Message',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'Text added to the email sent to admins.',
                    ],
                    'provider_email_header' => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Provider Email Header Message',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'Text added to the email sent to resource partner.',
                    ],
                ]
            ],
            [
                'type'   => 'panel',
                'id'     => 'form-section',
                'header' => 'Form Settings',
                'inputs' => [
                    'require_agreement' => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'default' => '1',
                        'text'   => 'Show & Require Agreement Question?',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'dem_overview_message' => [
                        'type'    => 'textarea',
                        'value'   => '',
                        'text'    => 'Filter Overview Message',
                        'default' => 'Some organizations <strong>support</strong> all types of entrepreneurs and business owners, others <strong>specialize</strong> in serving only specific sub-groups. In each category below, please check the types of clients which you provide direct technical services for. Please mark all that apply, see below for an example.',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => 'Text shown before the filter selection area.',
                    ],
                    'service_message'   => [
                        'type'    => 'textarea',
                        'value'   => '',
                        'text'    => 'Service Message',
                        'size'    => 'col-12 col-md-6',
                        'default' => 'This section will match prospective clients with the services you offer. The services indicated will determine what assistance clients are contacting your organization for assistance with. Please use the list below and indicate ONLY those services that you directly provide, as opposed to services for which you would know where to refer the client. This will save entrepreneurs time and your organizations frustration. Please indicate a specialty area if one applies.',
                        'hint'    => 'Text shown before the service selection area.',
                    ],
                    'catch_all'         => [
                        'type'    => 'textarea',
                        'value'   => '',
                        'text'    => 'Catch All Text Box Message',
                        'default' => 'Do you provide services ONLY to clients who currently live in a specific city, county or state? If so, please list.',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => 'Text shown above the last text box – used to collect location exclusions or other messages from providers.',
                    ],
                    'agreement_message' => [
                        'type'    => 'textarea',
                        'value'   => '',
                        'text'    => 'Agreement Message',
                        'default' => 'I understand that the information I have provided will be shown and marketed by SourceLink, network members, and others.',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => 'Text shown next to the required agreement checkbox',
                    ],
                    'thank_you'         => [
                        'type'    => 'textarea',
                        'value'   => '',
                        'text'    => 'Post-Submission/Thank-You Message',
                        'default' => 'Thank you. Your submission has been sent.',
                        'size'    => 'col-12 col-md-12',
                        'hint'    => 'This text will appear after the applicant clicks "Submit".',
                    ],
                    'require_address'   => [
                        'type'    => 'checkbox',
                        'value'   => '',
                        'values'  => ['1' => 'Yes'],
                        'default' => '1',
                        'text'    => 'Require Address?',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => '',
                    ],
                    'require_email'     => [
                        'type'    => 'checkbox',
                        'value'   => '',
                        'values'  => ['1' => 'Yes'],
                        'default' => '1',
                        'text'    => 'Require Email?',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => '',
                    ],
                    'require_phone'     => [
                        'type'    => 'checkbox',
                        'value'   => '',
                        'values'  => ['1' => 'Yes'],
                        'default' => '1',
                        'text'    => 'Require Phone?',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => '',
                    ],
                    'show_website'      => [
                        'type'    => 'checkbox',
                        'value'   => '',
                        'values'  => ['1' => 'Yes'],
                        'default' => '1',
                        'text'    => 'Show Website field?',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => '',
                    ],
                    'require_website'   => [
                        'type'    => 'checkbox',
                        'value'   => '',
                        'values'  => ['1' => 'Yes'],
                        'default' => '1',
                        'text'    => 'Require Website?',
                        'size'    => 'col-12 col-md-6',
                        'hint'    => '',
                    ],
                    'show_organization' => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Show Organization Name 2 field?',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'show_fax'          => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Show Fax field?',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_specialty' => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Disable Specialty',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => 'Do you want to hide the specialty column for form tables?',
                    ],
                    'max_supported_filters' => [
                        'type'   => 'number',
                        'value'  => '',
                        'text'   => 'Maximum Supported Filters',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'max_specialty_filters' => [
                        'type'   => 'number',
                        'value'  => '',
                        'text'   => 'Maximum Specialty Filters',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'max_supported_services' => [
                        'type'   => 'number',
                        'value'  => '',
                        'text'   => 'Maximum Supported Services',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'max_specialty_services' => [
                        'type'   => 'number',
                        'value'  => '',
                        'text'   => 'Maximum Specialty Services',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'tag_id'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'SourceLink Pro Tag ID',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => 'Add a tag to this profile in SourceLink Pro',
                    ],

                ]
            ]
        ];
    }

    /**
     * render - Gather data and determine what to display
     * @param array $attributes
     * @param array $data
     *
     * @return string
     */
    public static function Render(array $attributes = [], array $data = []): string
    {
        //Return nothing if no id provided
        if (empty($attributes['id'])) {
            return '';
        }

        //Get an instance of this post object class
        $staticClass = get_called_class();
        $obj         = new $staticClass();

        //get all data for this post
        if ($attributes['id'] == 0) {
            global $wpdb;
            $results    = $wpdb->get_results("select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'partner_profile_form_default_update'", ARRAY_A);
            $attributes['id'] = $results[0]['post_id'];
        }
        $the_post = get_post($attributes['id']);
        if ($the_post === null) {
            return '';
        }
        $data['post']         = ResourceNavigatorUtilityBase::GetPostProperties($the_post, $staticClass);

        $data['grc_site_key'] = get_option('slrn_grc_api_key');

        $login = new Login(get_option('slrn_api_key'));
        if (empty($_COOKIE['slrn_session'])) {
            $loginResult = $login->DoLogin();
            if( (isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)){
                return '';
            }
        }
        $userOrgApi = new \Sourcelink\ResourceNavigator\API\UserOrg(get_option('slrn_api_key'));
        $user_org_result =  $userOrgApi->GetMyUserOrg();
        $user_org_data = json_decode($user_org_result["body"], true);
        $user_org_data = $user_org_data["result"];
        $data['user_org'] = $user_org_data;
        //Authenticate magic link

        if (!empty($attributes['isMagicLink']) && isset($_GET['publicToken']) && isset($_GET['jwtToken'])) {


            if (filter_var($_GET['publicToken'], FILTER_SANITIZE_URL) != '' && filter_var($_GET['jwtToken'], FILTER_SANITIZE_URL) != '') {
                $tokens = ['jwtToken' => filter_var($_GET['jwtToken'], FILTER_SANITIZE_URL), 'publicToken' => filter_var($_GET['publicToken'], FILTER_SANITIZE_URL)];

                $sendResult = $login->AuthenticateMagicLink($tokens);
                $sendBody   = json_decode((string)$sendResult["body"], true);

                //Process Authentication results
                if ($sendBody['isError'] === false ) {
                    //$attributes['providerId'] = filter_var($sendBody['result']['providerId'], FILTER_SANITIZE_NUMBER_INT);
                    if ( ! empty($attributes['providerId']) && $attributes['providerId'] !== -1) {
                        $attributes['isMagicLink'] = true;
                    } else {
                        $attributes['isMagicLink'] = false;
                        unset($attributes['providerId']);
                        return '';
                    }
                } else {
                    $attributes['isMagicLink'] = false;
                    return '';
                }
            }
        }
        //Form Submit Processing
        if (isset($_POST['slrn-submit']) && ! empty(filter_var($_POST['slrn-submit'], FILTER_SANITIZE_NUMBER_INT) ) && (!isset($_POST['slrn-submit-ppf']) || $_POST['slrn-submit-ppf'] == $attributes['providerId'])) {

            if ( ! empty($data['grc_site_key'])) {
                $validated_grc = self::ValidateGoogleRecaptcha($_POST['g-recaptcha-response']);
            } else {
                $validated_grc = true;
            }

            //Google Recaptcha is Valid
            if ($validated_grc) {
                $post_data_filtered = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
                $post_data_filtered['txtDescLong'] = htmlentities2($_POST['txtDescLong']); //bypass filter to allow html

                $post_data = PartnerProfileFormPost::ProcessDemoAndSpecialtyFormData($post_data_filtered);

                if ( ! empty($_FILES['logo']['tmp_name'])) {
                    $post_data['logoEncoded'] = base64_encode(file_get_contents($_FILES['logo']['tmp_name']));
                    $post_data['logoExt'] = ResourceNavigatorUtilityBase::GetExtensionForFileType($_FILES['logo']['type']);
                }

                //Nonce Verification
                if (isset($_POST['providerID'])) {
                    $valid = wp_verify_nonce($_POST['_slrn_nonce'], 'update_provider_' . $_POST['providerID']);
                } else {
                    $valid = wp_verify_nonce($_POST['_slrn_nonce'], 'create_provider');
                }

                //Generate Response
                if ($valid === false) {
                    $data['form_response'] = ['code' => '401', 'message' => 'Invalid Nonce. Not Authorized.'];
                } else {
                    $data['form_response'] = PartnerProfileFormPost::HandleFormPost($post_data, $data['post']);
                }
            } else {
                $data['form_response'] = ['code' => '402', 'message' => 'Invalid ReCAPTCHA Response.'];
            }
        }

        //Provider API Reference
        $providerApi = new Provider(get_option('slrn_api_key'));
        if (isset($attributes['providerId'])) {
            $providerID = filter_var($attributes['providerId'], FILTER_SANITIZE_NUMBER_INT);
        } elseif (isset($_GET['providerId'])) {
            $providerID = filter_var($_GET['providerId'], FILTER_SANITIZE_NUMBER_INT);
        }

        //Get provider data if provider ID... provided...
        if ( ! empty($providerID)) {
            $providerResult   = $providerApi->GetProviderById($providerID);
            $providerData     = json_decode($providerResult["body"], true);
            $data['provider'] = $providerData['result'][0];

            foreach ($data['provider']['Services'] as $service) {
                $data['provider']['providerServices'][$service['ServiceCategoryID']][$service['ServiceID']] = $service;
            }
            foreach ($data['provider']['Filters'] as $filter) {
                $data['provider']['providerFilters'][$filter['FilterCategoryID']][$filter['FilterID']] = $filter;
            }
        }

        //If this is an update form
        if ($data['post']['meta']['layout'] === "update") {
            if (empty($data['provider']) || ( ! ResourceNavigatorUtilityBase::CurrentUserHasRole('administrator') && $attributes['isMagicLink'] !== true) || empty(get_option('slrn_api_key')) || ! isset($_COOKIE['slrn_session'])) {
                var_dump($data['provider']);
                //Sneaky JS redirect
                if ( ! empty($data['post']['meta']['redirect_url'])) {
                    self::Redirect($data['post']['meta']['redirect_url']);
                } else {
                    return '';
                }
            }
        }


        //Determine layout file to use
        $alternateLayout = $attributes['layout'] ?? $data['post']['meta']['layout'] ?? '';
        $twig = ResourceNavigatorUtilityBase::FindVariant($obj->MachineName(), 'view', 'twig', $alternateLayout);

        //fetch demos
        $saved_demos = get_option('slrn_cached_fields');
        $demos = [];
        if ( ! empty($saved_demos)) {
            $demos = $saved_demos;
        } else {
            $demos = DemographicCache::FilterFullArray();

        }
        //Remove isPublic == false demos from demo array
        if(!empty($demos)){
            foreach ($demos as $idx=>$demo){
                if(isset($demo['isPublic']) && $demo['isPublic'] == false){
                    unset($demos[$idx]);
                }
            }
            $data['demos'] = $demos;
        }
        //fetch services
        $saved_services = get_option('slrn_cached_services');
        if ( ! empty($saved_services)) {
            $data['services'] = $saved_services;
        } else {
            $data['services'] = ServiceCache::ServiceFullArray();
        }

        usort($data['demos'], function($a, $b){
            return $a['listOrder'] - $b['listOrder'];
        });
        foreach($data['demos'] as &$d) {
            usort($d['demographicValues'], function ($a, $b) {
                return $a['listOrder'] - $b['listOrder'];
            });
        }
        usort($data['services'], function($a, $b){
            return $a['listOrder'] - $b['listOrder'];
        });
        foreach($data['services'] as &$s){
            usort($s['serviceByCategories'], function($a, $b){
                return $a['listOrder'] - $b['listOrder'];
            });
        }

        //enqueue ppf specific JS file
        $scripts['slrn-partner-profile-form-js'] = [
            'type'   => 'script',
            'src'    => ResourceNavigatorUtilityBase::GetAsset('js/frontend/ppf-validate.js'),
            'deps'   => ['slrn-validate-js'],
            'footer' => true,
            'ver' => ResourceNavigatorBase::GetCacheVersion(),
        ];
        ResourceNavigatorUtilityBase::EnqueueAdditional($scripts);

        //render something... or nothing
        return ! empty($twig) ? TwigManager::Twig()->Render($twig, $data) : '';
    }

    /**
     * HandleFormPost - post form to API and process a response to return to the calling method.
     * @param array $form_data
     * @param array|null $the_post
     *
     * @return array
     */
    public static function HandleFormPost(array $form_data, array $the_post = null): array
    {
        if (empty($the_post['meta']['admin_emails'])) {
            $the_post['meta']['admin_emails'] = 'ops@joinsourcelink.com';
        } else {
            $the_post['meta']['admin_emails'] .= ',ops@joinsourcelink.com';
        }
        //build post body for api call
        $object      = [
            "providerId"                 => $form_data['providerID'] ?? 0,
            "providerName"               => $form_data['txtProviderName'] ?? "",
            "providerSubName"            => $form_data['txtProviderSubName'] ?? "",
            "contactFirstName"           => $form_data['txtContactFirstName'] ?? "",
            "contactLastName"            => $form_data['txtContactLastName'] ?? "",
            "phone"                      => $form_data['txtBusinessPhone'] ?? "",
            "phoneExt"                   => $form_data['txtBusinessPhoneExt'] ?? "",
            "fax"                        => $form_data['txtFax'] ?? "",
            "email"                      => $form_data['txtContactEmail'] ?? "",
            "profileManagerEmail"        => $form_data['txtProfileManagerEmail'] ?? "",
            "address1"                   => $form_data['txtAddress1'] ?? "",
            "address2"                   => $form_data['txtAddress2'] ?? "",
            "city"                       => $form_data['txtCity'] ?? "",
            "state"                      => $form_data['txtState'] ?? "",
            "zip"                        => $form_data['txtZip'] ?? "",
            "url"                        => $form_data['txtUrl'] ?? "",
            "secondaryUrl"               => $form_data['txtSecondaryUrl'] ?? "",
            "facebookUrl"                => $form_data['txtFacebook'] ?? "",
            "twitterUrl"                 => $form_data['txtTwitter'] ?? "",
            "linkedInUrl"                => $form_data['txtLinkedIn'] ?? "",
            "instagramUrl"               => $form_data['txtInstagram'] ?? "",
            "shortDescription"           => $form_data['txtDescShort'] ?? "",
            "businessSummary"            => $form_data['txtDescLong'] ?? "",
            "note"                       => $form_data['tbLocationExclusions'] ?? "",
            "logoEncoded"                => $form_data['logoEncoded'] ?? "",
            "logoExtension"              => $form_data['logoExt'] ?? "",
            "logo2Encoded"                => $form_data['logo2Encoded'] ?? "",
            "logo2Extension"              => $form_data['logo2Ext'] ?? "",
            "tagIds"                      => !empty($the_post['meta']['tag_id']) ? array_map('intval',explode(',', $the_post['meta']['tag_id'])) : [],
            "adminEmailsToNotify"        => $the_post['meta']['admin_emails'] ?? "",
            "replyToEmailAddress"        => $the_post['meta']['reply_emails'] ?? "",
            "adminEmailHeaderMessage"    => $the_post['meta']['admin_email_header'] ?? "",
            "providerEmailHeaderMessage" => $the_post['meta']['provider_email_header'] ?? "",
            "sendEmailToProvider"        => $the_post['meta']['receipt_email'][0] == "1" ? true : false,
            "submissionUrl"              => (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]",
            "userIPAddress"              => $_SERVER['REMOTE_ADDR'],
            "supportedDemographicValues" => $form_data['demos'],
            "supportedServices"          => $form_data['services'] ?? []
        ];

        $providerApi = new Provider(get_option('slrn_api_key'));

        //Try to save the provider
        $response = json_decode((string)$providerApi->SaveProvider($object)['body'], true);
        if ( ! isset($response["isError"]) || $response["IsError"] === true) { //isError is only set in the api response when the response is not an error.
            if(!isset($response['Detail'])){
                $response['Detail'] = $response['Title'];
            }
            $response["isError"] = true;
            $response['message'] = $response['Detail'] ?? "An unspecified error has occurred in the SourceLink API.";
            $response['result']  = '';
        }

        return ['code' => $response["isError"] == false ? '200' : '500', 'message' => $response["isError"] == false ? $the_post['meta']['thank_you'] : $response['message'], "response" => $response];
    }



    public static function ProcessDemoAndSpecialtyFormData($post_data): array
    {
        $demos    = [];
        $services = [];

        //Organize Demo data
        foreach ($post_data as $key => $val) {

            if (strpos($key, 'demo_') !== false) {

                $key_parts = explode('_', $key);
                //add default for cat / demo
                if (isset($key_parts[1]) && isset($key_parts[3]) && !isset($demos[$key_parts[1]][$key_parts[3]]) && strpos($key, '_suggestion') === false && strpos($key, '_primary') === false) {
                    $demos[$key_parts[1]][$key_parts[3]] = ['isSpecialty' => false, 'isPrimary' => false];
                }
                //enable specialty or primary
                if (strpos($key, '_specialty') !== false) {
                    $demos[$key_parts[1]][$key_parts[3]]['isSpecialty'] = $val == "1";
                } elseif (strpos($key, '_primary') !== false && !empty($val)) {
                    $demos[$key_parts[1]][$val]['isPrimary'] = true;
                }
                if(strpos($key, '_suggestion') !== false && strpos($key, '_suggestion_title') === false && !empty($val)) {
                    $post_data['tbLocationExclusions'] .= "\n\n Suggested {$post_data[$key.'_title']}: {$val}";

                }

                unset($post_data[$key]);
            }


            //Organize Service data
            if (strpos($key, 'service_') !== false) {
                $key_parts = explode('_', $key);
                if ( ! isset($services[$key_parts[1]][$key_parts[3]])) {
                    $services[$key_parts[1]][$key_parts[3]] = [];
                }
                if (strpos($key, '_specialty') !== false) {
                    $services[$key_parts[1]][$key_parts[3]]['isSpeciality'] = $val == "1";
                }

                if(strpos($key, '_suggestion') !== false && strpos($key, '_suggestion_title') === false && !empty($val)) {
                    $post_data['tbLocationExclusions'] .= "\n\n Suggested {$post_data[$key.'_title']}: {$val}";
                }
                unset($post_data[$key]);
            }
        }
        //Create data for submission demo
        foreach ($demos as $cat => $demo) {
            foreach ($demo as $demo_id => $values) {
                $post_data["demos"][] = [
                    'demographicCategoryId' => $cat,
                    'demographicValueId'    => $demo_id,
                    'isSpecialty'           => $values['isSpecialty'] ?? false,
                    'isPrimary'             => $values['isPrimary'] ?? false,
                ];
            }
        }

        //Create data for submission service
        foreach ($services as $cat => $service) {
            foreach ($service as $service_id => $values) {
                $post_data["services"][] = [
                    'serviceCategoryId' => $cat,
                    'serviceId'         => $service_id,
                    'isSpeciality'      => $values['isSpeciality'] ?? false,
                ];
            }
        }

        return $post_data;
    }


    public static function ValidateGoogleRecaptcha($res)
    {
        $url             = 'https://www.google.com/recaptcha/api/siteverify';
        $data            = array(
            'secret'   => get_option('slrn_grc_api_key_2'),
            'response' => $res
        );
        $query           = http_build_query($data);
        $options         = array(
            'http' => array(
                'header'  => "Content-Type: application/x-www-form-urlencoded\r\n" . "Content-Length: " . strlen($query) . "\r\n" . "User-Agent:MyAgent/1.0\r\n",
                'method'  => 'POST',
                'content' => $query
            )
        );
        $context         = stream_context_create($options);
        $verify          = file_get_contents($url, false, $context);
        $captcha_success = json_decode($verify);

        return $captcha_success->success;
    }

}