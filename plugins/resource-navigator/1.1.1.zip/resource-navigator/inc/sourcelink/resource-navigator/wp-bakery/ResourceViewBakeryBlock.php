<?php
/*
 * @desctiption : WPBakery block for SourceLink Resource Navigator View
 * @version     : 1.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2022/02/21    | MG          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\WPBakery;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\ShortcodeBase;
if ( class_exists( 'WPBakeryShortCode' ) && !class_exists( 'ResourceViewBakeryBlock' ) ) {

    class ResourceViewBakeryBlock extends \WPBakeryShortCode {

        //Initialize Component
        function __construct() {
            add_action( 'init', array( $this, 'create_shortcode' ), 999 );
            add_shortcode( 'vc_resource_view', array( $this, 'render_shortcode' ) );

        }

        public static function Bootstrap() {
//            $class      = get_called_class();
//            add_action( 'init', array( $class, 'create_shortcode' ), 999 );
//            add_shortcode( 'vc_resource_view', array( $class, 'render_shortcode' ) );
        }

        //Map Component
        public function create_shortcode() {
            if(function_exists('vc_map')){
                vc_map( array(
                    "name" => __("SourceLink Resource View"),
                    "base" => "vc_resource_view",
                    "category" => __('SourceLink'),
                    "params" => array(
                        array(
                            "type" => "dropdown",
                            "holder" => "div",
                            "class" => "",
                            "heading" => __("Resource View"),
                            "param_name" => "id",
                            "value" => array_merge(['-- Select a Resource View --'=>''],ResourceViewPost::SelectOptions()),
                            "description" => __("Select the resource view to use.")
                        )
                    )
                ) );
            }
            //Code in the next steps

        }

        //Render Component
        public function render_shortcode( $atts, $content, $tag ) {
            if(is_array($atts)){
                global $wpdb;
                $post = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type='resource_view'", $atts['id'] ));
                $atts['id'] = $post;

                $data=[];
                return ResourceViewPost::Render($atts, $data);
            } else{
                return null;
            }
        }
    }
}
