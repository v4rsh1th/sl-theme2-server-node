<?php
/*
 * @description : Handles all saving
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator;

use function wp_editor;

trait SaveTrait {

    // ************ SAVE METHODS ******************* //
    /**
     * Nice name for object
     *
     * @return string
     */
    public function Name() {
        return '';
    }

    /**
     * Nice name for object (plural)
     *
     * @return string
     */
    public static function metaName() {
        $class=get_called_class();
        $obj = new $class();
        return $obj->Name() . 's';
    }

    /**
     * DB field value or machine readable name. Should be a slug with underscores.
     *
     * @return string
     */
    public function MachineName() {
        return strtolower(preg_replace("/[^a-z0-9.]+/i", "", $this->Name()));
    }

    public function GetInputs() {
        return [];
    }

    /**
     * Override here to save meta info
     *
     * @param $id
     */
    public function save_meta($id) {



        foreach($this->GetInputs() as $idx=>$panel) {
            if($panel['type'] == 'repeater') {
                $tmpArr = array();
                $filtered = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

                if(isset($filtered[$panel['prefix'].'_'.$this->prefix('title')])) {


                    foreach($filtered[$panel['prefix'].'_'.$this->prefix('title')] as $idx2=>$title) {
                        if(strlen($title) > 0 ) {
                            $tmpObj = [];
                            foreach($panel['inputs'] as $key=>$meta) {

                                $filteredField = $filtered[$panel['prefix'] . '_' . $this->prefix($key)][$idx2];

                                switch($meta['type']) {
                                    case 'checkbox':
                                    case 'toggle':
                                    case 'hr':
                                        break;
                                    case 'textarea':
                                        if (isset($_POST[$panel['prefix'] . '_' . $this->prefix($key)][$idx2])) {
                                            $tmpObj[$key] = $_POST[$panel['prefix'] . '_' . $this->prefix($key)][$idx2];
                                            //$this->saveDBValue($id, $this->prefix($key), $_POST[$this->prefix($key)]);
                                        }
                                        break;
                                    case 'date':
                                        $tmpObj[$key] = strtotime($filteredField);
                                        break;
                                    case 'api_question':
                                        $tmpObj[$key] = $filteredField;
                                        $filteredField2 = $filtered[$panel['prefix'] . '_' . $this->prefix($key) . '_answer'][$idx2];
                                        $tmpObj[$key . '_answer'] = $filteredField2;
                                        break;
                                    default:
                                        $tmpObj[$key] = $filteredField;
                                        break;
                                }



                            }
                            $tmpArr[] = $tmpObj;
                        }
                    }
                    $this->saveDBValue($id, $this->prefix($panel['id']), $tmpArr);
                }
            } else {
                $filtered = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
                foreach($panel['inputs'] as $key=>$meta) {

                    switch($meta['type']) {
                        case 'tie':
                            $targetObj = new $meta['target']();

                            if(isset($filtered[$this->prefix($key)])) {



                                $structuredStaffArray = ResourceNavigatorUtilityBase::UpdateTies($id, $filtered[$this->prefix($key)], $this->prefix($key), $targetObj->MachineName() .'_to_'. $this->MachineName());
                                $this->saveDBValue($id, $this->prefix($key), $structuredStaffArray);
                            } else {
                                $structuredStaffArray = ResourceNavigatorUtilityBase::UpdateTies($id, array(),$this->prefix($key), $targetObj->MachineName() .'_to_'. $this->MachineName());
                                $this->saveDBValue($id, $this->prefix($key), $structuredStaffArray);
                            }
                            break;
                        case 'toggle':
                        case 'checkbox':
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), $filtered[$this->prefix($key)]);
                            } else {
                                $this->saveDBValue($id, $this->prefix($key), '');
                            }
                            break;
                        case 'textarea':
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), $_POST[$this->prefix($key)]);
                            }
                            break;
                        case 'date':
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), strtotime($filtered[$this->prefix($key)]));
                            }
                            break;
                        case 'filter':
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), $filtered[$this->prefix($key)]);
                            }
                            if (isset($filtered[$this->prefix($key) . '_name'])) {
                                $this->saveDBValue($id, $this->prefix($key) . '_name', $filtered[$this->prefix($key) . '_name']);
                            }
                            if (isset($filtered[$this->prefix($key) . '_order'])) {
                                $this->saveDBValue($id, $this->prefix($key) . '_order', $filtered[$this->prefix($key) . '_order']);
                            }
                            if(!empty($meta['settings'])){
                                foreach($meta['settings'] as $settings_key=>$settings_meta) {
                                    if (isset($filtered[$this->prefix($key) . '_settings_' . $settings_key])) {
                                        $this->saveDBValue($id, $this->prefix($key) . '_settings_' . $settings_key, $filtered[$this->prefix($key) . '_settings_' . $settings_key]);
                                    } else {
                                        $this->saveDBValue($id, $this->prefix($key) . '_settings_' . $settings_key, '');
                                    }
                                }
                            }
                            break;
                        case 'form_field':
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), $filtered[$this->prefix($key)]);
                            }
                            if (isset($filtered[$this->prefix($key) . '_order'])) {
                                $this->saveDBValue($id, $this->prefix($key) . '_order', $filtered[$this->prefix($key) . '_order']);
                            }
                            if (isset($filtered[$this->prefix($key) . '_notes'])) {
                                $this->saveDBValue($id, $this->prefix($key) . '_notes', $filtered[$this->prefix($key) . '_notes']);
                            }
                            break;
                        case 'hr':
                            break;
                        default:
                            if (isset($filtered[$this->prefix($key)])) {
                                $this->saveDBValue($id, $this->prefix($key), $filtered[$this->prefix($key)]);
                            }
                            break;
                    }
                }
            }
        }
        //die;
    }

    /**
     * Helper function to force field ids into this metas "namespace".
     *
     * @param $string
     * @return string
     */
    public function prefix($string) {
        return $this->MachineName()."_".$string;
    }
    // ************ END SAVE METHODS ******************* //

    // ************ DISPLAY METHODS ******************* //

    /**
     *
     *
     * @param integer $id
     */
    protected function DisplayFields(int $id = 0) {
        print $this->GetFields($id);

    }

    /**
     * @param int $id
     *
     * @return string
     */
    protected function GetFields(int $id = 0): string
    {
        $rtn = '';
        foreach($this->filledValues($id) as $idx=>$panel) {
            $thisPanel = $panel;
            $thisPanel['machine_name'] = $this->MachineName();
            $thisPanel['wysiwyg'] = $this->MachineName();
            $rtn .= TwigManager::Twig()->Render('admin/'.$panel['type'].'.twig', $thisPanel);
        }
        $this->printWysiwyg();
        return $rtn;
    }

protected function cmp_by_order($a, $b) {
        return $a["order"] - $b["order"];
    }
    /**
     *
     *
     * @param $id
     * @return array $meta
     */
    protected function filledValues($id) {
        $meta = $this->GetInputs();

        if(count($meta) > 0) {
            foreach($meta as $idx=>&$panel) {
                if($panel['type'] == 'repeater') {
                    $db_val = $this->getDBValue( $id,$this->prefix( $panel['id']), true );
                    if(!$db_val) {
                        $db_val = [];
                    }
                    $allMeta = $panel['inputs'];

                    foreach($db_val as $idx2=>&$eachBlock) {
                        $_allMeta = $allMeta;
                        foreach($_allMeta as $att=>&$mDetails) {

                            switch($mDetails['type']) {

                                case 'date':
                                    $mDetails['value'] = date('m/d/Y h:i A', $eachBlock[$att]);
                                    break;
                                case 'api_question':
                                    $mDetails['value'] = $eachBlock[$att];
                                    $mDetails['value2'] = $eachBlock[$att . '_answer'];
                                    break;
                                default:
                                    if(isset($eachBlock[$att])) {
                                        $mDetails['value'] = $eachBlock[$att];
                                    }
                                    break;
                            }
                        }
                        $eachBlock = $_allMeta;
                    }
                    $panel['values'] = $db_val;
                }
                elseif($panel['type'] == 'panel') {

                    foreach($panel['inputs'] as $key=>&$eachMeta) {

                        switch($eachMeta['type']) {
                            case 'toggle':
                            case 'checkbox':
                                $db_val = $this->getDBValue( $id, $this->prefix( $key)  , true );
                                $eachMeta['selected'] = $db_val;
                                break;
                            case 'date':
                                if(!empty($this->getDBValue($id, $this->prefix( $key)))){
                                    $db_val = date('m/d/Y h:i A', $this->getDBValue($id, $this->prefix( $key) , true ));
                                    $eachMeta['value'] = $db_val;
                                }
                                break;
                            case 'filter':
                                $db_val = $this->getDBValue( $id, $this->prefix( $key) , true );
                                $eachMeta['value'] = $db_val;
                                $db_val_order = $this->getDBValue( $id, $this->prefix( $key) . '_order' , true );
                                $db_val_name = $this->getDBValue( $id, $this->prefix( $key) . '_name' , true );
                                $eachMeta['order'] = !empty($db_val_order) ? $db_val_order : 0;
                                $eachMeta['name_val'] = !empty($db_val_name) ? $db_val_name : "";
                                if(!empty($eachMeta['settings'])){
                                    foreach($eachMeta['settings'] as $settings_key=>&$settings_meta) {
                                        $db_val_setting = $this->getDBValue( $id, $this->prefix( $key) . '_settings_' . $settings_key , true );
                                        $settings_meta['selected'] = $db_val_setting;
                                    }
                                }
                                break;
                            case 'form_field':
                                $db_val = $this->getDBValue( $id, $this->prefix( $key) , true );
                                $eachMeta['value'] = $db_val;
                                $db_val_order = $this->getDBValue( $id, $this->prefix( $key) . '_order' , true );
                                $eachMeta['order'] = !empty($db_val_order) ? $db_val_order : 0;
                                $db_val_notes = $this->getDBValue( $id, $this->prefix( $key) . '_notes' , true );
                                $eachMeta['notes'] = !empty($db_val_notes) ? $db_val_notes : '';

                                break;
                            default:
                                $db_val = $this->getDBValue( $id, $this->prefix( $key) , true );
                                $eachMeta['value'] = $db_val;
                                break;
                        }
                    }
                }
            }
        }
        else{
            echo '<style>#'.$this::MachineName().'_meta_box{display:none;}</style>';
        }
        return $meta;
    }

    protected function printWysiwyg() {
        print('<div class="hidden" id="wysiwyg-'.$this->MachineName().'">');
        wp_editor('',$this->MachineName());
        print('</div>');
    }




    // ************ END DISPLAY METHODS ******************* //
}