<?php


namespace Sourcelink\ResourceNavigator;

class SettingsBase
{

    use SaveTrait;


    /**
     * Default initiation call. All classes in Resource Navigator engine use ::Bootstrap to set the initial hooks and filters for that
     * class. Register will handle instance specific hooks and filters while this class handles global default registrations
     *
     * @param mixed $input Ignored by the engine, but required to Bootstrap.
     *
     * @return mixed $customPost
     */
    public static function Bootstrap($input = '')
    {
        $class      = get_called_class();
        $customPost = new $class();
        add_action('admin_init', array($customPost, 'save_meta'), 10, 3);
        add_action('admin_menu',[$customPost,'Register'], 11);
        add_action('admin_notices', [$customPost,'Notice']);
        return $customPost;
    }

    /**
     * Name in the WordPress DB for object
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'settings';
    }

    // Register all the post lifecycle callbacks inside WordPress.
    public function Register()
    {
        //$this->save_meta();
    }
    // Register all the post lifecycle callbacks inside WordPress.
    public function Notice()
    {

    }

    public function DisplayTab()
    {
    }

    /**
     *
     * @param int $id
     * @param string $field
     * @param mixed $data
     *
     * @return bool|int
     */
    public function saveDBValue($id, string $field, $data)
    {
        return update_option( $field, $data);
    }

    /**
     *
     * @param string $field
     * @return mixed
     */
    public function getDBValue($id,string $field)
    {
        return get_option($field);
    }

}
