<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\API\Model\IntakeForm;
use Sourcelink\ResourceNavigator\ApiBase;

class Intake extends ApiBase
{
    //API NAMESPACE
    /**
     * @return string
     */
    public function MachineName():string
    {
        return 'Intake';
    }

    //API NAMESPACE ENDPOINTS

    /**
     * GetWebForms - Get all Web Forms
     *
     * @return array
     */
    public function GetWebForms(): ?array
    {
        return self::Get($this->GetRoute('GetWebForms'));
    }

    /**
     * GetWebForms - Get a Web Form
     *
     * @param int $formID
     *
     * @return array
     */
    public function GetWebForm(int $formID): ?array
    {
        if(!is_numeric($formID)) return null;
        return self::Get($this->GetRoute('GetWebForm/' . $formID));
    }
    /**
     * GetProviderContactForm
     *
     * @return array
     */
    public function GetProviderContactForm(): ?array
    {
        return self::Get($this->GetRoute('GetProviderContactForm'));
    }

    /**
     * GetProviderFeedbackForm
     *
     * @return array
     */
    public function GetProviderFeedbackForm(): ?array
    {
        return self::Get($this->GetRoute('GetProviderFeedbackForm'));
    }



    /**
     * SaveClientIntake - Save Client Intake Form
     *
     * @return array|null
     */
    public function SaveWebForm(IntakeForm $form): ?array
    {
        return self::Post($this->GetRoute('SaveWebForm' ),$form);
    }

    /**
     * GetListValues
     *
     * @return array
     */
    public function GetListValues(): ?array
    {
        return self::Get($this->GetRoute('GetListValues'));
    }

    /**
     * GetBusinessStages
     *
     * @return array
     */
    public function GetBusinessStages(): ?array
    {
        return self::Get($this->GetRoute('GetBusinessStages'));
    }

    /**
     * GetEntityTypes
     *
     * @return array
     */
    public function GetEntityTypes(): ?array
    {
        return self::Get($this->GetRoute('GetEntityTypes'));
    }

    /**
     * GetGenderTypes
     *
     * @return array
     */
    public function GetGenderTypes(): ?array
    {
        return self::Get($this->GetRoute('GetGenderTypes'));
    }

    /**
     * GetRaceTypes
     *
     * @return array
     */
    public function GetRaceTypes(): ?array
    {
        return self::Get($this->GetRoute('GetRaceTypes'));
    }

    /**
     * GetDisabilityStatuses
     *
     * @return array
     */
    public function GetDisabilityStatuses(): ?array
    {
        return self::Get($this->GetRoute('GetDisabilityStatuses'));
    }

    /**
     * GetEducationBackgrounds
     *
     * @return array
     */
    public function GetEducationBackgrounds(): ?array
    {
        return self::Get($this->GetRoute('GetEducationBackgrounds'));
    }

    /**
     * GetEthnicityTypes
     *
     * @return array
     */
    public function GetEthnicityTypes(): ?array
    {
        return self::Get($this->GetRoute('GetEthnicityTypes'));
    }

    /**
     * GetInteractTypes
     *
     * @return array
     */
    public function GetInteractTypes(): ?array
    {
        return self::Get($this->GetRoute('GetInteractTypes'));
    }

    /**
     * GetReferralEntityTypes
     *
     * @return array
     */
    public function GetReferralEntityTypes(): ?array
    {
        return self::Get($this->GetRoute('GetReferralEntityTypes'));
    }

    /**
     * GetServiceTypes
     *
     * @return array
     */
    public function GetServiceTypes(): ?array
    {
        return self::Get($this->GetRoute('GetServiceTypes'));
    }

    /**
     * GetMaritalStatuses
     *
     * @return array
     */
    public function GetMaritalStatuses(): ?array
    {
        return self::Get($this->GetRoute('GetMaritalStatuses'));
    }

    /**
     * GetTimeSpentList
     *
     * @return array
     */
    public function GetTimeSpentList(): ?array
    {
        return self::Get($this->GetRoute('GetTimeSpentList'));
    }

    /**
     * GetYesNoList
     *
     * @return array
     */
    public function GetYesNoList(): ?array
    {
        return self::Get($this->GetRoute('GetYesNoList'));
    }

}