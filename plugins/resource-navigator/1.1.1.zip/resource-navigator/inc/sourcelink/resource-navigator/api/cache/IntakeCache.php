<?php

namespace Sourcelink\ResourceNavigator\API\Cache;


use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\CacheBase;

class IntakeCache extends CacheBase
{
    protected $api_namespace;
    protected $cache_keys = [

        'GetWebForms'             => "slrn_cached_web_forms",
        'GetProviderContactForm'  => "slrn_cached_provider_form",
        'GetProviderFeedbackForm' => "slrn_cached_feedback_form",
        'GetListValues'           => "slrn_cached_list_values",

    ];

    public function __construct()
    {
        $this->api_namespace = new Intake(get_option('slrn_api_key'));
    }
    public function GetListValuesArray($field= '',int $lang = 1): array
    {

        $rtn  = [];
        if(empty($field)) return $rtn;
        $data = $this->GetCacheForEndpoint('GetListValues');
        if($data == null) return $rtn;

        foreach ($data as $datum) {

            if($datum['FieldCategoryLabel'] == $field){
            //if($datum['FieldCategoryLabel'] == "Country") var_dump($datum); //Quick dump a group of fields by label


                    $rtn[] = [
                        'value' => $datum['FieldId'],
                        'label' => $lang == 1 ? $datum['FieldLabel'] : $datum['FieldLabelSpanish'],
                        'order' => intval($datum['ListOrder']),
                        'parent' => $datum['ParentFieldId'] ?? ""
                    ];


            }
        }
        if($field == "Country"){
            usort($rtn, function ($item1, $item2) {
                if($item1['value'] == '') return 0;
                return $item1['label'] <=> $item2['label'];
            });
            array_unshift($rtn, [
                'value' => '',
                'label' => $lang == 1 ? 'No Response' : 'Ninguna respuesta',
                'order' => 0,
                'parent' => ""
            ]);

        }
        else{
            usort($rtn, function ($item1, $item2) {
                return $item1['order'] <=> $item2['order'];
            });
        }
        return $rtn;
    }


}