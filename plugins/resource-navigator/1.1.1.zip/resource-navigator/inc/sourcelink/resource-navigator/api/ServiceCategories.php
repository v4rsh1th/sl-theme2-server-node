<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class ServiceCategories extends ApiBase
{
    //API NAMESPACE
    public function MachineName():string
    {
        return 'ServiceCategory';
    }

    //API NAMESPACE ENDPOINTS

    /**
     * GetServiceCategories - Get all service categories
     *
     * @return array|null
     */
    public function GetServiceCategories(): ?array
    {
        return self::Get($this->GetRoute("GetServiceCategories"));
    }

    /**
     * GetServiceCategory - Get a specific service category
     *
     * @param int $serviceCategoryId
     *
     * @return array|null
     */
    public function GetServiceCategory(int $serviceCategoryId): ?array
    {
        if(!is_numeric($serviceCategoryId)) return null;
        return self::Get($this->GetRoute("GetServiceCategory/". $serviceCategoryId));
    }
}