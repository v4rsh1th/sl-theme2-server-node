<?php
namespace Sourcelink\ResourceNavigator\API\Model;

use Sourcelink\ResourceNavigator\ApiObjectBase;

class IntakeForm extends ApiObjectBase
{
    protected $intakeStagingId = 0; //int
    protected $intakeSettingsId = 0; //int
    protected $counselorId = 0; //int
    protected $companyName = ""; //String
    protected $firstName = ""; //String
    protected $lastName = ""; //String
    protected $email = ""; //String
    protected $workTitle = ""; //String
    protected $webUrl = ""; //String
    protected $facebookUrl = ""; //String
    protected $twitterUrl = ""; //String
    protected $address1 = ""; //String
    protected $address2 = ""; //String
    protected $zip = ""; //String
    protected $countryIso = ""; //String
    protected $ruralUrbanId = 0; //int
    protected $legalState = ""; //String
    protected $workPhone = ""; //String
    protected $cellPhone = ""; //String
    protected $homePhone = ""; //String
    protected $fax = ""; //String
    protected $targetMarket = ""; //String
    protected $naicsId = 0; //int
    protected $entityId = 0; //int
    protected $taxIdNum = ""; //String
    protected $referralEntityTypeId = 0; //int
//    protected $providerId = 0; //int
    protected $womenOwned = 0; //int
    protected $minorityOwned = 0; //int
    protected $veteranOwned = 0; //int
    protected $immigrantOwned = 0; //int
    protected $internallyDisplPerOwned = 0; //int
    protected $justiceInvCitizenOwned = 0; //int
    protected $refugeeOwned = 0; //int
    protected $lgbtqOwned = 0; //int
    protected $youthOwned = 0; //int
    protected $lowIncomeOwned = 0; //int
    protected $disabledOwned = 0; //int
    protected $nonEnglishBusinessOwned = 0; //int
    protected $certWomenOwned = 0; //int
    protected $certMinorityOwned = 0; //int
    protected $certDisadvantagedOwned = 0; //int
    protected $certLGBTQOwned = 0; //int
    protected $certSerDisabledVetOwned = 0; //int
    protected $certVetOwned = 0; //int
    protected $certHUDSec3Owned = 0; //int
    protected $certDisabledOwned = 0; //int
    protected $cert8aOwned = 0; //int
    protected $homeBased = 0; //int
    protected $eCommerce = 0; //int
    protected $hasCommercialLocation = 0; //int
    protected $hasMobileBusiness = 0; //int
    protected $genderId = 0; //int
    protected $raceId1 = false; //boolean
    protected $raceId2 = false; //boolean
    protected $raceId3 = false; //boolean
    protected $raceId4 = false; //boolean
    protected $raceId5 = false; //boolean
    protected $ethnicityId = 0; //int
    protected $educationBackgroundId = 0; //int
    protected $disabledId = 0; //int
    protected $militaryStatusId = 0; //int
    protected $veteranStatusId = 0; //int
    protected $lgbtqId = 0; //int
    protected $birthDate = ""; //Date
    protected $clientTypeId = 0; //int
    protected $clientStatusId = 0; //int
    protected $inBusiness = 0; //int
    protected $yearStarted = 0; //int
    protected $monthStarted = 0; //int
    protected $interactTypeId = 0; //int
    protected $serviceTypeId = 0; //int
    protected $interactionDate = ""; //Date
    protected $timeSpentId = 0; //int
    protected $prepTimeId = 0; //int
    protected $travelTimeId = 0; //int
    protected $notes = ""; //String
    protected $busStageId = 0; //int
    protected $fullTimeEmployees = 0; //int
    protected $partTimeEmployees = 0; //int
    protected $loanAmount = 0; //int
    protected $equityAmount = 0; //int
    protected $grantAmount = 0; //int
    protected $revenueAmount = 0; //int
    protected $bondingCapacityAmount = 0; //int
    protected $contractAmount = 0; //int
    protected $sellLocally = 0; //int
    protected $sellRegionally = 0; //int
    protected $sellNationally = 0; //int
    protected $sellInternationally = 0; //int
    protected $sellFedGovt = 0; //int
    protected $userIPAddress = ""; //String
    protected $submissionUrl = ""; //String
    protected $destinationUrl = ""; //String
    protected $capitalRequested = null; //array( CapitalRequested )
    protected $capitalSecured = null; //array( CapitalSecured )
    protected $providersToRefer = null; //array( Int )

    function __construct($json = null) { parent::__construct($json); }

    /**
     * @return int
     */
    public function getIntakeStagingId(): int
    {
        return $this->intakeStagingId;
    }

    /**
     * @param int $intakeStagingId
     */
    public function setIntakeStagingId(int $intakeStagingId): void
    {
        $this->intakeStagingId = $intakeStagingId;
    }

    /**
     * @return int
     */
    public function getIntakeSettingsId(): int
    {
        return $this->intakeSettingsId;
    }

    /**
     * @param int $intakeSettingsId
     */
    public function setIntakeSettingsId(int $intakeSettingsId): void
    {
        $this->intakeSettingsId = $intakeSettingsId;
    }

    /**
     * @return int
     */
    public function getCounselorId(): int
    {
        return $this->counselorId;
    }

    /**
     * @param int $counselorId
     */
    public function setCounselorId(int $counselorId): void
    {
        $this->counselorId = $counselorId;
    }

    /**
     * @return string
     */
    public function getCompanyName(): string
    {
        return $this->companyName;
    }

    /**
     * @param string $companyName
     */
    public function setCompanyName(string $companyName): void
    {
        $this->companyName = $companyName;
    }

    /**
     * @return string
     */
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * @param string $firstName
     */
    public function setFirstName(string $firstName): void
    {
        $this->firstName = $firstName;
    }

    /**
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @param string $lastName
     */
    public function setLastName(string $lastName): void
    {
        $this->lastName = $lastName;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $email
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    /**
     * @return string
     */
    public function getWorkTitle(): string
    {
        return $this->workTitle;
    }

    /**
     * @param string $workTitle
     */
    public function setWorkTitle(string $workTitle): void
    {
        $this->workTitle = $workTitle;
    }

    /**
     * @return string
     */
    public function getWebUrl(): string
    {
        return $this->webUrl;
    }

    /**
     * @param string $webUrl
     */
    public function setWebUrl(string $webUrl): void
    {
        $this->webUrl = $webUrl;
    }

    /**
     * @return string
     */
    public function getFacebookUrl(): string
    {
        return $this->facebookUrl;
    }

    /**
     * @param string $facebookUrl
     */
    public function setFacebookUrl(string $facebookUrl): void
    {
        $this->facebookUrl = $facebookUrl;
    }

    /**
     * @return string
     */
    public function getTwitterUrl(): string
    {
        return $this->twitterUrl;
    }

    /**
     * @param string $twitterUrl
     */
    public function setTwitterUrl(string $twitterUrl): void
    {
        $this->twitterUrl = $twitterUrl;
    }

    /**
     * @return string
     */
    public function getAddress1(): string
    {
        return $this->address1;
    }

    /**
     * @param string $address1
     */
    public function setAddress1(string $address1): void
    {
        $this->address1 = $address1;
    }

    /**
     * @return string
     */
    public function getAddress2(): string
    {
        return $this->address2;
    }

    /**
     * @param string $address2
     */
    public function setAddress2(string $address2): void
    {
        $this->address2 = $address2;
    }

    /**
     * @return string
     */
    public function getZip(): string
    {
        return $this->zip;
    }

    /**
     * @param string $zip
     */
    public function setZip(string $zip): void
    {
        $this->zip = $zip;
    }

    /**
     * @return string
     */
    public function getCountryIso(): string
    {
        return $this->countryIso;
    }

    /**
     * @param string $countryIso
     */
    public function setCountryIso(string $countryIso): void
    {
        $this->countryIso = $countryIso;
    }

    /**
     * @return int
     */
    public function getRuralUrbanId(): int
    {
        return $this->ruralUrbanId;
    }

    /**
     * @param int $ruralUrbanId
     */
    public function setRuralUrbanId(int $ruralUrbanId): void
    {
        $this->ruralUrbanId = $ruralUrbanId;
    }

    /**
     * @return string
     */
    public function getLegalState(): string
    {
        return $this->legalState;
    }

    /**
     * @param string $legalState
     */
    public function setLegalState(string $legalState): void
    {
        $this->legalState = $legalState;
    }

    /**
     * @return string
     */
    public function getWorkPhone(): string
    {
        return $this->workPhone;
    }

    /**
     * @param string $workPhone
     */
    public function setWorkPhone(string $workPhone): void
    {
        $this->workPhone = $workPhone;
    }

    /**
     * @return string
     */
    public function getCellPhone(): string
    {
        return $this->cellPhone;
    }

    /**
     * @param string $cellPhone
     */
    public function setCellPhone(string $cellPhone): void
    {
        $this->cellPhone = $cellPhone;
    }

    /**
     * @return string
     */
    public function getHomePhone(): string
    {
        return $this->homePhone;
    }

    /**
     * @param string $homePhone
     */
    public function setHomePhone(string $homePhone): void
    {
        $this->homePhone = $homePhone;
    }

    /**
     * @return string
     */
    public function getFax(): string
    {
        return $this->fax;
    }

    /**
     * @param string $fax
     */
    public function setFax(string $fax): void
    {
        $this->fax = $fax;
    }

    /**
     * @return string
     */
    public function getTargetMarket(): string
    {
        return $this->targetMarket;
    }

    /**
     * @param string $targetMarket
     */
    public function setTargetMarket(string $targetMarket): void
    {
        $this->targetMarket = $targetMarket;
    }

    /**
     * @return int
     */
    public function getNaicsId(): int
    {
        return $this->naicsId;
    }

    /**
     * @param int $naicsId
     */
    public function setNaicsId(int $naicsId): void
    {
        $this->naicsId = $naicsId;
    }

    /**
     * @return int
     */
    public function getEntityId(): int
    {
        return $this->entityId;
    }

    /**
     * @param int $entityId
     */
    public function setEntityId(int $entityId): void
    {
        $this->entityId = $entityId;
    }

    /**
     * @return string
     */
    public function getTaxIdNum(): string
    {
        return $this->taxIdNum;
    }

    /**
     * @param string $taxIdNum
     */
    public function setTaxIdNum(string $taxIdNum): void
    {
        $this->taxIdNum = $taxIdNum;
    }

    /**
     * @return int
     */
    public function getReferralEntityTypeId(): int
    {
        return $this->referralEntityTypeId;
    }

    /**
     * @param int $referralEntityTypeId
     */
    public function setReferralEntityTypeId(int $referralEntityTypeId): void
    {
        $this->referralEntityTypeId = $referralEntityTypeId;
    }

//    /**
//     * @return int
//     */
//    public function getProviderId(): int
//    {
//        return $this->providerId;
//    }
//
//    /**
//     * @param int $providerId
//     */
//    public function setProviderId(int $providerId): void
//    {
//        $this->providerId = $providerId;
//    }

    /**
     * @return int
     */
    public function getWomenOwned(): int
    {
        return $this->womenOwned;
    }

    /**
     * @param int $womenOwned
     */
    public function setWomenOwned(int $womenOwned): void
    {
        $this->womenOwned = $womenOwned;
    }

    /**
     * @return int
     */
    public function getMinorityOwned(): int
    {
        return $this->minorityOwned;
    }

    /**
     * @param int $minorityOwned
     */
    public function setMinorityOwned(int $minorityOwned): void
    {
        $this->minorityOwned = $minorityOwned;
    }

    /**
     * @return int
     */
    public function getVeteranOwned(): int
    {
        return $this->veteranOwned;
    }

    /**
     * @param int $veteranOwned
     */
    public function setVeteranOwned(int $veteranOwned): void
    {
        $this->veteranOwned = $veteranOwned;
    }

    /**
     * @return int
     */
    public function getImmigrantOwned(): int
    {
        return $this->immigrantOwned;
    }

    /**
     * @param int $immigrantOwned
     */
    public function setImmigrantOwned(int $immigrantOwned): void
    {
        $this->immigrantOwned = $immigrantOwned;
    }

    /**
     * @return int
     */
    public function getInternallyDisplPerOwned(): int
    {
        return $this->internallyDisplPerOwned;
    }

    /**
     * @param int $internallyDisplPerOwned
     */
    public function setInternallyDisplPerOwned(int $internallyDisplPerOwned): void
    {
        $this->internallyDisplPerOwned = $internallyDisplPerOwned;
    }

    /**
     * @return int
     */
    public function getJusticeInvCitizenOwned(): int
    {
        return $this->justiceInvCitizenOwned;
    }

    /**
     * @param int $justiceInvCitizenOwned
     */
    public function setJusticeInvCitizenOwned(int $justiceInvCitizenOwned): void
    {
        $this->justiceInvCitizenOwned = $justiceInvCitizenOwned;
    }

    /**
     * @return int
     */
    public function getRefugeeOwned(): int
    {
        return $this->refugeeOwned;
    }

    /**
     * @param int $refugeeOwned
     */
    public function setRefugeeOwned(int $refugeeOwned): void
    {
        $this->refugeeOwned = $refugeeOwned;
    }

    /**
     * @return int
     */
    public function getLgbtqOwned(): int
    {
        return $this->lgbtqOwned;
    }

    /**
     * @param int $lgbtqOwned
     */
    public function setLgbtqOwned(int $lgbtqOwned): void
    {
        $this->lgbtqOwned = $lgbtqOwned;
    }

    /**
     * @return int
     */
    public function getYouthOwned(): int
    {
        return $this->youthOwned;
    }

    /**
     * @param int $youthOwned
     */
    public function setYouthOwned(int $youthOwned): void
    {
        $this->youthOwned = $youthOwned;
    }

    /**
     * @return int
     */
    public function getLowIncomeOwned(): int
    {
        return $this->lowIncomeOwned;
    }

    /**
     * @param int $lowIncomeOwned
     */
    public function setLowIncomeOwned(int $lowIncomeOwned): void
    {
        $this->lowIncomeOwned = $lowIncomeOwned;
    }

    /**
     * @return int
     */
    public function getDisabledOwned(): int
    {
        return $this->disabledOwned;
    }

    /**
     * @param int $disabledOwned
     */
    public function setDisabledOwned(int $disabledOwned): void
    {
        $this->disabledOwned = $disabledOwned;
    }

    /**
     * @return int
     */
    public function getNonEnglishBusinessOwned(): int
    {
        return $this->nonEnglishBusinessOwned;
    }

    /**
     * @param int $nonEnglishBusinessOwned
     */
    public function setNonEnglishBusinessOwned(int $nonEnglishBusinessOwned): void
    {
        $this->nonEnglishBusinessOwned = $nonEnglishBusinessOwned;
    }

    /**
     * @return int
     */
    public function getCertWomenOwned(): int
    {
        return $this->certWomenOwned;
    }

    /**
     * @param int $certWomenOwned
     */
    public function setCertWomenOwned(int $certWomenOwned): void
    {
        $this->certWomenOwned = $certWomenOwned;
    }

    /**
     * @return int
     */
    public function getCertMinorityOwned(): int
    {
        return $this->certMinorityOwned;
    }

    /**
     * @param int $certMinorityOwned
     */
    public function setCertMinorityOwned(int $certMinorityOwned): void
    {
        $this->certMinorityOwned = $certMinorityOwned;
    }

    /**
     * @return int
     */
    public function getCertDisadvantagedOwned(): int
    {
        return $this->certDisadvantagedOwned;
    }

    /**
     * @param int $certDisadvantagedOwned
     */
    public function setCertDisadvantagedOwned(int $certDisadvantagedOwned): void
    {
        $this->certDisadvantagedOwned = $certDisadvantagedOwned;
    }

    /**
     * @return int
     */
    public function getCertLGBTQOwned(): int
    {
        return $this->certLGBTQOwned;
    }

    /**
     * @param int $certLGBTQOwned
     */
    public function setCertLGBTQOwned(int $certLGBTQOwned): void
    {
        $this->certLGBTQOwned = $certLGBTQOwned;
    }

    /**
     * @return int
     */
    public function getCertSerDisabledVetOwned(): int
    {
        return $this->certSerDisabledVetOwned;
    }

    /**
     * @param int $certSerDisabledVetOwned
     */
    public function setCertSerDisabledVetOwned(int $certSerDisabledVetOwned): void
    {
        $this->certSerDisabledVetOwned = $certSerDisabledVetOwned;
    }

    /**
     * @return int
     */
    public function getCertVetOwned(): int
    {
        return $this->certVetOwned;
    }

    /**
     * @param int $certVetOwned
     */
    public function setCertVetOwned(int $certVetOwned): void
    {
        $this->certVetOwned = $certVetOwned;
    }

    /**
     * @return int
     */
    public function getCertHUDSec3Owned(): int
    {
        return $this->certHUDSec3Owned;
    }

    /**
     * @param int $certHUDSec3Owned
     */
    public function setCertHUDSec3Owned(int $certHUDSec3Owned): void
    {
        $this->certHUDSec3Owned = $certHUDSec3Owned;
    }

    /**
     * @return int
     */
    public function getCertDisabledOwned(): int
    {
        return $this->certDisabledOwned;
    }

    /**
     * @param int $certDisabledOwned
     */
    public function setCertDisabledOwned(int $certDisabledOwned): void
    {
        $this->certDisabledOwned = $certDisabledOwned;
    }

    /**
     * @return int
     */
    public function getCert8aOwned(): int
    {
        return $this->cert8aOwned;
    }

    /**
     * @param int $cert8aOwned
     */
    public function setCert8aOwned(int $cert8aOwned): void
    {
        $this->cert8aOwned = $cert8aOwned;
    }

    /**
     * @return int
     */
    public function getHomeBased(): int
    {
        return $this->homeBased;
    }

    /**
     * @param int $homeBased
     */
    public function setHomeBased(int $homeBased): void
    {
        $this->homeBased = $homeBased;
    }

    /**
     * @return int
     */
    public function getECommerce(): int
    {
        return $this->eCommerce;
    }

    /**
     * @param int $eCommerce
     */
    public function setECommerce(int $eCommerce): void
    {
        $this->eCommerce = $eCommerce;
    }

    /**
     * @return int
     */
    public function getHasCommercialLocation(): int
    {
        return $this->hasCommercialLocation;
    }

    /**
     * @param int $hasCommercialLocation
     */
    public function setHasCommercialLocation(int $hasCommercialLocation): void
    {
        $this->hasCommercialLocation = $hasCommercialLocation;
    }

    /**
     * @return int
     */
    public function getHasMobileBusiness(): int
    {
        return $this->hasMobileBusiness;
    }

    /**
     * @param int $hasMobileBusiness
     */
    public function setHasMobileBusiness(int $hasMobileBusiness): void
    {
        $this->hasMobileBusiness = $hasMobileBusiness;
    }

    /**
     * @return int
     */
    public function getGenderId(): int
    {
        return $this->genderId;
    }

    /**
     * @param int $genderId
     */
    public function setGenderId(int $genderId): void
    {
        $this->genderId = $genderId;
    }

    /**
     * @return bool
     */
    public function isRaceId1(): bool
    {
        return $this->raceId1;
    }

    /**
     * @param bool $raceId1
     */
    public function setRaceId1(bool $raceId1): void
    {
        $this->raceId1 = $raceId1;
    }

    /**
     * @return bool
     */
    public function isRaceId2(): bool
    {
        return $this->raceId2;
    }

    /**
     * @param bool $raceId2
     */
    public function setRaceId2(bool $raceId2): void
    {
        $this->raceId2 = $raceId2;
    }

    /**
     * @return bool
     */
    public function isRaceId3(): bool
    {
        return $this->raceId3;
    }

    /**
     * @param bool $raceId3
     */
    public function setRaceId3(bool $raceId3): void
    {
        $this->raceId3 = $raceId3;
    }

    /**
     * @return bool
     */
    public function isRaceId4(): bool
    {
        return $this->raceId4;
    }

    /**
     * @param bool $raceId4
     */
    public function setRaceId4(bool $raceId4): void
    {
        $this->raceId4 = $raceId4;
    }

    /**
     * @return bool
     */
    public function isRaceId5(): bool
    {
        return $this->raceId5;
    }

    /**
     * @param bool $raceId5
     */
    public function setRaceId5(bool $raceId5): void
    {
        $this->raceId5 = $raceId5;
    }

    /**
     * @return int
     */
    public function getEthnicityId(): int
    {
        return $this->ethnicityId;
    }

    /**
     * @param int $ethnicityId
     */
    public function setEthnicityId(int $ethnicityId): void
    {
        $this->ethnicityId = $ethnicityId;
    }

    /**
     * @return int
     */
    public function getEducationBackgroundId(): int
    {
        return $this->educationBackgroundId;
    }

    /**
     * @param int $educationBackgroundId
     */
    public function setEducationBackgroundId(int $educationBackgroundId): void
    {
        $this->educationBackgroundId = $educationBackgroundId;
    }

    /**
     * @return int
     */
    public function getDisabledId(): int
    {
        return $this->disabledId;
    }

    /**
     * @param int $disabledId
     */
    public function setDisabledId(int $disabledId): void
    {
        $this->disabledId = $disabledId;
    }

    /**
     * @return int
     */
    public function getMilitaryStatusId(): int
    {
        return $this->militaryStatusId;
    }

    /**
     * @param int $militaryStatusId
     */
    public function setMilitaryStatusId(int $militaryStatusId): void
    {
        $this->militaryStatusId = $militaryStatusId;
    }

    /**
     * @return int
     */
    public function getVeteranStatusId(): int
    {
        return $this->veteranStatusId;
    }

    /**
     * @param int $veteranStatusId
     */
    public function setVeteranStatusId(int $veteranStatusId): void
    {
        $this->veteranStatusId = $veteranStatusId;
    }

    /**
     * @return int
     */
    public function getLgbtqId(): int
    {
        return $this->lgbtqId;
    }

    /**
     * @param int $lgbtqId
     */
    public function setLgbtqId(int $lgbtqId): void
    {
        $this->lgbtqId = $lgbtqId;
    }

    /**
     * @return string
     */
    public function getBirthDate(): string
    {
        return $this->birthDate;
    }

    /**
     * @param string $birthDate
     */
    public function setBirthDate(string $birthDate): void
    {
        $this->birthDate = $birthDate;
    }

    /**
     * @return int
     */
    public function getClientTypeId(): int
    {
        return $this->clientTypeId;
    }

    /**
     * @param int $clientTypeId
     */
    public function setClientTypeId(int $clientTypeId): void
    {
        $this->clientTypeId = $clientTypeId;
    }

    /**
     * @return int
     */
    public function getClientStatusId(): int
    {
        return $this->clientStatusId;
    }

    /**
     * @param int $clientStatusId
     */
    public function setClientStatusId(int $clientStatusId): void
    {
        $this->clientStatusId = $clientStatusId;
    }

    /**
     * @return int
     */
    public function getInBusiness(): int
    {
        return $this->inBusiness;
    }

    /**
     * @param int $inBusiness
     */
    public function setInBusiness(int $inBusiness): void
    {
        $this->inBusiness = $inBusiness;
    }

    /**
     * @return int
     */
    public function getYearStarted(): int
    {
        return $this->yearStarted;
    }

    /**
     * @param int $yearStarted
     */
    public function setYearStarted(int $yearStarted): void
    {
        $this->yearStarted = $yearStarted;
    }

    /**
     * @return int
     */
    public function getMonthStarted(): int
    {
        return $this->monthStarted;
    }

    /**
     * @param int $monthStarted
     */
    public function setMonthStarted(int $monthStarted): void
    {
        $this->monthStarted = $monthStarted;
    }

    /**
     * @return int
     */
    public function getInteractTypeId(): int
    {
        return $this->interactTypeId;
    }

    /**
     * @param int $interactTypeId
     */
    public function setInteractTypeId(int $interactTypeId): void
    {
        $this->interactTypeId = $interactTypeId;
    }

    /**
     * @return int
     */
    public function getServiceTypeId(): int
    {
        return $this->serviceTypeId;
    }

    /**
     * @param int $serviceTypeId
     */
    public function setServiceTypeId(int $serviceTypeId): void
    {
        $this->serviceTypeId = $serviceTypeId;
    }

    /**
     * @return string
     */
    public function getInteractionDate(): string
    {
        return $this->interactionDate;
    }

    /**
     * @param string $interactionDate
     */
    public function setInteractionDate(string $interactionDate): void
    {
        $this->interactionDate = $interactionDate;
    }

    /**
     * @return int
     */
    public function getTimeSpentId(): int
    {
        return $this->timeSpentId;
    }

    /**
     * @param int $timeSpentId
     */
    public function setTimeSpentId(int $timeSpentId): void
    {
        $this->timeSpentId = $timeSpentId;
    }

    /**
     * @return int
     */
    public function getPrepTimeId(): int
    {
        return $this->prepTimeId;
    }

    /**
     * @param int $prepTimeId
     */
    public function setPrepTimeId(int $prepTimeId): void
    {
        $this->prepTimeId = $prepTimeId;
    }

    /**
     * @return int
     */
    public function getTravelTimeId(): int
    {
        return $this->travelTimeId;
    }

    /**
     * @param int $travelTimeId
     */
    public function setTravelTimeId(int $travelTimeId): void
    {
        $this->travelTimeId = $travelTimeId;
    }

    /**
     * @return string
     */
    public function getNotes(): string
    {
        return $this->notes;
    }

    /**
     * @param string $notes
     */
    public function setNotes(string $notes): void
    {
        $this->notes = $notes;
    }

    /**
     * @return int
     */
    public function getBusStageId(): int
    {
        return $this->busStageId;
    }

    /**
     * @param int $busStageId
     */
    public function setBusStageId(int $busStageId): void
    {
        $this->busStageId = $busStageId;
    }

    /**
     * @return int
     */
    public function getFullTimeEmployees(): int
    {
        return $this->fullTimeEmployees;
    }

    /**
     * @param int $fullTimeEmployees
     */
    public function setFullTimeEmployees(int $fullTimeEmployees): void
    {
        $this->fullTimeEmployees = $fullTimeEmployees;
    }

    /**
     * @return int
     */
    public function getPartTimeEmployees(): int
    {
        return $this->partTimeEmployees;
    }

    /**
     * @param int $partTimeEmployees
     */
    public function setPartTimeEmployees(int $partTimeEmployees): void
    {
        $this->partTimeEmployees = $partTimeEmployees;
    }

    /**
     * @return int
     */
    public function getLoanAmount(): int
    {
        return $this->loanAmount;
    }

    /**
     * @param int $loanAmount
     */
    public function setLoanAmount(int $loanAmount): void
    {
        $this->loanAmount = $loanAmount;
    }

    /**
     * @return int
     */
    public function getEquityAmount(): int
    {
        return $this->equityAmount;
    }

    /**
     * @param int $equityAmount
     */
    public function setEquityAmount(int $equityAmount): void
    {
        $this->equityAmount = $equityAmount;
    }

    /**
     * @return int
     */
    public function getGrantAmount(): int
    {
        return $this->grantAmount;
    }

    /**
     * @param int $grantAmount
     */
    public function setGrantAmount(int $grantAmount): void
    {
        $this->grantAmount = $grantAmount;
    }

    /**
     * @return int
     */
    public function getRevenueAmount(): int
    {
        return $this->revenueAmount;
    }

    /**
     * @param int $revenueAmount
     */
    public function setRevenueAmount(int $revenueAmount): void
    {
        $this->revenueAmount = $revenueAmount;
    }

    /**
     * @return int
     */
    public function getBondingCapacityAmount(): int
    {
        return $this->bondingCapacityAmount;
    }

    /**
     * @param int $bondingCapacityAmount
     */
    public function setBondingCapacityAmount(int $bondingCapacityAmount): void
    {
        $this->bondingCapacityAmount = $bondingCapacityAmount;
    }

    /**
     * @return int
     */
    public function getContractAmount(): int
    {
        return $this->contractAmount;
    }

    /**
     * @param int $contractAmount
     */
    public function setContractAmount(int $contractAmount): void
    {
        $this->contractAmount = $contractAmount;
    }

    /**
     * @return int
     */
    public function getSellLocally(): int
    {
        return $this->sellLocally;
    }

    /**
     * @param int $sellLocally
     */
    public function setSellLocally(int $sellLocally): void
    {
        $this->sellLocally = $sellLocally;
    }

    /**
     * @return int
     */
    public function getSellRegionally(): int
    {
        return $this->sellRegionally;
    }

    /**
     * @param int $sellRegionally
     */
    public function setSellRegionally(int $sellRegionally): void
    {
        $this->sellRegionally = $sellRegionally;
    }

    /**
     * @return int
     */
    public function getSellNationally(): int
    {
        return $this->sellNationally;
    }

    /**
     * @param int $sellNationally
     */
    public function setSellNationally(int $sellNationally): void
    {
        $this->sellNationally = $sellNationally;
    }

    /**
     * @return int
     */
    public function getSellInternationally(): int
    {
        return $this->sellInternationally;
    }

    /**
     * @param int $sellInternationally
     */
    public function setSellInternationally(int $sellInternationally): void
    {
        $this->sellInternationally = $sellInternationally;
    }

    /**
     * @return int
     */
    public function getSellFedGovt(): int
    {
        return $this->sellFedGovt;
    }

    /**
     * @param int $sellFedGovt
     */
    public function setSellFedGovt(int $sellFedGovt): void
    {
        $this->sellFedGovt = $sellFedGovt;
    }

    /**
     * @return string
     */
    public function getUserIPAddress(): string
    {
        return $this->userIPAddress;
    }

    /**
     * @param string $userIPAddress
     */
    public function setUserIPAddress(string $userIPAddress): void
    {
        $this->userIPAddress = $userIPAddress;
    }

    /**
     * @return string
     */
    public function getSubmissionUrl(): string
    {
        return $this->submissionUrl;
    }

    /**
     * @param string $submissionUrl
     */
    public function setSubmissionUrl(string $submissionUrl): void
    {
        $this->submissionUrl = $submissionUrl;
    }
    /**
     * @return string
     */
    public function getDestinationUrl(): string
    {
        return $this->destinationUrl;
    }

    /**
     * @param string $submissionUrl
     */
    public function setDestinationUrl(string $destinationUrl): void
    {
        $this->destinationUrl = $destinationUrl;
    }
    /**
     * @return array
     */
    public function getCapitalRequested(): array
    {
        return $this->capitalRequested;
    }

    /**
     * @param array $capitalRequested
     */
    public function setCapitalRequested(array $capitalRequested): void
    {
        $this->capitalRequested = $capitalRequested;
    }

    /**
     * @return array
     */
    public function getCapitalSecured(): array
    {
        return $this->capitalSecured;
    }

    /**
     * @param array $capitalSecured
     */
    public function setCapitalSecured(array $capitalSecured): void
    {
        $this->capitalSecured = $capitalSecured;
    }

    /**
     * @param FundingCapital $capitalRequested
     */
    public function addCapitalRequested(FundingCapital $capitalRequested): void
    {
        $this->capitalRequested[] = $capitalRequested;
    }

    /**
     * @param FundingCapital $capitalSecured
     */
    public function addCapitalSecured(FundingCapital $capitalSecured): void
    {
        $this->capitalSecured[] = $capitalSecured;
    }
    /**
     * @param array $providersToRefer
     */
    public function setProvidersToRefer(array $providersToRefer): void
    {
        $this->providersToRefer = $providersToRefer;
    }

    /**
     * @param int $provider_id
     */
    public function addProvidersToRefer(int $provider_id): void
    {
        $this->providersToRefer[] = $provider_id;
    }
    /**
     * @return array
     */
    public function getProvidersToRefer(): array
    {
        return $this->providersToRefer;
    }
}