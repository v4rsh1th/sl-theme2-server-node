<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class UserOrg extends ApiBase
{
    //API NAMESPACE
    public function MachineName():string
    {
        return 'UserOrg';
    }

    //API NAMESPACE ENDPOINTS

    /**
     * GetAllUsers - Get All Users
     * @return array|null
     */
    public function GetAllUsers(): ?array
    {
        return self::Get($this->GetRoute("GetAllUsers"));
    }
    /**
     * GetMyUserOrg - Get User by Organization Id
     *
     * @return array|null
     */
    public function GetMyUserOrg(): ?array
    {
        return self::Get($this->GetRoute("GetUserOrg"));
    }
    /**
     * GetUserOrg - Get User by Organization Id
     *
     * @param int $userOrgId
     *
     * @return array|null
     */
    public function GetUserOrg(int $userOrgId): ?array
    {
        if(!is_numeric($userOrgId)) return null;
        return self::Get($this->GetRoute("GetUserOrg/". $userOrgId));
    }

    /**
     * UpdateUserOrg - Get User by Organization ID
     *
     * @param int $userOrgId
     *
     * @return array|null
     */
    public function UpdateUserOrg(int $userOrgId): ?array
    {
        if(!is_numeric($userOrgId)) return null;
        return self::Post($this->GetRoute("UpdateUserOrg/". $userOrgId));
    }

    /**
     * DeleteUserOrg - Delete User Organization
     *
     * @param int $userOrgId
     *
     * @return array|null
     */
    public function DeleteUserOrg(int $userOrgId): ?array
    {
        if(!is_numeric($userOrgId)) return null;
        return self::Post($this->GetRoute("DeleteUserOrg/". $userOrgId));
    }
}