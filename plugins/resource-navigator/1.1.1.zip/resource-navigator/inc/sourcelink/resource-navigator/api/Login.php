<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class Login extends ApiBase
{
    /**
     * @return string
     */
    public function MachineName():string
    {
        return 'Login';
    }
    //e5050408-0628-40b6-8378-5f88205246eb
    //API NAMESPACE ENDPOINTS

    /**
     * DoLogin - Retrieves a list of demographic filters
     *
     *
     * @return array|null
     */
    public function DoLogin(): ?array
    {
        $curl_out = ApiBase::Get($this->GetRoute($this->API_KEY));
        $result = ApiBase::ProcessResult($curl_out['body']);
        if(!empty($curl_out['headers'][0]['Set-Cookie'])){
            unset($_COOKIE['slrn_session']);
            setcookie('slrn_session', null, -1);
            $cookie    = self::getCookie($curl_out['headers'][0]['Set-Cookie']);
            $protocols = array('http://', 'https://');
            setcookie('slrn_session', $cookie, time()+300, '/', str_replace($protocols, '', get_bloginfo('url')));

            $_COOKIE['slrn_session'] = $cookie;

        }

        return $result;

    }
    
    /**
     * AuthenticateMagicLink - Retrieves a list of demographic filters
     *
     * @param array $args
     *
     * @return array|null
     */
    public function AuthenticateMagicLink(array $args =[]): ?array
    {
        $query = http_build_query(array_filter($args));
        return self::Get($this->GetRoute("AuthenticateMagicLink?" . $query));
    }
    
    /**
     * TestAPI - Retrieves a list of demographic filters
     *
     * @return array|null
     */
    public function TestAPI():?array
    {

        $curl_out = ApiBase::Get($this->GetRoute($this->API_KEY));
        $result = ApiBase::ProcessResult($curl_out['body']);
        
        if(!empty($curl_out['headers'][0]['Set-Cookie'])) {

            $cookie = self::getCookie($curl_out['headers'][0]['Set-Cookie']);

            setcookie('slrn_session', $cookie, time()+1800);

            $_COOKIE['slrn_session'] = $cookie;

        }

        return $result;
    }

    /**
     * @param $set_cookie
     *
     * @return array|string|string[]
     */
    public static function getCookie($set_cookie)
    {
        if (strpos($set_cookie, '; path=/; samesite=lax') !== false) $set_cookie = str_replace('; path=/; samesite=lax', '', $set_cookie);
        if (strpos($set_cookie, 'WS_AUTH_ID=') !== false) $set_cookie = str_replace('WS_AUTH_ID=', '', $set_cookie);
        return $set_cookie;
    }
}