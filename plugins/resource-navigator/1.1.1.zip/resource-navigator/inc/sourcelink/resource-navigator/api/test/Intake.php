<?php

namespace Sourcelink\ResourceNavigator\API\Test;


use Sourcelink\ResourceNavigator\API\Model\IntakeForm;

class Intake
{
    public $intake_form = [
        "intakeStagingId"=> 0,
          "intakeSettingsId"=> 508,
          "counselorId"=> 0,
          "companyName"=> "",
          "firstName"=> "Test",
          "lastName"=> "User",
          "email"=> "tuser@joinsourcelink.com",
          "workTitle"=> "Grunt",
          "webUrl"=> "https=>//www.joinsourcelink.com/",
          "facebookUrl"=> "",
          "twitterUrl"=> "",
          "address1"=> "4747 Troost Ave.",
          "address2"=> "",
          "zip"=> "64110",
          "countryIso"=> "US",
          "ruralUrbanId"=> 0,
          "legalState"=> "MO",
          "workPhone"=> "8165551212",
          "cellPhone"=> "",
          "homePhone"=> "",
          "fax"=> "",
          "targetMarket"=> "",
          "naicsId"=> 0,
          "entityId"=> 0,
          "taxIdNum"=> "",
          "referralEntityTypeId"=> 0,
          "providerId"=> 0,
          "womenOwned"=> 1,
          "minorityOwned"=> 1,
          "veteranOwned"=> 0,
          "immigrantOwned"=> 1,
          "internallyDisplPerOwned"=> 0,
          "justiceInvCitizenOwned"=> 0,
          "refugeeOwned"=> 0,
          "lgbtqOwned"=> 0,
          "youthOwned"=> 0,
          "lowIncomeOwned"=> 1,
          "disabledOwned"=> 0,
          "nonEnglishBusinessOwned"=> 0,
          "certWomenOwned"=> 1,
          "certMinorityOwned"=> 1,
          "certDisadvantagedOwned"=> 0,
          "certLGBTQOwned"=> 0,
          "certSerDisabledVetOwned"=> 0,
          "certVetOwned"=> 0,
          "certHUDSec3Owned"=> 0,
          "certDisabledOwned"=> 0,
          "cert8aOwned"=> 0,
          "homeBased"=> 0,
          "eCommerce"=> 1,
          "hasCommercialLocation"=> 0,
          "hasMobileBusiness"=> 0,
          "genderId"=> 2,
          "raceId1"=> true,
          "raceId2"=> true,
          "raceId3"=> true,
          "raceId4"=> true,
          "raceId5"=> false,
          "ethnicityId"=> 0,
          "educationBackgroundId"=> 0,
          "disabledId"=> 0,
          "militaryStatusId"=> 0,
          "veteranStatusId"=> 0,
          "lgbtqId"=> 0,
          "birthDate"=> "1991-08-31T21:07:26.622Z",
          "clientTypeId"=> 0,
          "clientStatusId"=> 0,
          "inBusiness"=> 0,
          "yearStarted"=> 0,
          "monthStarted"=> 0,
          "interactTypeId"=> 0,
          "serviceTypeId"=> 0,
          "interactionDate"=> "2021-08-29T21:07:26.622Z",
          "timeSpentId"=> 0,
          "prepTimeId"=> 0,
          "travelTimeId"=> 0,
          "notes"=> "Test interaction notes",
          "busStageId"=> 0,
          "fullTimeEmployees"=> 0,
          "partTimeEmployees"=> 0,
          "loanAmount"=> 0,
          "equityAmount"=> 0,
          "grantAmount"=> 0,
          "revenueAmount"=> 0,
          "bondingCapacityAmount"=> 0,
          "contractAmount"=> 0,
          "sellLocally"=> 0,
          "sellRegionally"=> 0,
          "sellNationally"=> 0,
          "sellInternationally"=> 0,
          "sellFedGovt"=> 0,
          "userIPAddress"=> "192.168.1.1",
          "submissionUrl"=> "https=>//getsiteconnex.com/contact-us/",
          "capitalRequested" => [
            '{"capitalTypeId":3,"capitalSourceId":1579,"capitalAmount":200.00}'
        ],
        "capitalSecured"=> [
            '{"capitalTypeId": 2,"capitalSourceId": 1180,"capitalAmount": 2000.00}'
        ]

    ]; //int

    public function TestIntakeObjectCreate()
    {
        $formObj = new IntakeForm($this->intake_form);
        return $formObj->toJSON();
    }



}