<?php

namespace Sourcelink\ResourceNavigator\API\Cache;



use Sourcelink\ResourceNavigator\API\DemographicFilter;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Service;
use Sourcelink\ResourceNavigator\API\ServiceCategories;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\CacheBase;

class ServiceCache extends CacheBase
{
    protected $api_namespace;
    protected $cache_keys = [

        'GetDemographicFilters' => "slrn_cached_fields",
    ];

    public function __construct(){
        $this->api_namespace = new Service(get_option('slrn_api_key'));
    }


    //return a list of all service categories
    public static function ServiceCategoryArray($lang = ""): array
    {
        $savedServices = get_option('slrn_cached_services');
        if (empty($savedServices)) {
            $savedServices = self::ServiceFullArray();
        }
        $rtn = [];
        if ( ! empty($savedServices)) {
            foreach ($savedServices as $serviceCat) {
                $rtn[$serviceCat['serviceCategoryId']] = $lang == "spanish" ? $serviceCat['serviceCategoryLabelSpanish'] : $serviceCat['serviceCategoryLabel'];
            }
        }

        return $rtn;
    }



    //Fetch and normalize data from api and return array
    public static function ServiceFullArray(): array
    {
        $data           = [];
        $serviceCatsObj = new ServiceCategories();
        $serviceObj     = new Service();

        $serviceCatsRaw = $serviceCatsObj->GetServiceCategories();
        $serviceRaw     = $serviceObj->GetServices();
        $results2       = ApiBase::ProcessResult($serviceCatsRaw['body']);
        $results3       = ApiBase::ProcessResult($serviceRaw['body']);
        $services       = $results3['result'];


        if (is_array($results2)) {
            $serviceCats = $results2['result'];
            if ( ! empty($serviceCats[0]['serviceCategoryAndServices'])) {
                foreach ($serviceCats[0]['serviceCategoryAndServices'] as $serviceCat) {
                    $tmp2 = [
                        'serviceCategoryId'    => $serviceCat['ServiceCategoryId'] ?? 0,
                        'userOrgId'            => $serviceCat['UserOrgId'] ?? 0,
                        'serviceCategoryLabel' => $serviceCat['ServiceCategoryLabel'] ?? null,
                        'serviceCategoryLabelSpanish' => $serviceCat['ServiceCategoryLabelSpanish'] ?? null,
                        'serviceByCategories'  => $serviceCat['serviceByCategories'] ?? [],
                        'listOrder'  => $serviceCat['ServiceCategoryOrder'] ?? 999
                    ];
                    if (isset($services)) {
                        if (is_array($services)) {
                            foreach ($services as $service) {
                                if ($service['ServiceCategoryId'] == $serviceCat['ServiceCategoryId']) {
                                    $tmp2['serviceByCategories'][] = [
                                        'serviceLabel' => $service['ServiceLabel'],
                                        'serviceLabelSpanish' => $service['ServiceLabelSpanish'],
                                        'serviceId'    => $service['ServiceId'],
                                        'listOrder'    => $service['ServiceOrder'] ?? 999,
                                    ];
                                }
                            }
                        }
                    }

                    $data[] = $tmp2;
                }
            }
        }

        return $data;
    }

}