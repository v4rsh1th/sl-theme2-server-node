<?php

namespace Sourcelink\ResourceNavigator\API\Test;


use Sourcelink\ResourceNavigator\API\Model\FundingCapital;

class FundingCapitalTest
{
    public $intake_form = [
        "capitalTypeId"   => 3,
        "capitalSourceId" => 1579,
        "capitalAmount"   => 200.00
    ]; //int

    /**
     * @return string
     */
    public function TestFundingCapitalObjectCreate(): string
    {
        $formObj = new FundingCapital($this->intake_form);

        return $formObj->toJSON();
    }

    public function TestIntakeObjectPopulation(): void
    {
        $formObj = new FundingCapital();

        try {

            $formObj->setCapitalAmount("27");
            print('
        ' . $formObj->getCapitalAmount());
        } catch (\Exception $e) {
            print($e->getMessage());
        }
        try {
            $formObj->setCapitalAmount(27);
            print('
        ' . $formObj->getCapitalAmount());
        } catch (\Exception $e) {
            print($e->getMessage());
        }
    }
}