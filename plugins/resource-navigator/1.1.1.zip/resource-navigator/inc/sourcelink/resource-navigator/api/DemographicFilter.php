<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class DemographicFilter extends ApiBase
{
    //API NAMESPACE
    /**
     * @return string
     */
    public function MachineName(): string
    {
        return 'DemographicFilter';
    }

    //API NAMESPACE ENDPOINTS
    /**
     * GetAvailableFilters - Retrieves a list of demographic filters
     *  args: includeGeography | bool
     *
     * @return array|null
     */
    public function GetAvailableFilters(): ?array
    {
        return self::Get($this->GetRoute('GetAvailableFilters'));
    }

    /**
     * GetAllDemographicFilters - Retrieves a list of all demographic filters
     *  args: includeGeography | bool
     *
     * @return array
     */
    public function GetAllDemographicFilters(): ?array
    {
        return self::Get($this->GetRoute('GetAllDemographicFilters'));
    }

    /**
     * GetDemographicFilters - Retrieves a list of demographic filters
     *  args: includeGeography | bool:false
     *  args: includeChildren | bool:false
     *
     * @param array $args
     *
     * @return array
     */
    public function GetDemographicFilters(array $args =[]): ?array
    {
        $query = http_build_query($args);
        return self::Get($this->GetRoute('GetDemographicFilters?' . $query));
    }

    /**
     * GetDemographicFilterByCategoryId - Retrieves a specific demographic filter listing
     *
     * @param int $categoryId : 5
     *
     * @return array
     */
    public function GetDemographicFilterByCategoryId(int $categoryId): ?array
    {
        if(!is_numeric($categoryId)) return null;
        return self::Get($this->GetRoute('GetDemographicFiltersByCategory/' . $categoryId));
    }

    /**
     * GetDemographicValuesByDemographicCategory - Retrieves a specific demographic filter listing
     *
     * @param int $categoryId : 5
     *
     * @return array
     */
    public function GetDemographicValuesByDemographicCategory(int $categoryId): ?array
    {
        if(!is_numeric($categoryId)) return null;
        return self::Get($this->GetRoute('GetDemographicValuesByDemographicCategory/' . $categoryId));
    }

    /**
     * GetDemographicFiltersByClient - Retrieves a listing of demographic filters supported by a specific client
     *
     * @param int $clientId : 106
     *
     * @return array
     */
    public function GetDemographicFiltersByClient(int $clientId): ?array
    {
        if(!is_numeric($clientId)) return null;
        return self::Get($this->GetRoute('GetDemographicFiltersByClient/' . $clientId));
    }

    /**
     * GetAllDemographicValue - Retrieves a listing of demographic values for a specific category
     *
     * @param int $demographicCategoryId : 5
     *
     * @return array
     */
    public function GetAllDemographicValue(int $demographicCategoryId): ?array
    {
        if(!is_numeric($demographicCategoryId)) return null;
        return self::Get($this->GetRoute('GetAllDemographicValue/' . $demographicCategoryId));
    }

    /**
     * GetProvidersForFilter - Retrieves a listing of providers that support a demographic value
     *
     * @param int $demographicValueId : 5
     *
     * @return array
     */
    public function GetProvidersForFilter(int $demographicValueId): ?array
    {
        if(!is_numeric($demographicValueId)) return null;
        return self::Get($this->GetRoute('GetProvidersForFilter/' . $demographicValueId));
    }

    /**
     * UpdateProvidersForFilter - Retrieves a listing of providers that support a demographic value
     *
     * @return array|null
     */
    public function UpdateProvidersForFilter(): ?array
    {
        return self::Put($this->GetRoute('UpdateProvidersForFilter'));
    }
}