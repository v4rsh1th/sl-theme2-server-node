<?php

namespace Sourcelink\ResourceNavigator\API\Model;

use Sourcelink\ResourceNavigator\ApiObjectBase;

class FundingCapital extends ApiObjectBase
{
    protected $capitalTypeId = 0; //int
    protected $capitalSourceId = 0; //int
    protected $capitalAmount = 0; //float

    /**
     * @return int
     */
    public function getCapitalTypeId(): int
    {
        return $this->capitalTypeId;
    }

    /**
     * @param int $capitalTypeId
     */
    public function setCapitalTypeId(int $capitalTypeId): void
    {
        $this->capitalTypeId = $capitalTypeId;
    }

    /**
     * @return int
     */
    public function getCapitalSourceId(): int
    {
        return $this->capitalSourceId;
    }

    /**
     * @param int $capitalSourceId
     */
    public function setCapitalSourceId(int $capitalSourceId): void
    {
        $this->capitalSourceId = $capitalSourceId;
    }

    /**
     * @return float
     */
    public function getCapitalAmount(): float
    {
        return $this->capitalAmount;
    }

    /**
     * @param float $capitalAmount
     */
    public function setCapitalAmount(float $capitalAmount): void
    {
        $this->capitalAmount = $capitalAmount;
    }


}