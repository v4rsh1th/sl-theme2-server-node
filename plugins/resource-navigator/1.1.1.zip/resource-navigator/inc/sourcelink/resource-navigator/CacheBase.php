<?php

namespace Sourcelink\ResourceNavigator;

use Sourcelink\ResourceNavigator\ApiBase;

class CacheBase
{
    protected $api_namespace;
    protected $cache_keys = [];

    /**
     * @param null $namespace
     * @param string|null $endpoint
     * @param string|null $key
     *
     * @return bool
     */
    public function CacheGetEndpoint($namespace = null, string $endpoint = null, string $key = null): bool
    {
        if($namespace === null || $endpoint === null || $key === null)
        {
            return false;
        }
        return $this->Cache($key,$this->ProcessRaw($namespace->$endpoint()));
    }
    public function GetCacheForEndpoint( string $endpoint = null): ?array
    {
        if( $endpoint === null)
        {
            return null;
        }
        return $this->Get($this->cache_keys[$endpoint]);
    }
    /**
     * @return array
     */
    public function CacheAll(): array
    {
        $rtn = [];

        foreach ($this->cache_keys as $endpoint=>$key){
            if($this->CacheGetEndpoint($this->api_namespace, $endpoint, $key)){
                $rtn[] = "Success! Cached $endpoint as option $key.";
            } else {
                $rtn[] = "Failed to cache $endpoint as option $key.";
            }
        }
        return $rtn;
    }

    /**
     * @return array
     */
    public function CheckAll(): array
    {
        $rtn = [];
        foreach ($this->cache_keys as $endpoint=>$key){
            if(get_option($key)){
                $rtn[] = "Cached $endpoint as option $key.";
            } else {
                $rtn[] = "Cache $key does not exist for $endpoint.";
            }
        }
        return $rtn;
    }
    /**
     * @return array
     */
    public function DeleteAll(): array
    {
        $rtn = [];
        foreach ($this->cache_keys as $key){
            delete_option($key);
        }
        return $rtn;
    }
    /**
     * @param $requestResult
     *
     * @return mixed
     */
    protected function ProcessRaw($requestResult)
    {
        $results = [];
        if (isset($requestResult['body'])) {
            $results = ApiBase::ProcessResult($requestResult['body']);
        }
        return $results['result'];
    }
    protected function Cache($key, $data): bool
    {
        return update_option($key, $data);
    }
    protected function Get($key): ?array
    {
        $data = get_option($key);
        if($data == false) return null;
        else return get_option($key);
    }
}