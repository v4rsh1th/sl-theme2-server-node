<?php
namespace Sourcelink\ResourceNavigator\Widget;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\TwigManager;
use WP_Widget;

class ResourceViewWidget extends WP_Widget
{

// The construct part
    /**
     * @param $id_base
     * @param $name
     * @param array $widget_options
     * @param array $control_options
     */
    public function __construct($id_base, $name, $widget_options = array(), $control_options = array() )
    {
        parent::__construct($id_base, $name, $widget_options = array(), $control_options = array() );
    }

// Creating widget front-end
    public function widget($args, $instance)
    {
    }

// Creating widget Backend
    public function form($instance)
    {
        $views = ResourceViewPost::SelectOptions();
        $view  = 0;
        if (isset($instance['view'])) {
            $view = $instance['view'];
        }
        $field = [

            'type'   => 'select',
            'value'  => $view,
            'values' => $views,
            'text'   => 'Resource View',
            'size'   => 'col-12',
            'hint'   => 'select the resource view to display in this widget',

        ];
        $twig  = 'inputs/select.twig';
        print TwigManager::Twig()->Render($twig, $field);
    }

// Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
    }

// Class wpb_widget ends here
}