<?php
namespace Sourcelink\ResourceNavigator\Utility;

use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;
use Sourcelink\ResourceNavigator\TwigManager;
class ResponseData
{
    public static function Bootstrap($arr)
    {
        add_action( 'admin_init', ['Sourcelink\ResourceNavigator\Utility\ResponseData', 'EnsureResponseTableExists'] );
    }

    //Table needs to exist
    public static function EnsureResponseTableExists()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'slrn_responses';
        $query      = $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name));
        if ( ! $wpdb->get_var($query) == $table_name) {

            $charset_collate = $wpdb->get_charset_collate();

            $sql = "CREATE TABLE $table_name (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  post_id mediumint(9) NOT NULL,
  data text NOT NULL,
  url varchar(55) DEFAULT '' NOT NULL,
  created_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    //Create record for unique url -> responses
    public static function SaveResponse(int $post_id, array $data):string
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'slrn_responses';
        $serialized = serialize($data);
        $url = self::CreateURL();
        $success = $wpdb->insert($table_name,[
            'post_id' => intval($post_id),
            'data' => $serialized,
            'url' => $url,
            'created_date' => date('Y-m-d H:i:s', strtotime('now'))
        ]);
        if($success !== false){
        return $url;
        }
        return '';
    }

    //Get the row from the table
    public static function GetResponse(string $url):array
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'slrn_responses';
        $my_row = $wpdb->get_row( "SELECT * FROM $table_name WHERE url = '$url'",ARRAY_A );
        if($my_row != null){
            return $my_row;
        }

        return [];
    }

    //Create the url random string
    public static function CreateURL(): string
    {
        $url = bin2hex(random_bytes(20));
        while(!self::IsURLUnique($url))
        {
            $url = bin2hex(random_bytes(20));
        }
        return $url;

    }

    //Make sure this url only exists once in the database
    public static function IsURLUnique(string $url): bool
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'slrn_responses';
        $results = $wpdb->get_results("SELECT id FROM $table_name WHERE url = '$url' LIMIT 1");
        if (empty ($results)) {
            return true;
        }
        return false;
    }

    //Make sure this url only exists once in the database
    public static function EmailLink(string $email, string $url): bool
    {
        $subject = 'Thank you for the Inquiry';
        $body = 'Here is a link to the information and providers from your form submission. <a href="'.$url.'" target="_blank">'.$url.'</a>';
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        return wp_mail( $email, $subject, $body, $headers );
    }
}