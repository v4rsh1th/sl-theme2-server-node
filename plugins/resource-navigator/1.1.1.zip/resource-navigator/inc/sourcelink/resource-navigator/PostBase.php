<?php
namespace Sourcelink\ResourceNavigator;

use WP_Query;

class PostBase
{
    use SaveTrait;

    private $_post_types;
    private $_post_ids;
    private $_templates;
    private $_overrides;

    // PostBase constructor.
    public function __construct()
    {
        $this->_post_types = [];
        $this->_post_ids   = [];
        $this->_templates  = [];
        $this->_overrides  = [];
    }

    /**
     *
     *
     * @param mixed $ids
     *
     * @return mixed $customPost
     */
    public static function Bootstrap($ids = [])
    {
        $key = get_option('slrn_api_key');
        if(empty($key)) return '';
        $class      = get_called_class();
        $customPost = new $class();
        $customPost->Register($ids);
        add_filter( 'manage_'.$customPost->MachineName().'_posts_columns', [$class, 'posts_columns'] );
        add_action( 'manage_'.$customPost->MachineName().'_posts_custom_column', [$class, 'posts_column_data'], 10, 2 );
        add_action( 'get_header', [$class, 'run_before_header'] );
        return $customPost;
    }
//add_action( 'add_meta_boxes',  function() {
//    add_meta_box('html_myid_61_section', 'TITLEEEEE', 'my_output_function');
//});

//    function my_output_function( $post ) {
//        $text= get_post_meta($post, 'SMTH_METANAME' , true );
//        wp_editor( htmlspecialchars($text), 'mettaabox_ID', $settings = array('textarea_name'=>'MyInputNAME') );
//    }
    public static function posts_columns( $columns ) {
        return $columns;
    }

    public static function posts_column_data( $column, $post_id ) {

    }
    public static function run_before_header( $name ) {
    }
    /**
     * Name of the admin panel
     *
     * @return string
     */
    public function Name(): string
    {
        return 'Post';
    }

    // Register all the post lifecycle callbacks inside WordPress.
    public function Register()
    {
        add_action('init', array($this, '_create_custom'));
        add_action('admin_init', array($this, '_meta_custom_boxes'));
        add_action('save_post', array($this, '_save_meta'), 10, 3);
        add_action('transition_post_status', array($this, '_update_status'), 10, 3);
    }

    /**
     *
     *
     * @param int $post
     *
     * @return array[] $rtn
     */
    public static function MetaValues(int $post): array
    {
        $class      = get_called_class();
        $customPost = new $class();
        $rtn        = ['meta' => [], 'meta_lists' => []];
        foreach ($customPost->GetInputs() as $container) {
            if ($container['type'] == 'panel') {
                foreach ($container['inputs'] as $meta => $details) {
                    if ($details['type'] == 'filter') {
                        $order = get_post_meta($post, $customPost->prefix($meta) . '_order', true);
                        $rtn['meta']['filters'][$order]['default'] = get_post_meta($post, $customPost->prefix($meta), true);
                        $rtn['meta']['filters'][$order]['name'] = $meta;
                        $rtn['meta']['filters'][$order]['name_val'] = get_post_meta($post, $customPost->prefix($meta) . '_name', true);;
                        $rtn['meta']['filters'][$order]['title'] = $details['text'];
                        foreach ($details['settings'] as $meta2 => $details2) {
                            $rtn['meta']['filters'][$order]['settings'][$meta2] = get_post_meta($post, $customPost->prefix($meta) . '_settings_' . $meta2, true);
                        }
                    } else {

                        $rtn['meta'][$meta] = get_post_meta($post, $customPost->prefix($meta), true);
                    }

                }
            } elseif ($container['type'] == 'repeater') {
                $rtn['meta_lists'][$container['id']] = get_post_meta($post, $customPost->prefix($container['id']), true);
            }
        }
        if(!empty($rtn['meta']['filters'])){
            ksort($rtn['meta']['filters']);
        }
        return $rtn;
    }

    /**
     * @return array $overrides
     */
    public function GetDefaults(): array
    {
        return $this->_overrides;
    }

    /**
     * @param array $overrides
     */
    public function SetDefaults(array $overrides = [])
    {
        $this->_overrides = $overrides;
    }

    // Callback to create the tab and edit pages inside WordPress.
    public function _create_custom()
    {
        register_post_type($this->MachineName(), $this->GetArgs($this->_overrides));
    }

    /**
     * Determines via get parameters if the object should display its meta box content.
     * Post base only uses post type to display its meta box info.
     */
    public function _meta_custom_boxes()
    {
        $filtered = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);

        $add      = false;
        if (isset($filtered['post']) && get_post_type($filtered['post']) == $this->MachineName()) {
            $add = true;
        } elseif (isset($filtered['post_type']) && $filtered['post_type'] == $this->MachineName()) {
            $add = true;
        }

        if ($add) {
            add_meta_box(
                $this->MachineName() . '_meta_box',
                $this->Name() . ' Details',
                array($this, '_display_custom_meta_box'),
                $this->MachineName(),
                'normal',
                'high'
            );
        }
    }

    /**
     *
     *
     * @param array $default
     *
     * @return array $rtn
     */
    public static function SelectOptions(array $default = []): array
    {
        $class = get_called_class();
        $obj   = new $class();

        if ( ! is_array($default) && $default != '') {
            $default = array($default);
        }

        global $wpdb;

        $sql    = 'SELECT t1.post_title, t1.ID ';
        $sql    .= 'FROM '.$wpdb->prefix.'posts t1 ';
        $sql    .= 'WHERE t1.post_type = "' . $obj->MachineName() . '" ';
        $sql    .= 'AND t1.post_status = "publish" ';
        $sql    .= 'ORDER BY t1.post_title ';
        $my_rows = $wpdb->get_results($sql);
        $rtn = [];
        if ($my_rows && ! is_wp_error($my_rows)) {
            foreach ($my_rows as $row) {
                $rtn[$row->ID] = $row->post_title;
            }
        }

        return $rtn;
    }

    /**
     * Helper function to return all the WordPress label syntax's.
     *
     * @return array
     */
    public function GetLabels(): array
    {
        return array(
            'name'               => '' . $this::PluralName(),
            'singular_name'      => '' . $this::Name(),
            'add_new'            => 'Add ' . $this::PluralName(),
            'add_new_item'       => 'Add New ' . $this::Name(),
            'edit_item'          => 'Edit ' . $this::Name(),
            'new_item'           => 'New ' . $this::Name(),
            'all_items'          => 'All ' . $this::PluralName(),
            'view_item'          => 'View ' . $this::Name(),
            'search_items'       => 'Search ' . $this::PluralName(),
            'not_found'          => 'No ' . $this::PluralName() . ' found',
            'not_found_in_trash' => 'No ' . $this::PluralName() . ' found in Trash',
            'parent_item_colon'  => ':',
            'menu_name'          => $this::Name()
        );
    }

    /**
     * Returns the default array of settings for this post object. Allows subclasses to override these settings by
     * overriding the function and passing in an array of settings to its parent method.
     *
     * @param array $overrides
     *
     * @return array
     */
    public function GetArgs(array $overrides = []): array
    {
        $args = array(
            'labels'             => $this->GetLabels(),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => ['slug' => $this->MachineName()],
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'viewless'           => false,
            'supports'           => ['title', 'editor'],
            'show_in_rest'       => true,
            'rest_base'          => $this->MachineName(),
            'taxonomies'         => []
        );

        if (count($overrides)) {
            $args = array_merge($args, $overrides);
        }

        return $args;
    }

    // ADMIN DISPLAY

    /**
     * Determine if the admin box should display
     *
     * @param $post - post being viewed
     */
    public function _display_custom_meta_box($post)
    {
        if ( ! $this->_shouldActivate($post)) {
            return;
        }
        $this->display_custom_meta_box($post);
    }

    /**
     * Save callback. Limited to this custom post type. This method is where meta should be saved.
     *
     * @param $id
     * @param $post
     */
    public function _save_meta($id, $post)
    {
        if ($this->_shouldActivate($post) && !empty($_POST)) {
            $this->save_meta($post->ID);
        }
    }

    /**
     * Update callback. Limited to this custom post type. This method is where meta should be saved.
     *
     * @param $new_status
     * @param $old_status
     * @param $post
     */
    public function _update_status($new_status, $old_status, $post)
    {
        if ($new_status == 'publish' && $this->_shouldActivate($post)) {
            $this->post_changed_status($post);
        } elseif ($new_status == 'trash' && $this->_shouldActivate($post)) {
            $this->delete($post);
        }
    }

    /**
     * Helper function to determine if this object should perform actions. Limited by post type, ID and template.
     *
     * @param $post
     *
     * @return bool
     */
    private function _shouldActivate($post): bool
    {
        if (in_array($post->post_type, $this->_post_types)) {
            return true;
        }
        if (in_array($post->ID, $this->_post_ids)) {
            return true;
        }
        if (get_post_type($post->ID) == $this->MachineName()) {
            return true;
        }

        $template_file = get_post_meta($post->ID, '_wp_page_template', true);
        if (in_array($template_file, $this->_templates)) {
            return true;
        }

        return false;
    }





    //***********************************************************************************************************************
    //***********************************************************************************************************************
    // OVERRIDE THESE FUNCTIONS
    //***********************************************************************************************************************
    //***********************************************************************************************************************


    /**
     * Nice name for object
     *
     * @return string
     */
    public function PluralName(): string
    {
        return $this->Name() . 's';
    }

    /**
     * Override here to track post status changes. Back end events usually.
     *
     * @param $post
     */
    public function post_changed_status($post)
    {
    }

    /**
     * Override here to delete this object's meta info or call an API and remove the object there.
     *
     * @param $post
     */
    public function delete($post)
    {
    }


    /**
     *
     * @param int $id
     * @param string $field
     * @param mixed $data
     *
     * @return bool|int
     */
    public function saveDBValue(int $id, string $field, $data)
    {
        return update_post_meta($id, $field, $data);
    }

    /**
     *
     * @param int $id
     * @param string $field
     * @param bool $single
     *
     * @return mixed
     */
    public function getDBValue(int $id, string $field, bool $single = true)
    {
        return get_post_meta($id, $field, $single);
    }

    /**
     * Override this to print html meta box content
     *
     * @param $post
     */
    public function display_custom_meta_box($post)
    {
        $this->DisplayFields($post->ID);
    }

    /**
     *
     * @param callable $callback
     * @param array $attributes
     */
    public function getObjects(callable $callback, array $attributes = [])
    {
        $defaults = array(
            'posts_per_page' => -1,
            "post_type"      => $this->MachineName(),
            "post_status"    => "publish",
            'orderby'        => 'title',
            'order'          => 'ASC',

        );

        $attributes = wp_parse_args($attributes, $defaults);
        $query = new WP_Query($attributes);
        $callback($query->posts, $query);
        wp_reset_query();
    }

    /**
     * @return array
     */
    public function GetJs(): array
    {
        return [];
    }

    /**
     * @param array $attributes
     * @param array $data
     *
     * @return string
     */
    public static function Render(array $attributes = [], array $data = []): string
    {
        //Return nothing if no id provided
        if(empty($attributes['id'])) return '';

        //Get an instance of this post object class
        $staticClass = get_called_class();
        $obj  = new $staticClass();


        //get all data for this post
        $the_post = get_post($attributes['id']);
        $data['post'] = ResourceNavigatorUtilityBase::GetPostProperties($the_post, $staticClass);

        //Determine layout file to use
        $alternateLayout = $attributes['layout'] ?? $data['post']['meta']['layout'] ?? '';

        $twig = ResourceNavigatorUtilityBase::FindVariant($obj->MachineName(), 'view', 'twig', $alternateLayout) ;

        //render something... or nothing
        return !empty($twig) ? TwigManager::Twig()->Render($twig, $data) : '';
    }

}