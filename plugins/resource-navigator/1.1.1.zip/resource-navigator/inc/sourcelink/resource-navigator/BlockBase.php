<?php
/*
 * @desctiption :
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator;

use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase as ResourceNavigatorUtilityBase;

class BlockBase {

    protected function supportedPostTypes() {
        return [];
    }

    public function isMainEnabled() {
        return false;
    }

    public function allowedBlocks() {
        return '';
    }

    public function blockTemplate() {
        return [];
    }

    public function isCardList() {
        return false;
    }

    public function blockTemplateLock() {
        return '';
    }

    final public function getMainInputs() {
        $defaults = [];
        if($this->isMainEnabled()) {
            if($this->MachineName() == 'button-block') {
                $defaults = [
                    'richtext' => [
                        'title' => 'RichText',
                        'type' => 'richtext',
                    ]
                ];
            }
            else {
                $defaults = [
                    'wizzy' => [
                        'title' => 'WYSIWYG',
                        'type' => 'wizzy',
                        'allowedBlocks' => $this->allowedBlocks(),
                        'template' => $this->blockTemplate(),
                        'templateLock' => $this->blockTemplateLock(),
                    ]
                ];
            }
        }
        return $defaults;
    }
    public function GetSidebarInputs() {
        return [];
    }
    public function getAdvancedSidebarInputs() {
        return [];
    }
    final public function GetInputs() {
        return [
            'main' => $this->getMainInputs(),
            'sidebar' => $this->GetSidebarInputs(),
            'advanced' => $this->getAdvancedSidebarInputs()
        ];
    }
    /**
     * Name for the block in the block selector popover.
     *
     * @return string
     */
    public function Name() {
        return '';
    }
    /**
     * Machine readable index for the block. Appended to the resource-navigator-category and identifies the specific block in the shortcode-like
     * syntax of block html comments
     *
     * @return string
     */
    public function MachineName() {
        return '';
    }

    /**
     * Provides wordpress with the html output with data input in the UI. Invoked by the wp engine. $attributes will contain
     * all non-wysiwyg content, $content holds that string.
     *
     * @param array $attributes
     * @param string|null $content
     *
     * @return string
     */
    public function Display(array $attributes, string $content = null): string
    {
        return '';
    }

    /**
     * Static method first invoked by wordpress for the shortcode to get display. Passed to ->render instance method.
     *
     * @param $attributes
     * @param null $content
     *
     * @return string
     */
    public static function Render($attributes, $content=null): string
    {
        $class=get_called_class();
        $obj = new $class();
        return $obj->Display($attributes, $content);
    }
    // Register all the shortcodes within wordpress.
    public static function Bootstrap() {
        $class=get_called_class();
        $obj = new $class();
        add_action( 'init', [$obj, '_guten_render'] );
        add_action('admin_enqueue_scripts', [$obj, '_add_js_array'], 99);

    }
    /**
     * Registers the block in wordpress' php core with a php renderer rather than javascript renderer. Allows us to use
     * twig to output the display for blocks instead of react.
     */
    public function _guten_Render() {
        register_block_type( 'sl-resource-navigator/'. $this->MachineName(), array(
            'render_callback' => function($attributes, $content) {
                $class=get_called_class();
                return $class::Render($attributes, $content);
            },
        ));
    }

    /**
     * Add Js
     *
     */
    public function _add_js_array(){

        $inputs = $this->GetInputs();

        $icon = '';


        if(!empty($this->supportedPostTypes()) && !empty(get_the_ID())) {
            if(!in_array(get_post_type(get_the_ID()), $this->supportedPostTypes())) {
                return;
            }
        }


        // Make js string to append after admin js.
        $js_string = 'window.SLRNBlocks.addBlock.register("'. $this->MachineName() .'", "'. $this->Name() .'", '. json_encode($inputs).', "'. $this->getParent() .'", '. $icon .');';

        wp_add_inline_script('slrn-guten-script', $js_string);

        //tileWidth
        if($this->isCardList()) {
            add_action('admin_head', function () {
                echo '<style>
                        div[data-type="sl-resource-navigator/'. $this->MachineName() .'"]  > div > div > div > .styleWrap > div > div { display: flex; flex-flow: wrap; }
                        div[data-type="sl-resource-navigator/'. $this->MachineName() .'"] > div > div > div > .styleWrap > div > div > div.block-list-appender { width: 100%; }
                        
                        div[data-type="sl-resource-navigator/'. $this->MachineName() .'"] > div > div > div > .styleWrap > div > div > div:not(.block-list-appender) { 
                            flex: 0 0 33.33%;
                            max-width: 33.33%;
                            margin: 0;
                         }
                    </style>';
            });
        }
    }

    /**
     * String of the ResourceNavigator block that would only own this item. IE Slides should only appear in Sliders
     *
     * @return string
     */
    public function getParent() {
        return '';
    }

    /**
     * Reads the plugin and theme twig folders for all twigs associated with a block for use in layout selectors.
     * Only used for specific blocks. Blocks that represent other wordpress objects (meta, posts) can't use this because
     * the layouts for those objects must be read dynamically. This will only read layouts on pageload.
     *
     * @return array
     */
    public function getLayouts() {
        $rtn = [];

        $sourceDirs = [
            TwigManager::internalTwigs()
        ];

        foreach($sourceDirs as $dir) {

            $base_dir = $dir . "/blocks/";
            $variants_dir = $base_dir . "variants/" . $this->MachineName() . "/";

            if(is_dir($variants_dir)) {
                foreach (glob($variants_dir . "*.twig") as $filename) {
                    $filename = str_replace('.twig', '',basename($filename));
                    $rtn[$filename] = ucwords(str_replace('-', ' ', $filename));
                }
            }

            $filename = glob($base_dir . $this->MachineName() . ".twig");

            if(is_dir($base_dir) && $filename) {
                $filename = str_replace('.twig', '',basename($filename[0]));
                $rtn[$filename] = "Default";
            }
        }



        return $rtn;
    }


    /**
     * Returns an array of colors defined in the _variables.scss file in the selected theme for use in color pickers in
     * the block admin.
     *
     * @return array
     */
    public function getBrandColors() {
        $sass_vars = "";
        $file_to_read = ResourceNavigatorUtilityBase::GetAssetURI('css/scss/_variables.scss');
        if(file_exists($file_to_read)) {
            $sass_vars = file_get_contents(ResourceNavigatorUtilityBase::GetAssetURI('css/scss/_variables.scss'));
        }
        $re = '/[ ]*\$color-?(.*?):(.*?);/im';
        preg_match_all($re, $sass_vars, $matches, PREG_SET_ORDER, 0);

        $rtn = [];
        foreach($matches as $match) {
            if(strpos(trim($match[2]), '$') === false) {
                $rtn[$match[1]] = trim($match[2]);
            }
        }
        return $rtn;
    }

    /**
     * Override to return an svg relative to the selected theme for use in the wordpress block admin. Default will be
     * the default Icon
     *
     * @return array|null
     */
    public function getIcon(): ?array
    {
        return null;
    }
}
