<?php

namespace Sourcelink\ResourceNavigator\Settings;

use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;
use Sourcelink\ResourceNavigator\TwigManager;

class ReferralRegions extends SettingsBase
{

    public function Name(): string
    {
        return 'Regions';
    }

    public function MachineName(): string
    {
        return 'referral_regions';
    }


    public function GetInputs(): array
    {



        return [
            [
                'type'   => 'repeater',
                'id'     => 'regions',
                'prefix' => 'reg',
                'header' => 'Regions',
                'inputs' => [
                    'title'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Field Label',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => '',
                    ],
                    'type'    => [
                        'type'   => 'select',
                        'values' => [''=>'-- select type --', 'state' => 'State', 'zip' => 'Region of Zips'],
                        'text'   => 'Region Type',
                        'size'   => 'col-12  col-md-6',
                        'hint'   => 'Select a Region type',
                    ],
                    'state' => [
                        'type'      => 'select',
                        'value'     => '',
                        'text'      => 'State',
                        'values' => ResourceNavigatorUtilityBase::StateArray(),
                        'size'      => 'col-12  col-md-6 col',
                        'hint'      => 'choose a state',
                        'conditional' => [
                            [
                                'field'=>  'reg_referral_regions_type',
                                'value'=>  'state',
                                'operator' => '==',
                                'repeater' => true,
                            ]
                        ],
                    ],

                    'zip' => [
                        'type'      => 'textarea',
                        'value'     => '',
                        'text'      => 'Zips',
                        'hint'      => 'Comma separated list of zips',
                        'size'      => 'col-12 col-md-6',
                        'conditional' => [
                            [
                                'field'=>  'reg_referral_regions_type',
                                'value'=>  'zip',
                                'operator' => '==',
                                'repeater' => true,
                            ]
                        ],
                    ],
                ]
            ]

        ];
    }

    public function Display()
    {

        print TwigManager::Twig()->Render('admin/form.twig', ['content'=>$this->GetFields(), 'id'=>$this->MachineName()]);


    }
    public function DisplayTab()
    {

        return TwigManager::Twig()->Render('admin/form.twig', ['content'=>$this->GetFields(), 'id'=>$this->MachineName()]);


    }

}