<?php

namespace Sourcelink\ResourceNavigator\Settings;
use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;

class HelpSettings extends SettingsBase
{
    public function Register(){

        add_submenu_page(
            'admin.php?page=resource_navigator',
            __( 'Need Help?', 'slrn' ),
            __( '<div id="slrn-help-link">Need Help?</div>', 'slrn' ),
            'manage_options',
            'https://help.joinsourcelink.com/'
        );
    }

    public function MachineName():string {
        return 'help';
    }

    public function Display() {




    }

}