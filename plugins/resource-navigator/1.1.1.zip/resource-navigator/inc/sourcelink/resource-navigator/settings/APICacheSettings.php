<?php

namespace Sourcelink\ResourceNavigator\Settings;
use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;

class APICacheSettings extends SettingsBase
{
    public function save_meta($id = ''){
        if(isset($_POST['slrn_update'])) {
            $this->flush_cache();
        }

    }
    public function Notice(){

    }
    public function Name():string {
        return 'API Cache';
    }
    public function MachineName():string {
        return 'cache_settings';
    }

    public function Display() {

        if(isset($_POST['slrn_flush'])) {
            $this->flush_cache();
        }
        if(isset($_POST['slrn_empty'])) {
            $this->empty_cache();
        }

        ?>

        <div class="slrn-admin-component">
            <div class="row">
                <div class="col-12">
                    <form method="post" action="" class="d-inline-block">
                        <input type="hidden" name="slrn_flush" id="slrn_flush" value="1">
                        <button type="submit" class="button-primary">Flush API Cache</button>
                    </form>
                    <form method="post" action="" class="d-inline-block">
                        <input type="hidden" name="slrn_empty" id="slrn_empty" value="1">
                        <button type="submit" class="button-primary">Empty API Cache</button>
                    </form>
                </div>
                <div class="col-12">
                        <pre><?php
                            $demoData = get_option('slrn_cached_fields');
                            $serviceData = get_option('slrn_cached_services');
                            $cacheDate = get_option('slrn_cached_date');

                            if(!empty($demoData)) echo "Demographic categories / filters cached!\n";
                            if(!empty($serviceData)) echo "Service Categories / Services categories cached!\n";
                            $intakeObj = new IntakeCache();
                            $cacheStatuses = $intakeObj->CheckAll();
                            foreach ($cacheStatuses as $status){
                                echo "$status\n";
                            }
                            if(!empty($cacheDate)) {
                                $date = new \DateTime();
                                $date->setTimestamp($cacheDate)->setTimezone(new \DateTimeZone('America/Chicago'));
                            }
                             echo "Last Cached Date: " . $date->format("F j, Y - h:i:sa (e)");
                            ?>
                        </pre>
                </div>
            </div>
        </div>
        <?php

    }
    public function DisplayTab() {

        if(isset($_POST['slrn_flush'])) {
            $this->flush_cache();
        }
        if(isset($_POST['slrn_empty'])) {
            $this->empty_cache();
        }
        ob_start();
        ?>

        <div class="slrn-admin-component">
            <div class="row">
                <div class="col-12">
                    <form method="post" action="" class="d-inline-block">
                        <input type="hidden" name="slrn_flush" id="slrn_flush" value="1">
                        <button type="submit" class="button-primary">Flush API Cache</button>
                    </form>
                    <form method="post" action="" class="d-inline-block">
                        <input type="hidden" name="slrn_empty" id="slrn_empty" value="1">
                        <button type="submit" class="button-primary">Empty API Cache</button>
                    </form>
                </div>
                <div class="col-12">
                        <pre><?php
                            $demoData = get_option('slrn_cached_fields');
                            $serviceData = get_option('slrn_cached_services');
                            $cacheDate = get_option('slrn_cached_date');

                            if(!empty($demoData)) echo "Demographic categories / filters cached!\n";
                            if(!empty($serviceData)) echo "Service Categories / Services categories cached!\n";
                            $intakeObj = new IntakeCache();
                            $cacheStatuses = $intakeObj->CheckAll();
                            foreach ($cacheStatuses as $status){
                                echo "$status\n";
                            }
                            if(!empty($cacheDate)) {
                                $date = new \DateTime();
                                $date->setTimestamp($cacheDate)->setTimezone(new \DateTimeZone('America/Chicago'));
                            }
                            echo "Last Cached Date: " . $date->format("F j, Y - h:i:sa (e)");
                            ?>
                        </pre>
                </div>
            </div>
        </div>
        <?php
        $content = ob_get_clean();
        return $content;
    }
    public function flush_cache(){
        $login = new Login(get_option('slrn_api_key'));
        $login->DoLogin();
        $IntakeCache = new IntakeCache();
        update_option('slrn_cached_fields', DemographicCache::FilterFullArray());
        update_option('slrn_cached_services', ServiceCache::ServiceFullArray());
        $IntakeCache->CacheAll();
        update_option('slrn_cached_date', time());
    }

    public function empty_cache(){
        $login = new Login(get_option('slrn_api_key'));
        $login->DoLogin();
        $IntakeCache = new IntakeCache();
        delete_option('slrn_cached_fields');
        delete_option('slrn_cached_services');
        $IntakeCache->DeleteAll();
        update_option('slrn_cached_date', time());
    }
}