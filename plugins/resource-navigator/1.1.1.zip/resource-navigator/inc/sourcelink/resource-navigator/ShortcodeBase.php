<?php
/*
 * @desctiption :
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator;

class ShortcodeBase {




    /**
     * Return an array of inputs used to generate the interface in the defunct shortcode tool.
     *
     * @return array $defaults
     */
	public function GetInputs() {
        return [];
	}
	/**
	 * Return the shortcode pretty name for use in the defunct shortcode tool.
	 *
	 * @return string
	 */
	public function Name() {
		return '';
	}
	/**
	 * Shortcode used in wysiwyg
	 *
	 * @return string
	 */
	public function MachineName() {
		return '';
	}

    /**
     * Callback invoked by wordpress when wordpress processes the shortcode. Atts will represent the attributes inside the
     * shortcode tag. Content will hold all content between the opening and closing shortcode tag.
     *
     * @param  $attributes
     * @param string|null $content
     *
     * @return string
     */
	public function Display( $attributes, ?string $content = null) {
		return '';
	}

    /**
     * Helper method that passes the render call from a static wp engine context to instance method.
     *
     * @param  $attributes
     * @param string|null $content
     *
     * @return object
     */
	public static function Render( $attributes, ?string $content=null): object
    {
		$class=get_called_class();
		$obj = new $class();
		return $obj->Display($attributes, $content);
	}
	// Register all the shortcodes within wordpress.
	public static function Bootstrap() {
		$class=get_called_class();
		$obj = new $class();
		add_shortcode( $obj->MachineName(), array( $obj, 'Display' ) );

        add_action('init', array($obj, 'WPBakery'));

	}
    public function WPBakery() {

    }
}