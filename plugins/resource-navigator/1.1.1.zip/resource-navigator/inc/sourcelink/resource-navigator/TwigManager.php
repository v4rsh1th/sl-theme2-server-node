<?php
/*
 * @desctiption : Initiates basic twig functionality in ResourceNavigator
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2017/08/29    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/


namespace Sourcelink\ResourceNavigator;


use ComposerAutoloaderInit16d8f9d46e5bc0d876bd042b2f717297;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\Post\WebFormPost;
use Twig\Environment;
use Twig\Extension\DebugExtension;
use Twig\Loader\FilesystemLoader;
use Twig\Markup;
use Twig\TwigFilter;
use Twig\TwigFunction;

class TwigManager
{

    private static $instance;
    private $twig;
    protected $filters;
    protected $functions;


    public function __construct()
    {
    }

    /**
     * Setup the class
     */
    public static function Bootstrap()
    {
        $twigManager = TwigManager::getInstance();
        $twigManager->Register();
    }

    /**
     * Return internal twig directory
     *
     * @return string|null
     */
    public static function internalTwigs()
    {
        return WP_PLUGIN_DIR . '/resource-navigator/inc/sourcelink/assets/twig';
    }


    /**
     * Register all twigs, filters and functions
     */
    public function Register()
    {
        $paths      = [
            self::internalTwigs(),
        ];
        $loader     = new FilesystemLoader($paths);
        $this->twig = new Environment($loader, ['debug' => true]);
        $this->twig->addExtension(new DebugExtension());
        $this->registerFilters();
        $this->registerFunctions();
    }

    /**
     * Register all custom twig filters
     */
    public function registerFilters()
    {
        /**
         * add theme source to file / path provided
         * usage: {{ image|ThemeSource }}, {{ image|ThemeSource|MakeImage() }}
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('ThemeSource', function ($string) {
            return ResourceNavigatorUtilityBase::GetAsset($string);
        });

        /**
         * Apply the_content filter to string (wpautop by default, can be disabled)
         * usage: {{ content|WPContent }} {{ content|WPContent(false) }}
         *
         * @param $string
         * @param $useAutoP
         */
        $this->filters[] = new TwigFilter('WPContent', function ($string, $useAutoP = true) {
            if ($useAutoP) {
                add_filter('the_content', 'wpautop');
            }
            $rtn = apply_filters('the_content', $string);
            if ($useAutoP) {
                remove_filter('the_content', 'wpautop');
            }

            return new Markup($rtn, 'UTF-8');
        });

        $this->filters[] = new TwigFilter('preg_replace', function ($subject, $pattern, $replacement) {
            return preg_replace($pattern, $replacement, $subject);
        });
        $this->filters[] = new TwigFilter('get_filter_key', function ($subject) {

            return ResourceViewPost::getfilterKey($subject);
        });
        /**
         * turn  url into <img> with alt and passed classes
         * usage: {{ url|makeImg }} or {{ url|makeImg(title) }} or {{ url|makeImg(title, 'a list of classes') }}
         *
         * @param $string
         * @param $title
         * @param $classes
         */
        $this->filters[] = new TwigFilter('MakeImg', function ($string, $title = "", $classes = "") {
            //if the string is empy
            if (empty($string)) {
                return "";
            }

            //Get extension
            $str_parts = explode('.', $string);
            $extension = strtolower(end($str_parts));

            //Make sure file is allowed
            $acceptable_filetypes = ['jpg', 'jpeg', 'png', 'gif', 'svg'];
            if ( ! in_array($extension, $acceptable_filetypes)) {
                return "";
            }
            $str_parts = explode('/', $string);
            //create title
            if ($title == "") {
                $title = end($str_parts);
            }

            //Build img
            $rtn = '<img src="' . $string . '" class="' . $classes . '" alt="' . $title . '">';

            return new Markup($rtn, 'UTF-8');
        });

        /**
         * print_r any object under the sun
         * usage: {{ my_obj|print_r }}
         *
         * @param $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('print_r', function ($obj) {
            return '<pre class="code">' . print_r($obj, true) . '</pre>';
        });

        /**
         * prepAdminInput
         * usage: {{ my_obj|prepAdminInput }}
         *
         * @param $obj
         * @param $key
         * @param $machine_name
         * @param $prefix
         *
         * @return object
         */
        $this->filters[] = new TwigFilter('prepAdminInput', function ($obj, $key, $machine_name, $prefix) {
            if ( ! empty($prefix)) {
                $obj['is_repeater'] = true;
                if ($obj['type'] == 'select' && ! empty($obj['multiple'])) {
                    $obj['name'] = implode('_', [$prefix, $machine_name, $key]);
                } else {
                    $obj['name'] = implode('_', [$prefix, $machine_name, $key]) . '[]';
                }
                if ( ! empty($obj['idx'])) {
                    $obj['id'] = implode('_', [$prefix, $machine_name, $key, $obj['idx']]);
                } else {
                    $obj['id'] = implode('_', [$prefix, $machine_name, $key]);
                }
            } else {
                $obj['name'] = implode('_', [$machine_name, $key]);

                if ( ! empty($obj['idx'])) {
                    $obj['id'] = implode('_', [$machine_name, $key, $obj['idx']]);
                } else {
                    $obj['id'] = $obj['name'];
                }
            }

            if ($obj['type'] == 'textarea') {
                $obj['master_textarea'] = $machine_name;
            }


            return $obj;
        });

        /**
         * Add Icon to any string ant the beginning or end
         * usage: {{ my_obj|Icon('fas fa-search') }}, {{ my_obj|Icon('fas fa-search', true) }}
         *
         * @param string $string
         * @param string $icon
         * @param bool $atEnd
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('Icon', function ($string, $icon, $atEnd = false) {
            //if the string is empy
            if (empty($string)) {
                return "";
            }

            //Set Return value
            $rtn = $string;
            //if the string is empy
            if (empty($icon)) {
                return $rtn;
            }

            //Set icon
            $icon = '<i class="' . $icon . '"></i>';

            //Add Icon to Return Value
            if ($atEnd) {
                $rtn .= ' ' . $icon;
            } else {
                $rtn = $icon . ' ' . $rtn;
            }

            return new Markup($rtn, 'UTF-8');
        });

        /**
         * slugify a string
         * usage: {{ my_string|slugify }}
         *
         * @param string $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('slugify', function ($obj) {
            return sanitize_title($obj);
        });

        /**
         * slugify a string
         * usage: {{ my_string|slugify }}
         *
         * @param string $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('getExcerpt', function ($obj) {
            return get_the_excerpt($obj);
        });

        /**
         * get the permalink for any id
         * usage: {{ my_id|getPermalink }}
         *
         * @param int $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('getPermalink', function ($obj) {
            return get_the_permalink($obj);
        });

        /**
         * check if link is on another domain
         * usage: {% if my_string|IsOffsiteLink %}
         *
         * @param string $obj
         *
         * @return bool
         */
        $this->filters[] = new TwigFilter('IsOffsiteLink', function ($obj) {
            return ResourceNavigatorUtilityBase::IsOffsiteLink($obj);
        });

        /**
         * check if link is on another domain
         * usage: {% if my_string|IsOffsiteLink %}
         *
         * @param string $obj
         *
         * @return bool
         */
        $this->filters[] = new TwigFilter('HtmlEntities', function ($obj) {
            return html_entity_decode($obj);
        });

        /**
         * lowercase the first letter of a string
         * usage: {% if my_string|lcfirst %}
         *
         * @param string $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('lcfirst', function ($obj) {
            return lcfirst($obj);
        });
        /**
         * lowercase the first letter of a string
         * usage: {% if my_string|lcfirst %}
         *
         * @param string $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('GetProvidersByID', function ($obj) {
            $ids = [];
            if (is_string($obj)) {
                $ids = explode(',', $obj);
            }
            if (is_array($obj)) {
                $ids = $obj;
            }
            $rtn   = [];
            $login = new Login(get_option('slrn_api_key'));
            if (empty($_COOKIE['slrn_session'])) {
                $loginResult = $login->DoLogin();
                if ((isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)) {
                    return [];
                }
            }
            $providerApi = new Provider(get_option('slrn_api_key'));
            foreach ($ids as $id) {

                $providerResult = $providerApi->GetProviderById(intval($id));

                $providerData   = json_decode($providerResult["body"], true);

                if (is_array($providerData['result'])) {
                    $result = reset($providerData['result']);
                    if (isset($result['Active']) && $result['Active'] == true) {
                        if ( ! empty($result['Specialities'])) {
                            $has_specialties = true;
                        }
                        if ($result['Distance'] != 9999) {
                            $has_distance = true;
                        }
                        $rtn[] = [
                            'id'              => $result['ProviderID'],
                            'logo'            => $result['LogoUrl'],
                            'title'           => $result['ProviderName'],
                            'description'     => $result['ShortDescription'],
                            'contact'         => [
                                'name'      => $result['ContactFirstName'] . ' ' . $result['ContactLastName'],
                                'address_1' => $result['Address'],
                                'address_2' => trim($result['Address2']),
                                'city'      => $result['City'],
                                'state'     => $result['State'],
                                'zip'       => $result['Zip'],
                                'email'     => $result['Email'],
                                'phone'     => $result['Phone'] . (! empty($result['PhoneExt']) ? ' Ext: ' . $result['PhoneExt'] : ''),
                                'website'   => $result['URL'],
                            ],
                            'lat'             => $result['Latitude'],
                            'long'            => $result['Longitude'],
                            'isSponsor'       => $result['IsSponsor'],
                            'specialityCount' => $result['SpecialityCount'],
                            'specialities'    => $result['Specialities'],
                            'distance'        => round($result['Distance'], 2)
                        ];
                    }
                }
                usleep(400000); // 0.5seconds
            }

            return $rtn;
        });

        /**
         * lowercase the first letter of a string
         * usage: {% if my_string|lcfirst %}
         *
         * @param string $obj
         *
         * @return string
         */
        $this->filters[] = new TwigFilter('sortProvidersByTitle', function ($obj) {
            if(empty($obj)) return $obj;
            usort($obj, function($a,$b){
                return $a['title'] <=> $b['title'];
            });

            return $obj;
        });
        foreach ($this->filters as $filter) {
            $this->twig->addFilter($filter);
        }
    }

    /**
     * Register all custom twig function
     */
    public function registerFunctions()
    {
        /**
         * return blog info
         * usage: {{ BlogInfo('url') }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('BlogInfo', function ($string) {
            return get_bloginfo($string);
        });

        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetAttachment', function ($id = 0, $size = 'full', $icon = false, $attr = '') {
            return wp_get_attachment_image($id, $size, $icon, $attr);
        });

        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetAttachmentSrc', function ($id = 0, $size = 'full', $icon = false, $attr = '') {
            return wp_get_attachment_image_src($id, $size, $icon)[0];
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetTheID', function () {
            return get_the_ID();
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetTheScreen', function () {
            return get_current_screen();
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('PageCount', function ($total = 0, $per_page = 0) {
            if ($total == 0 || $per_page == 0) {
                return "";
            }

            return ceil($total / $per_page);
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('DemoCategoryFilterAttr', function ($str = '') {
            $key_arr = explode('_', $str);
            $key_num = array_pop($key_arr);
            if ($key_num != null) {
                return 'filter' . $key_num . 'Ids';
            }

            return '';
        }

        );
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('DemoCategoryFilterID', function ($str = '') {
            $key_arr = explode('_', $str);

            return array_pop($key_arr);
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('Nonce', function ($str = '', $name = '_wpnonce', $referer = true) {
            return wp_nonce_field($str, $name, $referer, false);

        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('WPEditor', function ($name = '', $id = '', $content = '') {
            wp_editor($content, $id, ['teeny' => true, 'textarea_name' => $name, 'media_buttons' => false]);

            return "";
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('StateOptions', function ($val = "") {
            return ResourceNavigatorUtilityBase::StateOptions($val);
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetQuestionType', function ($id = "", $question = "") {
            $question = WebFormPost::GetQuestionDetailsByID($id, $question);

            return $question['type'];
        });
        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('GetQuestionData', function ($id = "", $question = "") {
            $question = WebFormPost::GetQuestionDetailsByID($id, $question);

            return $question;
        });

        /**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('__', function ($string = "", $language ="") {
            if($language == "spanish"){
                return ResourceNavigatorUtilityBase::TranslateES($string);
            }
            return $string;
        });/**
         * returns img for the attachment id
         * usage: {{ GetAttachment(id) }}
         *
         * @return string
         */
        $this->functions[] = new TwigFunction('sprintf', function ($string = "", $replacements = "") {

            return sprintf($string, $replacements);


        });

        foreach ($this->functions as $function) {
            $this->twig->addFunction($function);
        }
    }

    /**
     * The object is created from within the class itself
     * only if the class has no instance.
     *
     * @return TwigManager
     */
    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new TwigManager();
        }

        return self::$instance;
    }

    /**
     * Get the twig Renderer
     *
     * @return object
     */
    public static function Twig()
    {
        $twigManager = TwigManager::getInstance();

        return $twigManager->twig;
    }
}

require_once __DIR__ . '/../../vendor/composer/autoload_real.php';

ComposerAutoloaderInit16d8f9d46e5bc0d876bd042b2f717297::getLoader();
