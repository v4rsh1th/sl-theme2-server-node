<?php /** @noinspection PhpIncludeInspection */

/**
 * After registering this autoload function with SPL, the following line
 * would cause the function to attempt to load the \Foo\Bar\Baz\Qux class
 * from /wp-content/plugins/resource-navigator/inc/sourcelink/resource-navigator/Baz/Qux.php:
 *
 *      new \Sourcelink\ResourceNavigator\Baz\Qux;
 *
 * @param string $class The fully-qualified class name.
 * @return void
 */
spl_autoload_register(function ($class) {

    // project-specific namespace prefix
    $prefixes = array(
    	'Sourcelink\\ResourceNavigator\\' => __DIR__ . '/sourcelink/resource-navigator/',
		'Sourcelink\\ResourceNavigator\\Post\\' => __DIR__ . '/sourcelink/resource-navigator/post/',
		'Sourcelink\\ResourceNavigator\\Plugin\\' => __DIR__ . '/sourcelink/resource-navigator/plugin/',
		'Sourcelink\\ResourceNavigator\\Utility\\' => __DIR__ . '/sourcelink/resource-navigator/utility/',
        'Sourcelink\\ResourceNavigator\\Shortcode\\' => __DIR__ . '/sourcelink/resource-navigator/shortcodes/',
        'Sourcelink\\ResourceNavigator\\Block\\' => __DIR__ . '/sourcelink/resource-navigator/blocks/',
        'Sourcelink\\ResourceNavigator\\InternalAPI\\' => __DIR__ . '/sourcelink/resource-navigator/internal-api/',
        'Sourcelink\\ResourceNavigator\\API\\' => __DIR__ . '/sourcelink/resource-navigator/api/',
        'Sourcelink\\ResourceNavigator\\WPBakery\\' => __DIR__ . '/sourcelink/resource-navigator/wp-bakery/',
        'Sourcelink\\ResourceNavigator\\Elementor\\' => __DIR__ . '/sourcelink/resource-navigator/elementor/',
    	);

    $addedClasses = [];
    // does the class use the namespace prefix?
    foreach($prefixes as $prefix => $base_dir)
    {

        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            // no, move to the next registered autoloader
            continue;
        }

        // get the relative class name
        $relative_class = substr($class, $len);
        if(strpos($relative_class, "\\") > -1){
            $relative_class_parts = explode("\\", $relative_class);
            foreach ($relative_class_parts as $key=>$val){
                if($val != end($relative_class_parts)){
                    $relative_class_parts[$key] = strtolower($val);
                }
            }
            $relative_class = implode("\\", $relative_class_parts);
        }

        // replace the namespace prefix with the base directory, replace namespace
        // separators with directory separators in the relative class name, append
        // with .php
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

        if(in_array($file, $addedClasses)) continue;

        $addedClasses[] = $file;

        // if the file exists, require it
        if (file_exists($file)) {

            include_once( $file );
        }
    }
});

