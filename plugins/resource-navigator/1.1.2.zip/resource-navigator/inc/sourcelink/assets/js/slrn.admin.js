//GIVE OURSELVES A DEFINED CUSTOM SCOPE TO DERP IN
window.ResourceNavigator = {Admin:{}, Frontend:{}, Settings:{}};
window.ResourceNavigator.Admin.removeBox = function(e){
    let r = confirm("Are you sure you want to delete this block?");
    if (r === true)  jQuery(e).remove();
};

//File Uploader Controller for managing media uploads via buttons in admin meta
window.ResourceNavigator.Admin.fileLoader = function ($) {
    let _bind = function() {
        $('.file-controller + .update_btn').unbind('click').on( 'click', _openDialog);
    };

    let _openDialog = function(e){
        e.preventDefault();
        let frame;
        let activeInput = $(this).siblings('input[type=text]');
        let activeIdInput = $(this).siblings('input[type=hidden]');

        // If the media frame already exists, reopen it.
        if ( frame ) {
            frame.open();
            return;
        }

        // Create a new media frame
        let args = {
            title: 'Select or Upload Media Of Your Chosen Persuasion',
            button: {
                text: 'Use this media'
            },
            frame: 'select',
            multiple: false,  // Set to true to allow multiple files to be selected
            // Library WordPress query arguments.
            library: {
                order: 'ASC',
                orderby: 'modified', // name, author, date, title, modified, uploadedTo, id, post__in, menuOrder
                type: 'video' // mime type. e.g. 'image', 'image/jpeg'
            }
        };

        if(activeInput.data('type') !== undefined && activeInput.data('type').length > 0) args.library.type = activeInput.data('type');
        if(activeInput.data('filter') !== undefined && activeInput.data('filter').length > 0) args.library.search = activeInput.data('filter');
        console.log(activeInput.data('type'));
        frame = wp.media(args);

        // When an image is selected in the media frame...
        frame.on( 'select', function() {

            // Get media attachment details from the frame state
            let attachment = frame.state().get('selection').first().toJSON();
            activeInput.val( attachment.url );

            //special actions to show a preview
            if($(activeInput).data("type") === 'video')
            {
                $(activeInput).parent().parent().next().html('<video width="320" height="240" controls><source src="'+attachment.url+'"></video>');
            }
            if($(activeInput).data("type") === 'image')
            {
                $(activeInput).parent().parent().next().html('<img src="'+attachment.url+'" alt="attachment" />');
            }

            // Send the attachment id to our hidden input
            activeIdInput.val( attachment.id );
        });

        // Finally, open the modal on click
        frame.open();
    };

    //Public
    return{
        bind:_bind
    }
}(jQuery);
window.ResourceNavigator.Admin.textareaLinks = function($,wp) {
    // bind a button or a link to open the dialog
    let _bind = function(){
         if($('textarea[data-is-wysiwyg="true"]')){
             $('textarea[data-is-wysiwyg="true"]').not('.master-block textarea[data-is-wysiwyg="true"]').each(function(i){

                 wp.editor.remove($(this).attr('id'));
                 wp.editor.initialize($(this).attr('id'), {
                     tinymce: {
                         wpautop:true,
                         plugins : 'charmap colorpicker compat3x directionality fullscreen hr image lists media paste tabfocus textcolor wordpress wpautoresize wpdialogs wpeditimage wpemoji wpgallery wplink wptextpattern wpview',
                         toolbar1: 'formatselect bold italic | bullist numlist | blockquote | alignleft aligncenter alignright | link unlink | wp_more | spellchecker'
                     },
                     quicktags: true
                 });
             })
         }
        //
        // $(d).on('change', 'p.hidden textarea', function(){
        //     let parent = $(this).parent().parent();
        //     console.log(parent);
        //     $('.content-preview', parent).html($(this).val());
        // });
        // $('a[data-wysiwyg]')for()
        // wp.editor.initialize( editorId, configObject );

        // quicktags({id : 'proj_desc'});
    };

    // let _openDialog = function(e){
    //     e.preventDefault();
    //     let element_id = $(this).data('content-id');
    //     let wysiwyg = $('#wysiwyg-'+$(this).data('wysiwyg'));
    //     if(wysiwyg.length == 0) {
    //         alert('instantiate '+'#wysiwyg-'+$(this).data('wysiwyg'))
    //     }
    //     _tmce_setContent($('#'+element_id).val(), $(this).data('wysiwyg'));
    //     wysiwyg.dialog('open').data('last-edited', $(this).data('content-id'));
    // };
    //
    // let _tmce_setContent = function(content, editor_id, textarea_id) {
    //     if ( typeof editor_id == 'undefined' ) editor_id = wpActiveEditor;
    //     if ( typeof textarea_id == 'undefined' ) textarea_id = editor_id;
    //
    //     if ( $('#wp-'+editor_id+'-wrap').hasClass('tmce-active') && tinyMCE.get(editor_id) ) {
    //         return tinyMCE.get(editor_id).setContent(content);
    //     }else{
    //
    //         return $('#'+textarea_id).val(content);
    //
    //     }
    // };
    //Public
    return{
        bind:_bind,
    }

}(jQuery,wp);
window.ResourceNavigator.Admin.multiSelects = function($,d) {
    // bind a button or a link to open the dialog
    let _bind = function(){
        $('.dupes select[multiple]').each(function(elm){
            if (!$(this).hasClass("select2-hidden-accessible")) {


                $(this).select2({
                    'width':'100%',
                    closeOnSelect:false,
                    dropdownParent: $(this).parent(),
                    placeholder: 'Click here to view options, type to filter options',
                    allowClear: true
                });
                if($(this).attr('data-repeater')){
                    $(this).val($(this).parent().find('input[type="hidden"]').val().split(','));
                    $(this).on('input', function(e){
                        $(this).parent().find('input[type="hidden"]').val($(this).val().join(','));
                    });
                }
            }
        });
    };


    //Public
    return{
        bind:_bind
    }

}(jQuery,document);
window.ResourceNavigator.Admin.repeaters = function ($, imageLoader, textareaLinks, multiSelects){
    let _all_repeaters = [];
    let _index = [];

    //TOGGLER - UNIQUE TO EACH COLLAPSER... NONE OF THESE ARE WORDS
    let _collapser = function(elem){
        let _this = jQuery(elem);
        if(jQuery(_this).is(':checked')){
            jQuery('[data-group='+ _this.attr('id') +']').show();
        } else {
            jQuery('[data-group='+ _this.attr('id') +']').hide();
        }
    }
    let _doStuff = function( m_prefix, m_repeater, m_dupes) {
        let idx = ($('.panel', $('.'+m_dupes)).length + 1);
        let clone = $('.master-block', m_repeater).clone();
        clone.removeClass('master-block').removeClass('hidden');
        $('.slrn-admin-component', clone).addClass('panel panel-default')
        $('input,textarea,select', clone).each(function() {
            $(this).attr('id', ($(this).attr('id') + '_' + idx ) );
        });
        $('.panel-heading', clone).attr('id', '#'+m_prefix + '_collapse_heading_' + idx);
        $('.panel-heading .title', clone).attr('data-parent', '#'+m_dupes).attr('data-target', '#'+m_prefix + '_collapse_' + idx).attr('aria-controls', m_prefix + '_collapse_' + idx).text('New');
        $('.panel-collapse', clone).attr('id', m_prefix + '_collapse_' + idx).attr('aria-labelledby', m_prefix + '_collapse_heading_' + idx);

        $('[data-content-id]', clone).each(function() {
            let newData = $(this).data('content-id')+ '_' + idx;
            $(this).attr('data-content-id', newData );
        });
        $('[data-content-area]', clone).each(function() {
            let newData = $(this).data('content-area')+ '_' + idx;
            $(this).attr('data-content-area', newData );
        });

        $('[data-group]', clone).each(function() {
            let newData = $(this).data('group')+ '_' + idx;
            $(this).attr('data-group', newData );
        });

        $('.collapser-toggle').on('change', function() {
            _collapser(this);
        });

        $('.dupes', m_repeater).append(clone.html());

        imageLoader.bind();
        $('.dupes', m_repeater).sortable({handle:'.handle'});
        textareaLinks.bind();
        multiSelects.bind();
        return idx;
    };
    let _init = function()
    {

        let me = this;
        _all_repeaters = $('.repeater-blocks');

        _all_repeaters.each(function() {
            let m_repeater = $(this);
            let m_prefix = $(this).data('prefix');
            let m_dupes = m_prefix+'_dupes';
            $('.dupes', m_repeater).sortable({handle:'.handle'});
            $('.add-more',m_repeater).click(function(e) {
                e.preventDefault();
                me.doStuff( m_prefix, m_repeater, m_dupes);

                $('.collapser-toggle').on('change', function() {
                    _collapser(this);
                });
            });

            if($('.panel', m_repeater).length == 0) {
                me.doStuff( m_prefix, m_repeater, m_dupes);
            }
            $('.dupes',m_repeater).attr('id', m_dupes).addClass(m_dupes);
        })
        $('.collapser-toggle').on('change', function() {
            _collapser(this);
        });
    };
    return {
        doStuff:_doStuff,
        init:_init
    }
}(jQuery, window.ResourceNavigator.Admin.fileLoader, window.ResourceNavigator.Admin.textareaLinks, window.ResourceNavigator.Admin.multiSelects);
//ON LOAD DO BINDINGS
jQuery(document).ready(function($) {
    //INITS
    window.ResourceNavigator.Admin.fileLoader.bind();
    window.ResourceNavigator.Admin.textareaLinks.bind();
    window.ResourceNavigator.Admin.repeaters.init();
    window.ResourceNavigator.Admin.multiSelects.bind();
    new ClipboardJS('.copy-shorty');

    //FIX MODAL OVER CONTENT MODAL
    jQuery.widget( "ui.dialog", jQuery.ui.dialog, {
        _allowInteraction: function( event ) {
            return !!jQuery( event.target ).closest( ".wp-core-ui" ).length || this._super( event );
        }
    });

    testConditions();

    jQuery(document).on('input','input,select,textarea',  testConditions);


});
function loadMaps(){};
function testConditions (){
    jQuery('.conditional').each(function(){
        var _this = jQuery(this);
        var conditions_json = jQuery(this).data('conditions');
        var relation = "AND";
        if( conditions_json[0].hasOwnProperty('relation') ){
            relation = conditions_json[0].relation;
            conditions_json.shift();
        }
        var display = true;
        var condition_met = [];

        conditions_json.forEach((condition, index) => {
            var parent = jQuery('body');
            var field = condition.field;
            if(condition.repeater)
            {
                field += '[]';
                parent = _this.parent().parent().parent();
            }
            switch(condition.operator) {
                case "==":
                    if(condition.checkbox) {
                        condition_met.push(jQuery('[name="' + field + '"]:checked',parent).length > 0);
                    } else {
                        condition_met.push(jQuery('[name="' + field + '"]',parent).val() === condition.value);
                    }
                    break;
                case "!=":
                    if(condition.checkbox) {
                        condition_met.push(jQuery('[name="' + field + '"]:checked',parent).length === 0);
                    } else {
                        condition_met.push(jQuery('[name="' + field + '"]',parent).val() !== condition.value)
                    }
                    break;
                default:
                    break;
            }

        });
        //DDEPENDING ON THE RELATIONSHIP CHECKED FOR
        if(relation !== "AND"){
            display = condition_met.includes(true);
        } else{
            display = !condition_met.includes(false);
        }

        //FINALLY CHECK THE DISPLAY
        if(display === false){
            jQuery(this).addClass('hide');
        } else {
            jQuery(this).removeClass('hide');
        }

    });
}