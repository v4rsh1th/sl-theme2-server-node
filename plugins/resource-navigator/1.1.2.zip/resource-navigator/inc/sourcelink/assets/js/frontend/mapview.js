


jQuery(function(){

    const wrappers = jQuery('.slrn-container.has-map');
    wrappers.each(function(){
        initViewToggle('#' +jQuery(this).attr('id'));
    });
})

function initViewToggle(context){
    jQuery('a.list-view',context).on('click', function(e){
        e.preventDefault();
        if(!jQuery(this).hasClass('active')){
            jQuery('a.map-view',context).removeClass('active');
            jQuery(this).addClass('active');
            jQuery('div.resources-view.map-view',context).removeClass('active');
            jQuery('div.resources-view.list-view',context).addClass('active');
        }
    });
    jQuery('a.map-view',context).on('click', function(e){
        e.preventDefault();
        if(!jQuery(this).hasClass('active')){
            jQuery('a.list-view',context).removeClass('active');
            jQuery(this).addClass('active');
            jQuery('div.resources-view.list-view',context).removeClass('active');
            jQuery('div.resources-view.map-view',context).addClass('active');
        }
    });
}