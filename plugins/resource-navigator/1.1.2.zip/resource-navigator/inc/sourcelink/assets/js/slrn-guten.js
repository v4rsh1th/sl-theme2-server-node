// SLRNBlocks declaration
window.SLRNBlocks = {};
// main
window.SLRNBlocks.addBlock = function(wp) {
    let siteUrl = '';
    // dependencies
    let el = wp.element.createElement, registerBlockType = wp.blocks.registerBlockType, SelectControl = wp.components.SelectControl, TextControl = wp.components.TextControl,
        TextareaControl = wp.components.TextareaControl, ToggleControl = wp.components.ToggleControl, InspectorControls = wp.blockEditor.InspectorControls,
        PanelColorSettings = wp.blockEditor.PanelColorSettings, PanelBody = wp.components.PanelBody,

        RangeControl = wp.components.RangeControl,

        InspectorAdvancedControls = wp.blockEditor.InspectorAdvancedControls,

        Button = wp.components.Button, MediaUpload = wp.blockEditor.MediaUpload, InnerBlocks = wp.blockEditor.InnerBlocks, BlockControls = wp.blockEditor.BlockControls,

        i18n = wp.i18n, Placeholder = wp.components.Placeholder, RichText = wp.blockEditor.RichText;

    // block icons
    const slIcon = el('svg', {
        viewBox: '0 0 50 50'
    }, el('path', {
        d: 'M25.014 0C11.198 0 0 11.198 0 25.014c0 13.814 11.198 25.014 25.014 25.014 13.814 0 25.014-11.2 25.014-25.014C50.028 11.198 38.828 0 25.014 0zm6.497 35.204l-6.718-4.867-6.89 4.867 2.627-7.854-6.706-4.76H22.2l2.592-7.884 2.655 7.884h8.157l-6.642 4.76 2.548 7.854z',
        fill: '#c00'
    }));
    const sl2 = el('svg', {
        viewBox: '0 0 50 50'
    }, el('path', {
        fill: '#0F0',
        d: 'M25.014 0C11.198 0 0 11.198 0 25.014c0 13.814 11.198 25.014 25.014 25.014 13.814 0 25.014-11.2 25.014-25.014C50.028 11.198 38.828 0 25.014 0zm6.497 35.204l-6.718-4.867-6.89 4.867 2.627-7.854-6.706-4.76H22.2l2.592-7.884 2.655 7.884h8.157l-6.642 4.76 2.548 7.854z'
    }));
    wp.blocks.updateCategory('resource-navigator-category', {icon: slIcon});

    // covert source input to gutenberg options
    let _convertSelectOptions = function(options) {
        let rtn = [];
        for (let eachval in options) {
            if (options.hasOwnProperty(eachval)) {
                rtn.push({label: options[eachval], value: eachval});
            }
        }
        return rtn;
    };

    // select
    let _inputsToSelectControl = function(itm, allProps, property) {
        return el(SelectControl, {
            label: itm.title, dragons: property, options: _convertSelectOptions(itm.values), value: allProps.attributes[property], onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }
        });
    };

    // range
    let _inputsToRangeControl = function(itm, allProps, property) {
        let val = allProps.attributes[property];
        if (typeof allProps.attributes[property] === 'undefined') {
            val = itm.min;
        }
        return el(RangeControl, {
            label: itm.title, dragons: property, min: itm.min, max: itm.max, step: itm.step, value: val, onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }
        });
    };

    // checkbox
    let _inputsToCheckboxControl = function(itm, allProps, property) {
        return el(ToggleControl, {
            label: itm.title, checked: allProps.attributes[property], onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }
        });
    };

    // text
    let _inputsToTextControl = function(itm, allProps, property) {
        return el(TextControl, {
            label: itm.title, value: allProps.attributes[property], onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }
        });
    };

    // textarea
    let _inputsToTextareaControl = function(itm, allProps, property) {
        return el(TextareaControl, {
            label: itm.title, value: allProps.attributes[property], onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }
        });
    };

    // innerblocks
    let _inputsToWizzy = function(itm, property) {
        let initialBlocks = itm.allowedBlocks ? [itm.allowedBlocks] : [];
        return el(
            InnerBlocks, {
                dragons: property,
                allowedBlocks: itm.allowedBlocks,
                //template: initialBlocks
            }
        );
    };

    // richtext
    let _inputsToRichText = function(itm, allProps, property) {
        return el('div', {
            className: 'wp-block-button'
        }, el(RichText, {
            label: itm.title, placeholder: 'Add text...', tagName: 'a', className: 'wp-block-button__link', value: allProps.attributes[property], onChange: function(val) {
                let set = {};
                set[property] = val;
                allProps.setAttributes(set);
            }, keepPlaceholderOnFocus: true
        }));
    };

    // color
    let _inputsToPanelColorSettings = function(itm, allProps, property) {
        return el(PanelColorSettings, {
            title: itm.title, colorSettings: [{
                label: itm.title, disableAlpha: false, value: allProps.attributes[property], onChange: function(val) {
                    let set = {};
                    set[property] = val;
                    allProps.setAttributes(set);
                }
            }]
        });
    };

    // media
    let _inputsToMediaUpload = function(itm, allProps, property) {

        return el(MediaUpload, {
            onSelect: function(val) {
                let mediaType = 'image';
                let set = {};
                set[property] = val.id;
                allProps.setAttributes(set);
            }, value: allProps.attributes[property], render: function(obj) {
                wp.media.attachment(parseInt(allProps.attributes[property])).fetch().then(function(data) {
                    jQuery('#media-btn-' + allProps.attributes[property]).attr('src', data.url);
                });
                if (!allProps.attributes[property]) {
                    return el('div', {class: 'components-base-control'},
                        [el('label', {class: 'components-base-control__label'}, itm.title), el(Button, {className: 'button button-large', onClick: obj.open}, 'Upload Media')]);
                }
                return el('div', {class: 'components-base-control'}, [el('label', {}, itm.title), el(Button, {className: 'media-button', onClick: obj.open}, el('img', {
                    src: '', autoplay: '', id: 'media-btn-' + allProps.attributes[property]
                })), el(Button, {
                    className: 'button button-large', onClick: function() {
                        let set = {};
                        set[property] = false;
                        allProps.setAttributes(set);
                    }
                }, 'Remove Media')]);
            }
        });
    };

    // generate attributes array
    let _createAttributesArray = function(inputs, rtn) {
        //let rtn = {};
        for (let property in inputs) {
            if (inputs.hasOwnProperty(property)) {
                let itm = inputs[property];
                if (itm.type === 'select') {
                    rtn[property] = {
                        type: 'string', default: 'none'
                    };
                }
                else if (itm.type === 'checkbox') {
                    rtn[property] = {
                        type: 'bool', default: false
                    };
                }
                else if (itm.type === 'text') {
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'textarea') {
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'wizzy') {
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'template') {
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'richtext') {
                    rtn['source'] = 'html';
                    rtn['selector'] = 'div';
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'color') {
                    rtn[property] = {
                        type: 'string', default: ''
                    };
                }
                else if (itm.type === 'media') {
                    rtn[property] = {
                        type: 'number'
                    };
                }
                else if (itm.type === 'range') {
                    rtn[property] = {
                        type: 'number'
                    };
                }
            }
        }
        return rtn;
    };

    // generate display for edit
    let _createDisplayArray = function(inputs, allProps) {
        let rtn = [];
        for (let property in inputs) {
            // console.log(property);
            if (inputs.hasOwnProperty(property)) {
                let itm = inputs[property];
                let push = null;
                if (itm.type === 'select') {
                    push = _inputsToSelectControl(itm, allProps, property);
                }
                else if (itm.type === 'checkbox') {
                    push = _inputsToCheckboxControl(itm, allProps, property);
                }
                else if (itm.type === 'text') {
                    push = _inputsToTextControl(itm, allProps, property);
                }
                else if (itm.type === 'textarea') {
                    push = _inputsToTextareaControl(itm, allProps, property);
                }
                else if (itm.type === 'wizzy') {
                    push = _inputsToWizzy(itm, property);
                }
                else if (itm.type === 'template') {
                    // push = _inputsToNestedTemplate(itm, allProps, property);
                }
                else if (itm.type === 'richtext') {
                    push = _inputsToRichText(itm, allProps, property);
                }
                else if (itm.type === 'color') {
                    push = _inputsToPanelColorSettings(itm, allProps, property);
                }
                else if (itm.type === 'media') {
                    push = _inputsToMediaUpload(itm, allProps, property);
                }
                else if (itm.type === 'range') {
                    push = _inputsToRangeControl(itm, allProps, property);
                }
                rtn.push(push);
            }
        }
        return rtn;
    };

    // creates a hover style
    let _createHoverStyle = function(id, rule, value, unit = '') {
        let rtn = '[data-block="' + id + '"] > .styleWrap:hover {';
        rtn += '' + rule + ':' + value + unit + '!important';
        rtn += '}';
        return rtn;
    };

    // creates a style
    let _createStyle = function(id, rule, value, unit = '') {
        let rtn = '[data-block="' + id + '"] > .styleWrap {';
        rtn += '' + rule + ':' + value + unit + '!important';
        rtn += '}';
        return rtn;
    };

    let _stylizeFromInputs = function(meta_name, props) {
        let css = '<style>';
        for (let prop in props.attributes) {
            if (prop.includes('hover_')) {
                if (prop === 'hover_backgroundColor') {
                    css += _createHoverStyle(props.clientId, 'background-color', props.attributes[prop]);
                }
            }
            else {
                if (prop === 'paddingTop') {
                    css += _createStyle(props.clientId, 'padding-top', props.attributes[prop], 'px');
                }
                else if (prop === 'paddingBottom') {
                    css += _createStyle(props.clientId, 'padding-bottom', props.attributes[prop], 'px');
                }
                else if (prop === 'backgroundColor') {
                    css += _createStyle(props.clientId, 'background-color', props.attributes[prop]);
                }
                else if (prop === 'color') {
                    css += _createStyle(props.clientId, 'color', props.attributes[prop]);
                }
                else if (prop === 'borderRadius') {
                    css += _createStyle(props.clientId, 'border-radius', props.attributes[prop], 'px');
                }
                else if (prop === 'backgroundImage') {
                    wp.media.attachment(parseInt(props.attributes[prop])).fetch().then(function(data) {
                        jQuery('[data-block="' + props.clientId + '"] > .styleWrap').css('background-image', 'url(' + data.url + ')');
                    });
                }
            }
        }

        css += '</style>';

        if ((css !== '<style></style>')) {
            jQuery('head').append(css);
        }
    };

    let _getPresetStyles = function(meta_name) {
        let rtn = [];
        if (meta_name === 'button-block') {
            rtn['backgroundColor'] = '#333333';
            rtn['color'] = '#ffffff';
        }
        return rtn;
    };

    // register block
    let _register = function(meta_name, nice_name, inputs, parent, icon, otherAtts) {
        let allAtts = {};

        if (inputs.advanced.length !== 0) {
            if (Array.isArray(inputs.advanced)) {
                inputs.advanced.forEach(function(itms) {
                    _createAttributesArray(itms.inputs, allAtts);
                });
            }
            else {
                _createAttributesArray(inputs.advanced, allAtts);
            }
        }
        if (inputs.sidebar.length !== 0) {
            if (Array.isArray(inputs.sidebar)) {
                inputs.sidebar.forEach(function(itms) {
                    _createAttributesArray(itms.inputs, allAtts);
                });
            }
            else {
                _createAttributesArray(inputs.sidebar, allAtts);
            }
        }
        if (inputs.main.length !== 0) {
            _createAttributesArray(inputs.main, allAtts);
        }

        registerBlockType('sl-resource-navigator/' + meta_name, {
            title: nice_name, icon: (icon === undefined || icon === '' ? slIcon : icon), category: 'resource-navigator-category', attributes: allAtts,

            getEditWrapperProps() {
                // if (meta_name === 'general-content-block' || meta_name === 'wrapper-block') {
                //   return {'data-align': 'full'};
                // }
                return {};
            },

            edit: function(props) {
                _stylizeFromInputs(meta_name, props);
                let additionalStyles = _getPresetStyles(meta_name);

                let allAreas = [];


                if (Array.isArray(inputs.advanced)) {
                    inputs.advanced.forEach(function(itms) {
                        allAreas.push(el(InspectorAdvancedControls, {key: 'controls'}, el(PanelBody, {'title': itms.title}, _createDisplayArray(itms.inputs, props))));
                    });
                }
                else {
                    allAreas.push(el(InspectorAdvancedControls, {key: 'controls'}, _createDisplayArray(inputs.advanced, props)));
                }

                if (inputs.sidebar.length !== 0) {
                    if (Array.isArray(inputs.sidebar)) {
                        inputs.sidebar.forEach(function(itms) {
                            allAreas.push(el(InspectorControls, {key: 'controls'}, el(PanelBody, {'title': itms.title}, _createDisplayArray(itms.inputs, props))));
                        });
                    }
                    else {
                        allAreas.push(el(InspectorControls, {key: 'controls'}, el(PanelBody, {'title': 'ResourceNavigator Options'}, _createDisplayArray(inputs.sidebar, props))));
                    }
                }

                // THIS ONE IS ALWAYS LAST
                if (inputs.main.length !== 0) {
                    allAreas.push(_createDisplayArray(inputs.main, props));
                    return el('div', {
                        style: {
                            paddingTop: '5px'
                        }
                    }, el('div', {
                        className: 'styleWrap', style: additionalStyles
                    }, allAreas));
                }

                if (meta_name === 'button-block') {
                    return el(allAreas);
                }

                return el(Placeholder, {
                    label: nice_name + (props.attributes.name !== undefined ? ' : ' + props.attributes.name : '')
                }, allAreas);

            }, save: function(props) {
                if (meta_name === 'button-block') {
                    return el('div', {
                        className: 'wp-block-button' + ' ' + props.attributes.variant
                    }, el(RichText.Content, {
                        tagName: 'a',
                        className: 'wp-block-button__link',
                        value: props.attributes.rich,
                        href: props.attributes.link,
                        target: props.attributes.target,
                        rel: 'noopener noreferrer'
                    }));
                }
                return el(InnerBlocks.Content, {});
            }
        });

    };
    let _setSiteUrl = function(url) {
        siteUrl = url;
    };
    // return registered block
    return {
        register: _register, setSiteUrl: _setSiteUrl
    };

}(window.wp);