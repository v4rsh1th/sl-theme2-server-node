window.ResourceNavigator.Settings  = function () {
    const settings = {
        blog_url: '', api_url: '', debug: true
    };
    const _getBlogUrl = function() {
        return settings.blog_url;
    };
    const _setBlogUrl = function($inVal) {
        settings.blog_url = $inVal;
    };
    const _getAPIUrl = function() {
        return settings.api_url;
    };
    const _setAPIUrl = function($inVal) {
        settings.api_url = $inVal;
    };
    const _getDebug = function() {
        return settings.debug;
    };

    return{
        getBlogUrl:_getBlogUrl,
        setBlogUrl:_setBlogUrl,
        getAPIUrl:_getAPIUrl,
        setAPIUrl:_setAPIUrl,
        getDebug:_getDebug
    }
}();
jQuery(document).ready(function($) {
    jQuery('#slrn-help-link').parent().attr('target','_blank');
});