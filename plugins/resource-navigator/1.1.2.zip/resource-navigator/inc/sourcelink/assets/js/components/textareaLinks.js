window.ResourceNavigator.Admin.textareaLinks = function($,d) {
    // bind a button or a link to open the dialog
    let _bind = function(){
        $('a[data-wysiwyg]').unbind('click').on('click',_openDialog);

        $(d).on('change', 'p.hidden textarea', function(){
            let parent = $(this).parent().parent();
            console.log(parent);
            $('.content-preview', parent).html($(this).val());
        });
    };

    let _openDialog = function(e){
        e.preventDefault();
        let element_id = $(this).data('content-id');
        let wysiwyg = $('#wysiwyg-'+$(this).data('wysiwyg'));
        if(wysiwyg.length == 0) {
            alert('instantiate '+'#wysiwyg-'+$(this).data('wysiwyg'))
        }
        _tmce_setContent($('#'+element_id).val(), $(this).data('wysiwyg'));
        wysiwyg.dialog('open').data('last-edited', $(this).data('content-id'));
    };

    let _tmce_setContent = function(content, editor_id, textarea_id) {
        if ( typeof editor_id == 'undefined' ) editor_id = wpActiveEditor;
        if ( typeof textarea_id == 'undefined' ) textarea_id = editor_id;

        if ( $('#wp-'+editor_id+'-wrap').hasClass('tmce-active') && tinyMCE.get(editor_id) ) {
            return tinyMCE.get(editor_id).setContent(content);
        }else{
            return $('#'+textarea_id).val(content);

        }
    };
    //Public
    return{
        bind:_bind
    }

}(jQuery,document);