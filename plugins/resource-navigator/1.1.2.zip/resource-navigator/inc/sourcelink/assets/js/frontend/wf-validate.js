var checkCaptch = false;
var verifyRecaptchaCallback = function(response) {
    if (response === "") {
        checkCaptch = false;
    }
    else {
        checkCaptch = true;
    }
};

Pristine.addMessages('es', {
    required: "Este campo es obligatorio",
    email: "Este campo requiere una dirección de correo electrónico válida",
    number: "Este campo requiere un número",
    integer: "Este campo requiere un número",
    url: "Este campo requiere una URL de sitio web válida",
    tel: "Este campo requiere un número de teléfono válido",
    maxlength: "La longitud de este campo debe ser < ${1}",
    minlength: "La longitud de este campo debe ser > ${1}",
    min: "El valor mínimo para este campo es ${1}",
    max: "El valor máximo para este campo es ${1}",
    pattern: "Porfavor rellena el formato requerido",
    equals: "Los dos campos no coinciden",
    default: "Ingrese un valor correcto"
});
var language = {
    'number' : {
        'en':'The value must be a number.',
        'es':'El valor debe ser un número.'
    },
    'phone' : {
        'en':'The value must be a valid phone number.',
        'es':'El valor debe ser un número de teléfono válido.'
    },
    'url' : {
        'en':'The value must be a url. (e.g. https://mywebsite.com)',
        'es':'El valor debe ser una URL. (e.g. https://mywebsite.com)'
    },
    'facebook' : {
        'en':'The value must be a valid facebook profile link. (e.g. https://facebook.com/myprofile)',
        'es':'El valor debe ser un enlace de perfil de Facebook válido. (e.g. https://facebook.com/myprofile)'
    },
    'twitter' : {
        'en':'The value must be a valid twitter profile link. (e.g. https://twitter.com/myProfile)',
        'es':'El valor debe ser un enlace de perfil de Twitter válido. (e.g. https://twitter.com/myProfile)'
    },
    'linkedin' : {
        'en':'The value must be a valid linkedIn profile. (e.g. https://www.linkedin.com/company/my-company/)',
        'es':'El valor debe ser un perfil linkIn válido. (e.g. https://www.linkedin.com/company/my-company/)'
    }
};

jQuery(function() {
    jQuery('.slrn-container-web-form input, .slrn-container-web-form textarea, .slrn-container-web-form select').on('change keydown', function(){

        Pristine.setLocale(jQuery(this).closest("form").data('lang'));
    });
    if(!jQuery('.capital-amount,.capital-source,.capital-type').prop('required')){
        jQuery(document).on('change', '.capital-amount', function(){
            var sib1 = jQuery(this).parent().parent().parent().find('.capital-source')
            var sib2 = jQuery(this).parent().parent().parent().find('.capital-type')
            if(jQuery(this).val() !== "" && jQuery(this).val() !== '0' && !jQuery(this).prop('required'))
            {
                jQuery(this).attr('required', true);
                sib1.attr('required', true);
                sib2.attr('required', true);
            } else {
              if(sib1.val() ===  "0" && sib2.val() === ''){
                  jQuery(this).removeAttr('required');
                  sib1.removeAttr('required');
                  sib2.removeAttr('required');
              }
            }

        });
        jQuery(document).on('change', '.capital-source', function(){
            var sib1 = jQuery(this).parent().parent().parent().find('.capital-amount')
            var sib2 = jQuery(this).parent().parent().parent().find('.capital-type')
            if(jQuery(this).val() !== "" && !jQuery(this).prop('required'))
            {
                jQuery(this).attr('required', true);
                sib1.attr('required', true);
                sib2.attr('required', true);
            } else {
                if(sib1.val() ===  "0" && sib1.val() ===  "" && sib2.val() === '0'){
                    jQuery(this).removeAttr('required');
                    sib1.removeAttr('required');
                    sib2.removeAttr('required');
                }
            }
        });
        jQuery(document).on('change', '.capital-type', function(){
            var sib1 = jQuery(this).parent().parent().parent().find('.capital-amount')
            var sib2 = jQuery(this).parent().parent().parent().find('.capital-source')
            if(jQuery(this) && jQuery(this).val() !== "0" && !jQuery(this)[0].hasAttribute('required'))
            {
                jQuery(this).attr('required', true);
                sib1.attr('required', true);
                sib2.attr('required', true);
            } else {
                if(sib1.val() ===  "0" && sib1.val() ===  ""){
                    jQuery(this).removeAttr('required');
                    sib1.removeAttr('required');
                    sib2.removeAttr('required');
                }
            }
        });
    }
    bind();
});
const forms = document.getElementsByClassName('slrn_web_form');
function bind(){
    let pristine =[];
    for (var index = 0; index < forms.length; index++) {

        if (forms[index]) {
            let pristineConfig = {
                classTo: 'field-wrap',
                errorClass: 'has-danger',
                successClass: 'has-success',
                errorTextParent: 'field-wrap',
                errorTextTag: 'div',
                errorTextClass: 'text-help'
            };
            // A validator to check if the first letter is capitalized
            jQuery('.g-recaptcha-response').prop('required', true)
            // create the pristine instance
            let lang = forms[index].getAttribute('data-lang') ?? 'en';
            Pristine.setLocale(lang );
            pristine[index] = new Pristine(forms[index], pristineConfig, true);
            //pristine[index].setLocale('es');
            let prefix = forms[index].getAttribute('data-prefix');

            let numbers = jQuery('input.number', forms[index]);
            numbers.each(function(a) {
                if (numbers[a]) {

                    pristine[index].addValidator(numbers[a], function(value) {
                        if (!jQuery(this).prop('required') && value === '') {
                            return true;
                        }
                        else {
                            let patt = /^[0-9]*\.?[0-9]+$/igm;
                            return patt.test(value);
                        }
                    }, language.number[lang], 2, false);
                }
            });

            let phones = jQuery('[type="tel"]', forms[index]);
            phones.each(function(i) {

                if (phones[i]) {
                    pristine[index].addValidator(phones[i], function(value) {
                        if (!jQuery(this).prop('required') && value === '') {
                            return true;
                        }
                        let patt = /^[\+]?[0-9]?[-\s\.]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
                        return patt.test(value);
                    }, language.phone[lang], 2, false);
                }
            });
            let website = document.getElementById(prefix + '_webUrl');
            if (website) {
                pristine[index].addValidator(website, function(value) {
                    let patt = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
                    if (!jQuery(this).prop('required') && value === '') {
                        return true;
                    }

                    return patt.test(value);
                }, language.url[lang], 2, false);
            }
            let facebook = document.getElementById(prefix + '_facebookUrl');
            if (facebook) {
                pristine[index].addValidator(facebook, function(value) {
                    if (!jQuery(this).prop('required') && value === '') {
                        return true;
                    }
                    let valid = facebook.validity.valid;
                    if (value.indexOf('https://facebook.com/') === -1 && value.indexOf('https://www.facebook.com/') === -1) {
                        valid = false;
                    }
                    if (value.length == 0) {
                        valid = true;
                    }
                    return valid;
                }, language.facebook[lang], 2, false);
            }
            let twitter = document.getElementById(prefix + '_twitterUrl');
            if (twitter) {
                pristine[index].addValidator(twitter, function(value) {
                    if (!jQuery(this).prop('required') && value === '') {
                        return true;
                    }
                    let valid = twitter.validity.valid;
                    if (value.indexOf('https://twitter.com/') === -1 && value.indexOf('https://www.twitter.com/') === -1) {
                        valid = false;
                    }
                    if (value.length == 0) {
                        valid = true;
                    }
                    return valid;
                }, language.twitter[lang], 2, false);
            }
            let linkedin = document.getElementById(prefix + '_txtLinkedIn');
            if (linkedin) {
                pristine[index].addValidator(linkedin, function(value) {
                    if (!jQuery(this).prop('required') && value === '') {
                        return true;
                    }
                    let valid = linkedin.validity.valid;
                    if (value.indexOf('https://linkedin.com/') === -1 && value.indexOf('https://www.linkedin.com/') === -1) {
                        valid = false;
                    }
                    if (value.length == 0) {
                        valid = true;
                    }
                    return valid;
                }, language.linkedin[lang], 2, false);
            }
            forms[index].formIndex = index;
            forms[index].addEventListener('dblclick', function(e) {
                e.preventDefault();

                // var button = document.getElementById('your-button-id');

                // button.addEventListener('dblclick', function(event) {
                // event.preventDefault();
                // });

                var recaptcha = true;
                if(jQuery(this).find('.g-recaptcha').length > 0){
                    var response = grecaptcha.getResponse(parseInt(e.currentTarget.formIndex));
                    if(response.length == 0 && grecaptcha){
                        recaptcha = false;
                        jQuery(this).find('.g-recaptcha').parent().find('.pristine-error').remove();
                        jQuery(this).find('.g-recaptcha').parent().addClass('has-danger').append('<div class="pristine-error text-help" style="display:block;">ReCaptcha is Required</div>')
                    }
                }
                let lang = forms[e.currentTarget.formIndex].getAttribute('data-lang') ?? 'en';
                Pristine.setLocale(lang );
                // check if the form is valid
                let valid = pristine[e.currentTarget.formIndex].validate(); // returns true or false
                if (valid && recaptcha) {
                    this.submit();
                }
                else {
                    if(jQuery(jQuery('.has-danger')[0]).length > 0)
                    {
                        window.scrollTo({
                            top: jQuery(jQuery('.has-danger')[0]).offset().top - 150, left: 0, behavior: 'smooth'
                        });
                    }
                    // if(jQuery("#slrn_magic_modal").length > 0){
                    //     jQuery("#slrn_magic_modal")[0].scrollTo({
                    //         top: jQuery(jQuery('.has-danger')[0]).offset().top - 150,
                    //         left: 0,
                    //         behavior: 'smooth'
                    //     });
                    // }
                }

            });
        }
    }
}
function validURL(str) {
    const pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}' + // domain name
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
    return !!pattern.test(str);
}
