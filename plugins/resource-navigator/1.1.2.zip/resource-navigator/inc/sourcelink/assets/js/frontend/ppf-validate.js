Pristine.addMessages('es', {
    required: 'Este campo es obligatorio',
    email: 'Este campo requiere una dirección de correo electrónico válida',
    number: 'Este campo requiere un número',
    integer: 'Este campo requiere un número',
    url: 'Este campo requiere una URL de sitio web válida',
    tel: 'Este campo requiere un número de teléfono válido',
    maxlength: 'La longitud de este campo debe ser < ${1}',
    minlength: 'La longitud de este campo debe ser > ${1}',
    min: 'El valor mínimo para este campo es ${1}',
    max: 'El valor máximo para este campo es ${1}',
    pattern: 'Porfavor rellena el formato requerido',
    equals: 'Los dos campos no coinciden',
    default: 'Ingrese un valor correcto'
});
var language = {
    'number': {
        'en': 'The value must be a number.', 'es': 'El valor debe ser un número.'
    }, 'phone': {
        'en': 'The value must be a valid phone number.', 'es': 'El valor debe ser un número de teléfono válido.'
    }, 'url': {
        'en': 'The value must be a url. (e.g. https://mywebsite.com)', 'es': 'El valor debe ser una URL. (e.g. https://mywebsite.com)'
    }, 'facebook': {
        'en': 'The value must be a valid facebook profile link. (e.g. https://facebook.com/myprofile)',
        'es': 'El valor debe ser un enlace de perfil de Facebook válido. (e.g. https://facebook.com/myprofile)'
    }, 'twitter': {
        'en': 'The value must be a valid twitter profile link. (e.g. https://twitter.com/myProfile)',
        'es': 'El valor debe ser un enlace de perfil de Twitter válido. (e.g. https://twitter.com/myProfile)'
    }, 'linkedin': {
        'en': 'The value must be a valid linkedIn profile. (e.g. https://www.linkedin.com/company/my-company/)',
        'es': 'El valor debe ser un perfil linkIn válido. (e.g. https://www.linkedin.com/company/my-company/)'
    }, 'instagram': {
        'en': 'The value must be a valid Instagram profile. (e.g. https://www.instagram.com/myProfile)',
        'es': 'El valor debe ser un perfil Instagram válido. (e.g. https://www.instagram.com/myProfile)'
    }
};
jQuery(function() {
    pbind();
});
const pforms = document.getElementsByClassName('slrn_partner_form');

function pbind() {
    let pristine = [];
    for (var index = 0; index < pforms.length; index++) {
        if (pforms[index]) {
            const pristineConfig = {
                // class of the parent element where the error/success class is added
                classTo: 'field-wrap', errorClass: 'has-danger', successClass: 'has-success', // class of the parent element where error text element is appended
                errorTextParent: 'field-wrap', // type of element to create for the error text
                errorTextTag: 'div', // class of the error text element
                errorTextClass: 'text-help'
            };
            // A validator to check if the first letter is capitalized
            let lang = pforms[index].getAttribute('data-lang') ?? 'en';
            Pristine.setLocale(lang);
            // create the pristine instance
            pristine[index] = new Pristine(pforms[index], pristineConfig, true);

            const prefix = pforms[index].getAttribute('data-prefix');
            const phones = jQuery('#' + prefix + '_txtBusinessPhone', pforms[index]);
            phones.each(function(i) {

                if (phones[i]) {
                    pristine[index].addValidator(phones[i], function(value) {
                        if (!phones[i].required && value === '') {
                            return true;
                        }
                        const patt = /^[\+]?[0-9]?[-\s\.]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
                        return patt.test(value);
                    }, language.phone[lang], 2, false);
                }
            });
            const websites = jQuery('#' + prefix + '_txtUrl', pforms[index]);
            websites.each(function(i) {
                if (websites[i]) {
                    pristine[index].addValidator(websites[i], function(value) {
                        return websites[i].validity.valid;
                    }, language.url[lang], 2, false);
                }
            });
            const facebooks = jQuery('#' + prefix + '_txtFacebook', pforms[index]);
            facebooks.each(function(i) {
                if (facebooks[i]) {
                    pristine[index].addValidator(facebooks[i], function(value) {
                        let valid = facebooks[i].validity.valid;
                        if (value.indexOf('https://facebook.com/') === -1 && value.indexOf('https://www.facebook.com/') === -1) {
                            valid = false;
                        }
                        if (value.length == 0) {
                            valid = true;
                        }
                        return valid;
                    }, language.facebook[lang], 2, false);
                }
            });
            const twitters = jQuery('#' + prefix + '_txtTwitter', pforms[index]);
            twitters.each(function(i) {
                if (twitters[i]) {
                    pristine[index].addValidator(twitters[i], function(value) {
                        let valid = twitters[i].validity.valid;
                        if (value.indexOf('https://twitter.com/') === -1 && value.indexOf('https://www.twitter.com/') === -1) {
                            valid = false;
                        }
                        if (value.length == 0) {
                            valid = true;
                        }
                        return valid;
                    }, language.twitter[lang], 2, false);
                }
            });
            const linkedins = jQuery('#' + prefix + '_txtLinkedIn', pforms[index]);
            linkedins.each(function(i) {
                if (linkedins[i]) {
                    pristine[index].addValidator(linkedins[i], function(value) {
                        let valid = linkedins[i].validity.valid;
                        if (value.indexOf('https://linkedin.com/') === -1 && value.indexOf('https://www.linkedin.com/') === -1) {
                            valid = false;
                        }
                        if (value.length == 0) {
                            valid = true;
                        }
                        return valid;
                    }, language.linkedin[lang], 2, false);
                }
            });
            var instagrams = jQuery('#' + prefix + '_txtInstagram', pforms[index]);
            instagrams.each(function(i) {
                if (instagrams[i]) {
                    pristine[index].addValidator(instagrams[i], function(value) {
                        var valid = instagrams[i].validity.valid;
                        if (value.indexOf('https://instagram.com/') === -1 && value.indexOf('https://www.instagram.com/') === -1) {
                            valid = false;
                        }
                        if (value.length == 0) {
                            valid = true;
                        }
                        return valid;
                    }, language.instagram[lang], 2, false);
                }
            });
            pforms[index].formIndex = index;
            pforms[index].addEventListener('submit', function(e) {
                e.preventDefault();


                var formTarget = '#'+ jQuery(e.currentTarget).attr('id');
                jQuery('.filter-errors', formTarget).text(``);
                jQuery('.filter-errors', formTarget).parent().removeClass('has-danger');

                var filterErrors = [];
                const validSupportedFilters = validCheckboxCount('supp-filter', 'supported filters', formTarget);
                if (validSupportedFilters) {
                    filterErrors.push(validSupportedFilters);
                }
                const validSpecialtyFilters = validCheckboxCount('spec-filter', 'specialty filters', formTarget);
                if (validSpecialtyFilters) {
                    filterErrors.push(validSpecialtyFilters);
                }
                const validSupportedServices = validCheckboxCount('supp-serv', 'supported services', formTarget);
                if (validSupportedServices) {
                    filterErrors.push(validSupportedServices);
                }
                const validSpecialtyServices = validCheckboxCount('spec-serv', 'specialty services', formTarget);
                if (validSpecialtyServices) {
                    filterErrors.push(validSpecialtyServices);
                }
                if (filterErrors.length > 0) {
                    jQuery('.filter-errors', formTarget).parent().addClass('has-danger');
                    jQuery('.filter-errors', formTarget).append(filterErrors.join('<br />'));
                }
                var recaptcha = true;

                if (jQuery(formTarget).find('.g-recaptcha').length > 0) {
                    var response = grecaptcha.getResponse(parseInt(e.currentTarget.formIndex));

                    if (response.length == 0 && grecaptcha) {
                        recaptcha = false;
                        jQuery(formTarget).find('.g-recaptcha').parent().find('.pristine-error').remove();
                        jQuery(formTarget).
                            find('.g-recaptcha').
                            parent().
                            addClass('has-danger').
                            append('<div class="pristine-error text-help" style="display:block;">ReCaptcha is Required</div>');
                    }
                }
                let lang = pforms[e.currentTarget.formIndex].getAttribute('data-lang') ?? 'en';
                Pristine.setLocale(lang);
                // check if the form is valid
                let valid = pristine[e.currentTarget.formIndex].validate(); // returns true or false
                if (valid && recaptcha && filterErrors.length === 0) {
                    jQuery(formTarget).submit();
                }
                else {
                    if (jQuery(jQuery('.has-danger')[0]).length > 0) {
                        window.scrollTo({
                            top: jQuery(jQuery('.has-danger')[0]).offset().top - 150, left: 0, behavior: 'smooth'
                        });
                    }
                    // if(jQuery("#slrn_magic_modal").length > 0){
                    //     jQuery("#slrn_magic_modal")[0].scrollTo({
                    //         top: jQuery(jQuery('.has-danger')[0]).offset().top - 150,
                    //         left: 0,
                    //         behavior: 'smooth'
                    //     });
                    // }
                }



            });
        }
    }
}

function validCheckboxCount(cbkType, msgType, form) {
    const maxNumber = jQuery(`.max-${cbkType}`, form).val();
    const defaultNumber = jQuery(`.${cbkType}-checkbox[readonly]`, form).length;
    // alert(`#max-${cbkType} -> ${maxNumber} | .${cbkType}-checkbox[readonly] -> ${defaultNumber}`)
    // alert(`.${cbkType}-checkbox:checked:not([readonly]) -> ${jQuery(`.${cbkType}-checkbox:checked:not([readonly])`, form).length}`)
    if (maxNumber > 0 && jQuery(`.${cbkType}-checkbox:checked:not([readonly])`, form).length > maxNumber) {
        const totalNumber = parseInt(maxNumber) + parseInt(defaultNumber);
        jQuery(`.col-${cbkType}`, form).addClass('has-danger');
        return `Only ${totalNumber} ${msgType} are allowed.`;
    }
    jQuery(`.col-${cbkType}`, form).removeClass('has-danger');
    return false;
}

function validURL(str) {
    const pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}' + // domain name
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
    return !!pattern.test(str);
}
