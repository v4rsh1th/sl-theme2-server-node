//File Uploader Controller for managing media uploads via buttons in admin meta
window.ResourceNavigator.Admin.fileLoader = function ($) {
    let _bind = function() {
        $('.file-controller + .update_btn').unbind('click').on( 'click', _openDialog);
    };

    let _openDialog = function(e){
        e.preventDefault();
        let frame;
        let activeInput = $(this).siblings('input[type=text]');
        let activeIdInput = $(this).siblings('input[type=hidden]');

        // If the media frame already exists, reopen it.
        if ( frame ) {
            frame.open();
            return;
        }

        // Create a new media frame
        let args = {
            title: 'Select or Upload Media Of Your Chosen Persuasion',
            button: {
                text: 'Use this media'
            },
            frame: 'select',
            multiple: false,  // Set to true to allow multiple files to be selected
            // Library WordPress query arguments.
            library: {
                order: 'ASC',
                orderby: 'modified', // name, author, date, title, modified, uploadedTo, id, post__in, menuOrder
                type: 'video' // mime type. e.g. 'image', 'image/jpeg'
            }
        };

        if(activeInput.data('type') !== undefined && activeInput.data('type').length > 0) args.library.type = activeInput.data('type');
        if(activeInput.data('filter') !== undefined && activeInput.data('filter').length > 0) args.library.search = activeInput.data('filter');
        console.log(activeInput.data('type'));
        frame = wp.media(args);

        // When an image is selected in the media frame...
        frame.on( 'select', function() {

            // Get media attachment details from the frame state
            let attachment = frame.state().get('selection').first().toJSON();
            activeInput.val( attachment.url );

            //special actions to show a preview
            if($(activeInput).data("type") === 'video')
            {
                $(activeInput).parent().parent().next().html('<video width="320" height="240" controls><source src="'+attachment.url+'"></video>');
            }
            if($(activeInput).data("type") === 'image')
            {
                $(activeInput).parent().parent().next().html('<img src="'+attachment.url+'" alt="attachment" />');
            }

            // Send the attachment id to our hidden input
            activeIdInput.val( attachment.id );
        });

        // Finally, open the modal on click
        frame.open();
    };

    //Public
    return{
        bind:_bind
    }
}(jQuery);