<?php

namespace Sourcelink\ResourceNavigator;

class ApiObjectBase
{

    /**
     * @param string|array
     */
    public function __construct($json = null)
    {
        if (is_array($json)) {
            $this->fromArray($json);
        } elseif ($this->isJSON($json)) {
            $arr = json_decode($json, 1);
            $this->fromArray($arr);
        }
    }

    /**
     * @return string
     */
    public function toJSON(): string
    {

        $json = [];
        foreach ($this as $key => $value) {
            if (is_array($value)) {
                $tmp = [];
                foreach ($value as $val) {
                    if (is_subclass_of($val, '\Sourcelink\ResourceNavigator\ApiObjectBase')) {
                        $tmp[] = $val->toArray();
                    } else {
                        $tmp[] = $val;
                    }
                }
                $value = $tmp ?? null;
            }
            $json[$key] = $value ?? null;
        }

        return json_encode($json);
    }

    /**
     * @return array
     */
    public function toArray(): array
    {

        $json = [];
        foreach ($this as $key => $value) {
            $json[$key] = $value ?? null;
        }

        return $json;
    }

    private function fromArray($arr)
    {

        foreach ($arr as $key => $value) {
            $call = 'set' . $key;
            if (property_exists($this, $key) && $value != null) {
                $this->$call($value);
            }
        }
    }

    /**
     * @param $string
     *
     * @return bool
     */
    private function isJSON($string): bool
    {
        json_decode($string);

        return json_last_error() === JSON_ERROR_NONE;
    }
}
