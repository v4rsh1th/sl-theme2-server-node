<?php

namespace Sourcelink\ResourceNavigator\Settings;
use DateTime;
use DateTimeZone;
use Sourcelink\ResourceNavigator\API\DemographicFilter;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\PostBase as PostBase;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;
use Sourcelink\ResourceNavigator\TwigManager;

class ApiTest extends SettingsBase
{

    public function Register(){
        add_submenu_page(
            'admin.php?page=resource_navigator',
            __( 'Dev Tools', 'slrn' ),
            __( 'Dev Tools', 'slrn' ),
            'manage_options',
            'resource_navigator_' . $this->MachineName(),
            [$this,'Display']
        );
    }

    public function MachineName():string
    {
        return 'api_test';
    }

    public function Display() {
        $login = new Login(get_option('slrn_api_key'));
            $login->DoLogin();

        $crons = _get_cron_array();
        ?>
        <div class="slrn-admin-component">
            <h3>Environment</h3>
<pre>
    Current PHP version: <?php echo phpversion(); ?><br>
    Current Apache version: <?php echo apache_get_version(); ?><br>
    IP: <?php echo $_SERVER['SERVER_ADDR'] ?>
</pre>
            <h3>Registered WP Cron Jobs</h3>
        <table class="table-striped">
            <thead>
            <tr>
                <th>Scheduled Time</th>
                <th>Handle</th>
                <th>UUID</th>
                <th>Schedule</th>
                <th>Interval</th>
            </tr>
            </thead>
            <tbody>
                    <?php
                    foreach ($crons as $timestamp=>$job){
                        echo '<tr>';
                        $date = new \DateTime();
                        $date->setTimestamp($timestamp)->setTimezone( new DateTimeZone('America/Chicago'));

                        echo '<td>' . $date->format('F j, Y h:i:s a') . '</td>';
                        $count=0;
                        foreach ($job as $label=>$job_inner){
                            if($count>0) {
                                echo '</tr><tr><td>' . $date->format('F j, Y h:i:s a') . '</td>';
                            }
                            echo '<td>' .$label . '</td>';
                            $count++;
                            foreach ($job_inner as $uuid=>$job_props){
                                echo '<td>' . $uuid . '</td>';
                                echo '<td>' . ($job_props['schedule'] ?? "") . '</td>';
                                echo '<td>' . ($job_props['interval'] ?? "") . '</td>';
                            }
                        }
                        echo '</tr>';
                    }
                    ?>
            </tbody>
        </table>


        </div>

        <?php
    }

}