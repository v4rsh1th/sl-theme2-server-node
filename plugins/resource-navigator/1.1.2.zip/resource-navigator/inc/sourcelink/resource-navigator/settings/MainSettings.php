<?php

namespace Sourcelink\ResourceNavigator\Settings;
use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\SettingsBase;

class MainSettings extends SettingsBase
{
    public function save_meta($id = ''){
        if(isset($_POST['slrn_update'])) {

            update_option('slrn_api_key', filter_var($_POST['slrn_api_key'], FILTER_SANITIZE_STRING));
            update_option('slrn_gm_api_key', filter_var($_POST['slrn_gm_api_key'], FILTER_SANITIZE_STRING));
            update_option('slrn_grc_api_key', filter_var($_POST['slrn_grc_api_key'], FILTER_SANITIZE_STRING));
            update_option('slrn_grc_api_key_2', filter_var($_POST['slrn_grc_api_key_2'], FILTER_SANITIZE_STRING));
            update_option('slrn_delete_data', filter_var($_POST['slrn_delete_data'], FILTER_SANITIZE_STRING));
            update_option('slrn_default_page', filter_var($_POST['slrn_default_page'], FILTER_SANITIZE_NUMBER_INT));
            update_option('slrn_use_staging', filter_var($_POST['slrn_use_staging'], FILTER_SANITIZE_NUMBER_INT));

        }
    }
    public function Notice(){
        if ( !empty(get_option('slrn_use_staging')) ) {
            echo '<div class="notice notice-warning is-dismissible">
                 <p>You are using the Sourcelink Staging API! Be sure update before going live with your changes. Update it <a href="admin.php?page=resource_navigator_settings">here</a>.</p>
             </div>';
        }
        if ( empty(get_option('slrn_api_key')) ) {
            echo '<div class="notice notice-warning is-dismissible">
                 <p>You must add your API Key to use the Resource Navigator. Add it <a href="admin.php?page=resource_navigator_settings">here</a>.</p>
             </div>';
        } else {

        $login = new Login(get_option('slrn_api_key'));
        $result = $login->DoLogin();
        if( (isset($result['response']['code']) && $result['response']['code'] != 200)){
            echo '<div class="notice notice-warning  is-dismissible">
                     <p>Your Resource Navigator API Key is incorrect. Update it <a href="admin.php?page=resource_navigator_settings">here</a>.</p>
                 </div>';
        }


        }
    }
    public function Name():string {
        return 'General';
    }
    public function MachineName():string {
        return 'settings';
    }

    public function Display() {


        $args = array(
            'orderby' => 'post_title',
            'order' => 'ASC',
            'post_type' => 'page',
            'posts_per_page' => -1,
            'post_status' => array('publish', 'draft', 'private',)
        );

        $pages = get_posts( $args );
?>
        <form method="post" action="">
            <div class="slrn-admin-component">
                <div class="row">
                    <div class="col-sm-12">
                        <label class="title" id="slrn_api_key_label" for="slrn_api_key">SourceLink API Key</label>
                        <input type="text" name="slrn_api_key" id="slrn_api_key" value="<?php echo get_option('slrn_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_gm_api_key">Google Maps API Key</label>
                        <input type="text" name="slrn_gm_api_key" id="slrn_gm_api_key" value="<?php echo get_option('slrn_gm_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_grc_api_key">Google reCaptcha Site Key</label>
                        <input type="text" name="slrn_grc_api_key" id="slrn_grc_api_key" value="<?php echo get_option('slrn_grc_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_grc_api_key_2">Google reCaptcha Site Secret</label>
                        <input type="text" name="slrn_grc_api_key_2" id="slrn_grc_api_key_2" value="<?php echo get_option('slrn_grc_api_key_2'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_default_page">Default Template Page</label>
                        <select name="slrn_default_page" id="slrn_default_page">
                            <option value="">- Select -</option>
                            <?php
                                $default_page = get_option('slrn_default_page');
                                foreach ($pages as $page){
                                    echo '<option value="'.$page->ID.'" '. ($default_page == $page->ID ? 'selected="selected"' : '') . '>' . $page->post_title . ' '  . ($page->post_status !== "publish" ? '(' . $page->post_status . ')' : '') . '</option>';
                                }
                            ?>
                        </select>
                        <p><em>used to render partner profiles and other default displays</em></p>
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_use_staging_label" for="slrn_use_staging">Use Developmental API</label>
                        <input type="checkbox" name="slrn_use_staging" id="slrn_use_staging" value="1"  <?php if(!empty(get_option('slrn_use_staging'))) { echo 'checked="checked"';} ?>>
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_delete_data" for="slrn_delete_data">Delete Forms and Views when uninstalling this plugin?</label>
                        <input type="checkbox" name="slrn_delete_data" id="slrn_delete_data" value="1" <?php if(!empty(get_option('slrn_delete_data'))) { echo 'checked="checked"';} ?>>
                    </div>
                    <div class="col-sm-12">
                        <input type="hidden" name="slrn_update" id="slrn_update" value="1">
                        <button type="submit" class="button-primary">Save Options</button>
                    </div>
                </div>
            </div>
        </form>

<?php

    }
    public function DisplayTab() {


        $args = array(
            'orderby' => 'post_title',
            'order' => 'ASC',
            'post_type' => 'page',
            'posts_per_page' => -1,
            'post_status' => array('publish', 'draft', 'private',)
        );

        $pages = get_posts( $args );
        ob_start();
        ?>
        <form method="post" action="">
            <div class="slrn-admin-component">
                <div class="row">
                    <div class="col-sm-12">
                        <label class="title" id="slrn_api_key_label" for="slrn_api_key">SourceLink API Key</label>
                        <input type="text" name="slrn_api_key" id="slrn_api_key" value="<?php echo get_option('slrn_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_gm_api_key">Google Maps API Key</label>
                        <input type="text" name="slrn_gm_api_key" id="slrn_gm_api_key" value="<?php echo get_option('slrn_gm_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_grc_api_key">Google reCaptcha Site Key</label>
                        <input type="text" name="slrn_grc_api_key" id="slrn_grc_api_key" value="<?php echo get_option('slrn_grc_api_key'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_grc_api_key_2">Google reCaptcha Site Secret</label>
                        <input type="text" name="slrn_grc_api_key_2" id="slrn_grc_api_key_2" value="<?php echo get_option('slrn_grc_api_key_2'); ?>">
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_gm_api_key_label" for="slrn_default_page">Default Template Page</label>
                        <select name="slrn_default_page" id="slrn_default_page">
                            <option value="">- Select -</option>
                            <?php
                            $default_page = get_option('slrn_default_page');
                            foreach ($pages as $page){
                                echo '<option value="'.$page->ID.'" '. ($default_page == $page->ID ? 'selected="selected"' : '') . '>' . $page->post_title . ' '  . ($page->post_status !== "publish" ? '(' . $page->post_status . ')' : '') . '</option>';
                            }
                            ?>
                        </select>
                        <p><em>used to render partner profiles and other default displays</em></p>
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_use_staging_label" for="slrn_use_staging">Use Developmental API</label>
                        <input type="checkbox" name="slrn_use_staging" id="slrn_use_staging" value="1"  <?php if(!empty(get_option('slrn_use_staging'))) { echo 'checked="checked"';} ?>>
                    </div>
                    <div class="col-sm-12">
                        <label class="title" id="slrn_delete_data" for="slrn_delete_data">Delete Forms and Views when uninstalling this plugin?</label>
                        <input type="checkbox" name="slrn_delete_data" id="slrn_delete_data" value="1" <?php if(!empty(get_option('slrn_delete_data'))) { echo 'checked="checked"';} ?>>
                    </div>
                    <div class="col-sm-12">
                        <input type="hidden" name="slrn_update" id="slrn_update" value="1">
                        <button type="submit" class="button-primary">Save Options</button>
                    </div>
                </div>
            </div>
        </form>

        <?php
        $content = ob_get_clean();
        return $content;
    }

}