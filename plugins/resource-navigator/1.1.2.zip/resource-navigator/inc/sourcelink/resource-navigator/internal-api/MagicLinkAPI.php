<?php

namespace Sourcelink\ResourceNavigator\InternalAPI;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\InternalApiBase;

/**
 * Class RecipeSearchAPI
 * @package Propaganda3\WPO\InternalAPI
 */
class MagicLinkAPI extends InternalApiBase
{
    /**
     * Registers a single endpoint for searching recipes.
     *
     * @return array Used by WPO engine to generate endpoint
     */
    public function RouteArray(): array
    {
        return [
            [
                'endpoint' => 'validate-magic-link',
                'method'   => 'GET',
                'callback' => array($this, 'ValidateMagicLink'),
                'args'     => [
                    'jrt'   => [
                        'validate_callback' => function ($param, $request, $key) {
                            return filter_var($param, FILTER_SANITIZE_STRING);
                        },
                        'required'          => true
                    ],
                    'pk'   => [
                        'validate_callback' => function ($param, $request, $key) {
                            return filter_var($param, FILTER_SANITIZE_STRING);
                        },
                        'required'          => true
                    ],
                ]
            ],
            [
                'endpoint' => 'request-magic-link',
                'method'   => 'GET',
                'callback' => array($this, 'SendMagicLink'),
                'args'     => [
                    'url'   => [
                        'validate_callback' => function ($param, $request, $key) {
                            return (strpos(get_bloginfo('url'),$param ) == 0 && !empty(filter_var($param, FILTER_SANITIZE_URL)));
                        },
                        'required'          => true
                    ],
                    'pid'   => [
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        },
                        'required'          => true
                    ],
                ]
            ]
        ];
    }

    /**
     * Name of common directory for all endpoints in this group. Must be unique.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'slrn_magic_link';
    }
    /**
     * Search db for recipes matching the provided parameters. All parameters except s are optional and added to the query
     * only if provided. Attributes are specific to Certified Hereford Beef, but can be customized for any recipe kit.
     *
     * @param $request
     *
     * @return string
     */
    public function SendMagicLink($request): string
    {
        if(empty($_COOKIE['slrn_session'])){
            $login = new Login(get_option('slrn_api_key'));
            $login->DoLogin();
        }
        $data=['success' => 1, 'response'=>[]];
        $args = [];
        if((strpos(get_bloginfo('url'),$request['url'] ) == 0 && !empty(filter_var($request, FILTER_SANITIZE_URL)))){
            $args['websiteUrl'] =     $request['url'];
        }
        if(is_numeric($request['pid'] )){
            $args['providerId'] =     $request['pid'];
        }
        $provider = new Provider(get_option('slrn_api_key'));
        $data['response'] = $provider->SendMagicLink($args);

        return json_encode($data);
    }
    /**
     * Search db for recipes matching the provided parameters. All parameters except s are optional and added to the query
     * only if provided. Attributes are specific to Certified Hereford Beef, but can be customized for any recipe kit.
     *
     * @param $request
     *
     * @return string
     */
    public function ValidateMagicLink($request): string
    {
        $login = new Login(get_option('slrn_api_key'));
        if(empty($_COOKIE['slrn_session'])){

            $login->DoLogin();
        }
        $data=['success' => 1, 'response'=>[]];

        $args = [];
        if(!empty(filter_var($request['jrt'], FILTER_SANITIZE_STRING))){
            $args['jwtToken'] =    filter_var($request['jrt'], FILTER_SANITIZE_STRING);
        }
        if(!empty(filter_var($request['pk'], FILTER_SANITIZE_STRING))){
            $args['publicToken'] =     $request['pk'];
        }
        $data['response'] = $login->AuthenticateMagicLink($args);
        return json_encode($data);
    }
}