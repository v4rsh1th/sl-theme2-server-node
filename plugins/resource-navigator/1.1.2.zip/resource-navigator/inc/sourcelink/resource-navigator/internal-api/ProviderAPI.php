<?php

namespace Sourcelink\ResourceNavigator\InternalAPI;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\InternalApiBase;

/**
 * Class RecipeSearchAPI
 * @package Propaganda3\WPO\InternalAPI
 */
class ProviderAPI extends InternalApiBase
{
    /**
     * Registers a single endpoint for searching recipes.
     *
     * @return array Used by WPO engine to generate endpoint
     */
    public function RouteArray(): array
    {
        return [
            [
                'endpoint' => 'send-activity',
                'methods'   => 'POST',
                'callback' => array($this, 'SendActivity'),
            ]
        ];
    }
//    public function register_routes()
//    {
//        $class = get_called_class();
//
//
//
//        add_action(
//            'rest_api_init',
//            function () use ($class) {
//                register_rest_route($class::MachineName(), 'send-activity/', array(
//                    'methods' => 'POST',
//                    'callback' => [$this,'SendActivity'],
//                ));
//
//            }
//        );
//
//    }
    /**
     * Name of common directory for all endpoints in this group. Must be unique.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'slrn_provider';
    }


    /**
     * send user activity to the api
     *
     * @param \WP_REST_Request $request
     *
     * @return \WP_REST_Response
     */
    public function SendActivity(\WP_REST_Request $request): \WP_REST_Response
    {
        if(empty($_COOKIE['slrn_session'])){
            $login = new Login(get_option('slrn_api_key'));
            $login->DoLogin();
        }
        $providerApi = new Provider(get_option('slrn_api_key'));
        $params = $request->get_body_params();

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        $args = [
            'clientId' => filter_var($params['id'], FILTER_SANITIZE_NUMBER_INT),
            'activityType' => filter_var($params['type'], FILTER_SANITIZE_STRING),
            'activityUrl' => filter_var($params['url'], FILTER_SANITIZE_URL),
            'referralUrl' => filter_var($params['referral'], FILTER_SANITIZE_URL),
            'ip' => $ip

        ];

        $results = $providerApi->SaveNavigatorActivity($args);

        $data = json_decode($results["body"], true);
        return new \WP_REST_Response(
            array(
                'response' => $results,
                'body_response' => $data
            )
        );
    }
}