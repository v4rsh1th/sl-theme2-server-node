<?php

namespace Sourcelink\ResourceNavigator\InternalAPI;

use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Service;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\InternalApiBase;

/**
 * Class RecipeSearchAPI
 * @package Propaganda3\WPO\InternalAPI
 */
class ServicesAPI extends InternalApiBase
{
    /**
     * Registers a single endpoint for searching recipes.
     *
     * @return array Used by WPO engine to generate endpoint
     */
    public function RouteArray(): array
    {
        return [
            [
                'endpoint' => 'get-services',
                'method'   => 'GET',
                'callback' => array($this, 'GetServices'),
                'args'     => [
                    'cat' => [
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param);
                        },
                        'required'          => false
                    ],
                    'lang' => [
                        'required'          => false
                    ],
                ]
            ]
        ];
    }

    /**
     * Name of common directory for all endpoints in this group. Must be unique.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'slrn_services';
    }

    /**
     * Search db for recipes matching the provided parameters. All parameters except s are optional and added to the query
     * only if provided. Attributes are specific to Certified Hereford Beef, but can be customized for any recipe kit.
     *
     * @param $request
     *
     * @return string
     */
    public function GetServices($request): string
    {
        if (empty($_COOKIE['slrn_session'])) {
            $login = new Login(get_option('slrn_api_key'));
            $login->DoLogin();
        }
        $data     = ['success' => 1, 'items' => []];
        $cat      = filter_var($request['cat'], FILTER_SANITIZE_NUMBER_INT);
        $lang     = filter_var($request['lang'], FILTER_SANITIZE_STRING);
        $services = new Service(get_option('slrn_api_key'));
        if ( ! empty($cat)) {
            $result = ApiBase::ProcessResult($services->GetServicesByCategoryId((int)$cat)["body"]);
        } else {
            $result = ApiBase::ProcessResult($services->GetServices()["body"]);
        }
        if ( ! empty($result['result'])) {

            foreach ($result['result'] as $item) {
                $data['items'][] = [
                    'id'    => $item['ServiceId'],
                    'label' => ($lang == "spanish" && !empty($item['ServiceLabelSpanish']) ? $item['ServiceLabelSpanish'] : $item['ServiceLabel']) ?? "",
                ];
            }
        }

        return json_encode($data);
    }
}