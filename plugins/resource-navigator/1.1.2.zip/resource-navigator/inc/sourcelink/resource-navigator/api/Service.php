<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class Service extends ApiBase
{
    //API NAMESPACE
    /**
     * @return string
     */
    public function MachineName(): string
    {
        return 'service';
    }

    //API NAMESPACE ENDPOINTS

    /**
     * GetServices - Get all services
     *
     * @param array $args
     *
     * @return array|null
     */
    public function GetServices(array $args =[]): ?array
    {
        return self::Get($this->GetRoute("GetServices"));
    }

    /**
     * GetServicesByCategoryId - Get all services within a service category
     * serviceCategoryId | integer : 181516
     *
     * @param int $serviceCategoryId
     *
     * @return array|null
     */
    public function GetServicesByCategoryId(int $serviceCategoryId): ?array
    {
        return self::Get($this->GetRoute("GetServicesByCategory/" . $serviceCategoryId));
    }

    /**
     * GetProvidersForService - Get all services within a service category
     * serviceId | integer : 15
     *
     * @param int $serviceId
     *
     * @return array|null
     */
    public function GetProvidersForService(int $serviceId): ?array
    {
        return self::Get($this->GetRoute("GetProvidersForService/" . $serviceId));
    }

    /**
     * UpdateServiceOfferedRequest - Insert OR Update a Provider
     *
     * @param array $args
     *
     * @return array|null
     */
    public function UpdateServiceOfferedRequest(array $args =[]): ?array
    {
        return self::Put($this->GetRoute("UpdateServiceOfferedRequest"));
    }
}