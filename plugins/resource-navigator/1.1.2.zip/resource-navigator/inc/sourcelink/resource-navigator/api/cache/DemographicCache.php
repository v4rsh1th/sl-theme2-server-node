<?php

namespace Sourcelink\ResourceNavigator\API\Cache;


use Sourcelink\ResourceNavigator\API\DemographicFilter;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\CacheBase;

class DemographicCache extends CacheBase
{
    protected $api_namespace;
    protected $cache_keys = [

        'GetDemographicFilters' => "slrn_cached_fields",
    ];

    public function __construct()
    {
        $this->api_namespace = new DemographicFilter(get_option('slrn_api_key'));
    }

    //v1.0
    public static function FilterFullArray(): array
    {
        $data     = [];
        $demosObj = new DemographicFilter(get_option('slrn_api_key'));
        $demosRaw = $demosObj->GetDemographicFilters();
        $results  = [];
        if (isset($demosRaw['body'])) {
            $results = ApiBase::ProcessResult($demosRaw['body']);
        }


        $demos = $results['result'];
        if ( ! empty($demos)) {
            foreach ($demos as $demo) {
                if ((isset($demo['IsActive']) && $demo['IsActive'] == false)) {
                    continue;
                }
                $tmp = [
                    'demographicCategoryId'          => $demo['DemographicCategoryId'] ?? 0,
                    'userOrgId'                      => $demo['UserOrgId'] ?? 0,
                    'demographicCategoryText'        => $demo['DemographicCategoryText'] ?? null,
                    'demographicCategoryTextSpanish' => $demo['DemographicCategoryTextSpanish'] ?? null,
                    'questionText'                   => $demo['QuestionText'] ?? null,
                    'questionTextSpanish'            => $demo['QuestionTextSpanish'] ?? null,
                    'primaryQuestionText'            => $demo['PrimaryQuestionText'] ?? null,
                    'primaryQuestionTextSpanish'     => $demo['PrimaryQuestionTextSpanish'] ?? null,
                    'isPublic'                       => $demo['IsPublic'] ?? false,
                    'isActive'                       => $demo['IsActive'] ?? false,
                    'specialtyOnly'                  => $demo['SpecialtyOnly'] ?? false,
                    'isBoolean'                      => $demo['IsBoolean'] ?? false,
                    'allowPrimaryCreate'             => $demo['AllowPrimaryCreate'] ?? false,
                    'allowPrimaryUpdate'             => $demo['AllowPrimaryUpdate'] ?? false,
                    'allowOtherSuggestion'           => $demo['AllowOtherSuggestion'] ?? false,
                    'displayColor'                   => $demo['DisplayColor'] ?? null,
                    'urlName'                        => $demo['UrlName'] ?? null,
                    'demographicValues'              => $demo['DemographicValues'] ?? [],
                    'listOrder'                      => $demo['ListOrder'] ?? 999,
                ];
                if ( ! empty($demo['DemographicCategoryId'])) {
                    $values = ApiBase::ProcessResult($demosObj->GetDemographicValuesByDemographicCategory($demo['DemographicCategoryId'])['body']);
                    if (is_array($values)) {
                        $values = $values['result'];

                        if ( ! empty($values)) {
                            foreach ($values as $value) {
                                $tmp['demographicValues'][] = [
                                    'listOrder'                   => $value['ListOrder'] ?? 999,
                                    'demographicValueId'          => $value['DemographicValueId'] ?? 0,
                                    'demographic'                 => $value['Demographic'] ?? '',
                                    'demographicSpanish'          => $value['DemographicSpanish'] ?? '',
                                    'description'                 => $value['Description'] ?? '',
                                    'descriptionSpanish'          => $value['DescriptionSpanish'] ?? '',
                                    'demographicValueDesc'        => $value['DemographicValueDesc'] ?? '',
                                    'demographicValueDescSpanish' => $value['DemographicValueDescSpanish'] ?? ''
                                ];
                            }
                        }
                    }
                }


                $data[] = $tmp;
            }
        }

        return $data;
    }

    public static function FilterCategoryArray($lang = ""): array
    {
        $savedFilters = get_option('slrn_cached_fields');
        if (empty($savedFilters)) {
            $savedFilters = self::FilterFullArray();
        }
        $rtn = [];
        if ( ! empty($savedFilters)) {
            foreach ($savedFilters as $filterCat) {
                $rtn[$filterCat['demographicCategoryId']] = $lang == "spanish" ? $filterCat['demographicCategoryTextSpanish'] : $filterCat['demographicCategoryText'];
            }
        }

        return $rtn;
    }


    public static function FilterArray($cat = "", $lang = ""): array
    {
        $savedFilters = get_option('slrn_cached_fields');
        if (empty($savedFilters)) {
            $savedFilters = self::FilterFullArray();
        }
        $rtn = [];
        if ( ! empty($savedFilters)) {
            if ( ! empty($cat)) {


                foreach ($savedFilters as $filterCat) {

                    if (($filterCat['demographicCategoryId'] != $cat)) {
                        continue;
                    }
                    foreach ($filterCat['demographicValues'] as $filter) {
                        $rtn[$filter['demographicValueId']] = $lang == "spanish" ? $filter['demographicSpanish'] : $filter['demographic'];
                    }
                }
            } else {
                foreach ($savedFilters as $filterCat) {
                    foreach ($filterCat['demographicValues'] as $filter) {
                        $rtn[$filter['demographicValueId']] = $lang == "spanish" ? $filter['demographicSpanish'] : $filter['demographic'];
                    }
                }
            }
        }

        return $rtn;
    }

}