<?php

namespace Sourcelink\ResourceNavigator\API;

use Sourcelink\ResourceNavigator\ApiBase;

class Provider extends ApiBase
{
    //API NAMESPACE
    public function MachineName(): string
    {
        return 'Provider';
    }

    //API NAMESPACE ENDPOINTS

    /**
     * GetProviders - Retrieves a list of Providers (Provider Search)
     * filter1Ids | string
     * filter2Ids | string
     * filter5Ids | string
     * filter6Ids | string
     * filter7Ids | string
     * filter9Ids | string
     * filter10Ids | string
     * filter11Ids | string
     * filter12Ids | string
     * filter13Ids | string
     * keyword | string
     * serviceCategoryIds | string
     * serviceIds | string
     * providerName | string
     * providerId | integer
     * zipcode | string
     * distance | integer
     * searchLogLocation | string
     * userIp | string
     * liveSearch | bool
     *
     * @param array $filters
     *
     * @return array|null
     */
    public function GetProviders(array $filters = []): ?array
    {
        //$query = http_build_query($filters);
        $query = http_build_query(array_filter($filters));

        return self::Get($this->GetRoute("GetProviders?" . $query));
    }

    /**
     * GetProviderById - Retrieves Provider by Provider / Client ID
     *
     * @param int $id
     *
     * @return array|null
     */
    public function GetProviderById(int $id): ?array
    {
        return self::Get($this->GetRoute("GetProvider?providerId=" . $id));
    }

    /**
     * SaveProvider - Insert OR Update a Provider
     * logo | base64 encoded image
     *
     * @param array $args
     *
     * @return array|null
     */
    public function SaveProvider(array $args =[]): ?array
    {

        return self::Post($this->GetRoute("SaveProvider"), $args);
    }

    /**
     * SendMagicLink - Send the Provider a Magic Link
     *
     * @param array $args
     *
     * @return array|null
     */
    public function SendMagicLink(array $args =[]): ?array
    {
        $query = http_build_query(array_filter($args));
        return self::Get($this->GetRoute("SendMagicLink?" . $query));
    }
/**
     * SaveNavigatorActivity - Save Frontend User Activity
     *
     * @param array $args
     *
     * @return array|null
     */
    public function SaveNavigatorActivity(array $args =[]): ?array
    {
        return self::Post($this->GetRoute("SaveNavigatorActivity"), $args);
    }

}