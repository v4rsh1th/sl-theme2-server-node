<?php


namespace Sourcelink\ResourceNavigator;

use Sourcelink\ResourceNavigator\Exception\APIException;

class ApiBase
{
    protected $namespace;
    protected $url = 'https://api.joinsourcelink.com/api';
    protected $staging = 'https://apitest.joinsourcelink.com/api';
    protected $version = 'v1';
    protected $API_KEY = "";

    public function __construct($key = "")
    {
        $this->API_KEY   = $key;
        $this->namespace = $this->MachineName();
    }

    /**
     * Default initiation call. All classes in Resource Navigator engine use ::Bootstrap to set the initial hooks and filters for that
     * class. Register will handle instance specific hooks and filters while this class handles global default registrations
     *
     * @param mixed $input Ignored by the engine, but required to Bootstrap.
     *
     * @return mixed $customPost
     */
    public static function Bootstrap($input = '')
    {
        $class                 = get_called_class();
        $customPost            = new $class(get_option('slrn_api_key'));
        $customPost->namespace = $customPost->MachineName();
        $customPost->Register($input);

        return $customPost;
    }

    /**
     * Name in the WordPress DB for object
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'endpoint';
    }

    /**
     * @param $input
     */
    public function Register($input)
    {
    }

    /**
     * Instances will override this function to return a structured array of inputs used to establish the endpoint.
     *
     * @return array
     */
    public function RouteArray(): array
    {
        return [];
    }

    /**
     * Instances will override this function to return a structured array of inputs used to establish the endpoint.
     *
     * @param string $endpoint
     *
     * @return string
     */
    public function GetRoute(string $endpoint = ""): string
    {
        $url_in_use = $this->url;
        if(!empty(get_option('slrn_use_staging'))){
            $url_in_use = $this->staging;
        }
        if ( ! empty($endpoint)) {
            return $url_in_use . '/' . $this->version . '/' . $this->namespace . '/' . $endpoint;
        }

        return $url_in_use . '/' . $this->version . '/' . $this->namespace;
    }

    /**
     * @param string $route
     *
     * @return array|null
     */
    public static function Get(string $route = ""): ?array
    {
        if ( ! empty($route)) {
            $curl = curl_init();

            curl_setopt_array(
                $curl,
                array(
                    CURLOPT_URL            => $route,
                    CURLOPT_HEADER         => 1,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING       => "",
                    CURLOPT_MAXREDIRS      => 10,
                    CURLOPT_TIMEOUT        => 30,
                    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST  => "GET",
                )
            );
            if (isset($_COOKIE['slrn_session'])) {
                curl_setopt($curl, CURLOPT_COOKIE, 'WS_AUTH_ID=' . $_COOKIE['slrn_session'] . '; path=/; domain=api.joinsourcelink.com; samesite=lax;');
            }
            $response    = curl_exec($curl);
            $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
            $header      = substr($response, 0, $header_size);

            $headers = ApiBase::CurlHeadersFromResponse($header);
            $body    = substr($response, $header_size);
            curl_close($curl);

            return ["headers" => $headers, "body" => $body, ];
        }

        return null;
    }


    /**
     * @param $headerContent
     *
     * @return array
     */
    public static function CurlHeadersFromResponse($headerContent): array
    {
        $headers = array();

        // Split the string on every "double" new line.
        $arrRequests = explode("\r\n\r\n", $headerContent);

        // Loop of response headers. The "count() -1" is to
        //avoid an empty row for the extra line break before the body of the response.
        for ($index = 0; $index < count($arrRequests) - 1; $index++) {
            foreach (explode("\r\n", $arrRequests[$index]) as $i => $line) {
                if ($i === 0) {
                    $headers[$index]['http_code'] = $line;
                } else {
                    list ($key, $value) = explode(': ', $line);
                    $headers[$index][$key] = $value;
                }
            }
        }

        return $headers;
    }

    /**
     * @param string $route
     * @param mixed $args
     *
     * @return array|null
     */
    public static function Post(string $route = "", $args = []): ?array
    {
        if ( ! empty($route)) {
            $curl = curl_init();
            if(!is_array($args)){
                $opts = array(
                    CURLOPT_URL            => $route,
                    CURLOPT_HEADER         => 1,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING       => "",
                    CURLOPT_MAXREDIRS      => 10,
                    CURLOPT_TIMEOUT        => 30,
                    CURLOPT_HTTPHEADER     => ['accept:text/plain', 'Content-Type:application/json'],
                    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST  => "POST",
                    CURLOPT_POSTFIELDS      => $args->toJSON(),
                );
            }
            else {
                $opts = array(
                    CURLOPT_URL            => $route,
                    CURLOPT_HEADER         => 1,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING       => "",
                    CURLOPT_MAXREDIRS      => 10,
                    CURLOPT_TIMEOUT        => 30,
                    CURLOPT_HTTPHEADER     => ['Content-Type:application/json'],
                    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST  => "POST",
                    CURLOPT_POSTFIELDS      => json_encode($args)

                );
            }
            curl_setopt_array(
                $curl,
                $opts
            );
            if (isset($_COOKIE['slrn_session'])) {
                curl_setopt($curl, CURLOPT_COOKIE, 'WS_AUTH_ID=' . $_COOKIE['slrn_session'] . '; path=/; domain=api.joinsourcelink.com; samesite=lax;');
            }
            $response    = curl_exec($curl);
            $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
            $header      = substr($response, 0, $header_size);

            $headers = ApiBase::CurlHeadersFromResponse($header);
            $body    = substr($response, $header_size);
            curl_close($curl);

            return ["headers" => $headers, "body" => $body, ];
        }

        return null;
    }

    public static function Put($route = "", $args = [])
    {
        return null;
    }

    /**
     * @param $raw
     *
     * @return array[]|mixed
     */
    public static function ProcessResult($raw)
    {
        try {
            $arr = json_decode($raw, true);
            if (isset($arr['isError']) && $arr['isError'] === false) {
                return $arr;
            }
            else{
                throw new APIException("unable to contact API", 500);
            }
        } catch (APIException $e) {
            return ["response" => ["code" => $e->getCode(), 'message' => $e->getMessage()]];
        }
    }

//    public static function GetHeaders()
//    {
//        if (isset($_COOKIE['slrn_session'])) {
//            return [
//                'headers' => [
//                    'cookie' => 'WS_AUTH_ID=' . $_COOKIE['slrn_session'],
//
//                ]
//            ];
//        } else {
//            return false;
//        }
//    }

}
