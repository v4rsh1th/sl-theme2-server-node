<?php

namespace Sourcelink\ResourceNavigator\Block;
use Sourcelink\ResourceNavigator\BlockBase;
use Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost;

class PartnerProfileFormBlock extends BlockBase {
    /**
     * @return string
     */
    public function MachineName(): string
    {
        return 'partner-profile-form-block';
    }

    /**
     * @return string
     */
    public function Name(): string
    {
        return 'Partner Profile Form Block';
    }

    /**
     * @return array[]
     */
    public function GetSidebarInputs(): array
    {
        $profiles = PartnerProfileFormPost::SelectOptions();
        return [
            'id' => [
                'title' => 'Partner Profile',
                'type' => 'select',
                'values' => [0=>'Select'] + $profiles
            ],
        ];
    }

    /**
     * @param array $attributes
     * @param string|null $content
     *
     * @return string
     */
    public function Display(array $attributes, string $content = null): string
    {
        return PartnerProfileFormPost::Render($attributes);
    }
}
