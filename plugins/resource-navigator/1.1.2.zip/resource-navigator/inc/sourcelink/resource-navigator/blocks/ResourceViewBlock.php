<?php
/*
 * @desctiption : Manages display and control of event objects in the wp admin. This is the simple version with basic
 *                date, venue string and url. Subclass for more complex functionality
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\Block;
use Sourcelink\ResourceNavigator\BlockBase;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;

class ResourceViewBlock extends BlockBase {
    public function MachineName(): string
    {
        return 'resource-view-block';
    }

    public function Name() {
        return 'Resource View Block';
    }



    public function GetSidebarInputs(): array
    {
        $profiles = ResourceViewPost::SelectOptions();
        return [
            'id' => [
                'title' => 'Resource View',
                'type' => 'select',
                'values' => [0=>'Select'] + $profiles
            ],
        ];
    }
    /**
     * @param array $attributes
     * @param string|null $content
     *
     * @return string
     */
    public function Display(array $attributes, string $content = null): string
    {
        return ResourceViewPost::Render($attributes);
    }
    /* -----------------   END SEE OVERRIDDEN PARENT CLASS METHODS   ----------------------- */
}
