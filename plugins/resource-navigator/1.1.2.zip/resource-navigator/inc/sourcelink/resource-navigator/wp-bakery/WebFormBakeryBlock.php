<?php
/*
 * @desctiption : Manages display and control of event objects in the wp admin. This is the simple version with basic
 *                date, venue string and url. Subclass for more complex functionality
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\WPBakery;
use Sourcelink\ResourceNavigator\Post\WebFormPost;
use Sourcelink\ResourceNavigator\ShortcodeBase;
if ( class_exists( 'WPBakeryShortCode' ) && !class_exists( 'WebFormBakeryBlock' ) ) {

    class WebFormBakeryBlock extends \WPBakeryShortCode {

        //Initialize Component
        function __construct() {
            add_action( 'init', array( $this, 'create_shortcode' ), 999 );
            add_shortcode( 'vc_web_form', array( $this, 'render_shortcode' ) );

        }
        public static function Bootstrap() {
//            $class      = get_called_class();
//            add_action( 'init', array( $class, 'create_shortcode' ), 999 );
//            add_shortcode( 'vc_web_form', array( $class, 'render_shortcode' ) );

        }
        //Map Component
        public function create_shortcode() {
            if(function_exists('vc_map')){
                vc_map( array(
                    "name" => __("SourceLink Web Form"),
                    "base" => "vc_web_form",
                    "category" => __('SourceLink'),
                    "params" => array(
                        array(
                            "type" => "dropdown",
                            "holder" => "div",
                            "class" => "",
                            "heading" => __("Web Form"),
                            "param_name" => "id",
                            "value" => array_merge(['-- Select a Form --'=>''],array_flip(WebFormPost::SelectOptions())),
                            "description" => __("Select the web form to use.")
                        )
                    )
                ) );
            }
            //Code in the next steps

        }

        //Render Component
        public function render_shortcode( $atts, $content, $tag ) {
            if(is_array($atts)){
                if(!is_numeric($atts['id'])){
                    global $wpdb;
                    $post = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type='web_form'", $atts['id'] ));
                    $atts['id'] = $post;
                }
                $data=[];
                return WebFormPost::Render($atts, $data);
            } else{
                return null;
            }
        }

    }


}
