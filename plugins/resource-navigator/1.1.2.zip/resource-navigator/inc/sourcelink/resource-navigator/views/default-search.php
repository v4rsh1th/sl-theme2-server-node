<?php
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;

global $wpdb;
$results = $wpdb->get_results( "select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'resource_view_default_view'", ARRAY_A );
if(empty(get_option('slrn_api_key') || empty($results))){
    wp_redirect(get_page_by_path('/'));
}
//ob_start();
//get_header();
//$header = ob_get_clean();
//$header = preg_replace('#<title>(.*?)<\/title>#', '<title>Resource Navigator - '.get_bloginfo('name').'</title>', $header);
//echo $header;

//get all data for this post
if(!empty($results)){
    $post->post_title = $results[0]['post_title'];
    $post->post_content = ResourceViewPost::render(['id'=>$results[0]['post_id']]);
}
//get_footer();