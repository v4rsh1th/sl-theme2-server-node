<?php

use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\Post\ResourceViewPost;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
$view = intval(get_query_var('slrn_view'));;
global $base;
global $wpdb;
if(!empty($view)){
    $results = $wpdb->get_results( "select * from {$wpdb->prefix}posts where ID = {$view} and post_type = 'resource_view'", ARRAY_A );
} else {
    $results = $wpdb->get_results( "select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'resource_view_default_view'", ARRAY_A );
//get all data for this post
}
if(!empty($results)){
    print '<!DOCTYPE html><html lang="en-US">';
    print '<head>';
    print '<title></title>';
    print '<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/pristine.min.js').'"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/frontend/common.js').'"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/datepicker-full.min.js').'"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/slrn.admin.base.js').'"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/slrn.settings.js').'"></script>';
    print '<script>window.ResourceNavigator.Settings.setBlogUrl("' . get_bloginfo("url") . '/");</script>';


    $url_in_use = "https://api.joinsourcelink.com/api/";
    if(!empty(get_option('slrn_use_staging'))){
        $url_in_use = 'https://apitest.joinsourcelink.com/api/';
    }
    print '<script>window.ResourceNavigator.Settings.setAPIUrl("' . $url_in_use . '");</script>';

    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/api/service.js').'"></script>';
    print '<script src="' . ResourceNavigatorUtilityBase::GetAsset('js/api/track-activity.js').'"></script>';
    print '<script src="//polyfill.io/v3/polyfill.min.js?features=default"></script>';
    print '<script src="'.ResourceNavigatorUtilityBase::GetAsset('js/libs/bootstrap4.min.js').'"></script>';

    //print '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">';

    print '<link type="text/css" rel="stylesheet" href="' . ResourceNavigatorUtilityBase::GetAsset('css/libs/datepicker.min.css').'">';
    print '<link type="text/css" rel="stylesheet" href="' . ResourceNavigatorUtilityBase::GetAsset('css/frontend-style.min.css').'">';
//    if(!empty($view)) {
//        print get_postmeta($results[0]['ID'], 'resource_view_header_code', 'true');
//    } else {
//        print get_postmeta($results[0]['post_id'], 'resource_view_header_code', 'true');
//    }
    print '</head>';
    print '<body>';
    if(!empty($view)) {
        print ResourceViewPost::Render(['id' => $results[0]['ID'], 'chromeless' => true]);
    } else {
        print ResourceViewPost::Render(['id'=>$results[0]['post_id'], 'chromeless' => true]);
    }

    print '<script src="'.ResourceNavigatorUtilityBase::GetAsset('js/frontend/pagination.js').'"></script>';
    print '<script src="'.ResourceNavigatorUtilityBase::GetAsset('js/frontend/mapview.js').'"></script>';
    print '<script src="//polyfill.io/v3/polyfill.min.js?features=default"></script>';
    print '<script src="//maps.googleapis.com/maps/api/js?key=' . get_option('slrn_gm_api_key') . '&callback=loadMaps&libraries=&v=weekly" defer></script>';

    print '<script type="text/javascript">';
    print 'function loadMaps(){';
    foreach($base->_maps as $map=>$callback){
        echo $callback . '();';
    }
    print '}';
    print '</script>';
    print '</body>';

    print '<script type="text/javascript" defer src="' . ResourceNavigatorUtilityBase::GetAsset('js/libs/iframeResizer.contentWindow.min.js').'"></script>';
    
    print '</html>';
} else{
    print '';
}
