<?php
global $wpdb;global $post;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;

if(empty(get_option('slrn_api_key'))){
    wp_redirect(get_page_by_path('/'));
}
$login = new Login(get_option('slrn_api_key'));
if (empty($_COOKIE['slrn_session'])) {
    $loginResult = $login->DoLogin();
    if( (isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)){
        wp_redirect(get_page_by_path('/'));
    }
}

$staticClass = "\Sourcelink\ResourceNavigator\Post\WebFormPost";
$response_url = get_query_var('slrn_response');
$row = \Sourcelink\ResourceNavigator\Utility\ResponseData::GetResponse($response_url);
$data = [
    'post' => ResourceNavigatorUtilityBase::GetPostProperties(get_post($row['post_id']), $staticClass),
    'responses' => unserialize($row['data'])
    ];
$ref_ids = [];
foreach ($data['responses'] as $res) {
    if(!empty($res['provider']) ){
        $providers = explode(',', $res['provider']);

        $ref_ids = array_unique(array_merge($ref_ids, array_map('intval', $providers)));

    }
}
$data['providers'] = $ref_ids;
$results = $wpdb->get_results( "select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'resource_view_default_view'", ARRAY_A );
$viewID = $results[0]['post_id'];

$view = get_post($viewID);
$data['view'] = ResourceNavigatorUtilityBase::GetPostProperties($view, 'Sourcelink\ResourceNavigator\Post\ResourceViewPost');
$data['no_logo'] =  plugin_dir_url( __DIR__ ).'../assets/images/placeholder.png';

$post->post_title = '';


$post->post_content = TwigManager::Twig()->Render('view/response.twig', $data);