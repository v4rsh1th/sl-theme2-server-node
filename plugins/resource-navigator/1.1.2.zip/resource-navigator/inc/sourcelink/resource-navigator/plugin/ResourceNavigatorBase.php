<?php
/*
 * @desctiption : Use to orchestrate the startup of ResourceNavigator. In this object you can define the classes and components for
 *                the current installation
 * @version     : 5.0
 * @author      : DP
 * @changelog   :
  |Date          | Author        |Description
  ===============|===============|======================================================================================
  | 2016/12/28    | DP          | Initial creation
  ----------------------------------------------------------------------------------------------------------------------
*/

namespace Sourcelink\ResourceNavigator\Plugin;
use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\Elementor\WebFormEWidget;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\WPBakery\WebFormBakeryBlock;

class ResourceNavigatorBase
{
    private $_classes = [
        '\Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase'=>'',
        '\Sourcelink\ResourceNavigator\TwigManager'=>'',
        '\Sourcelink\ResourceNavigator\Post\PartnerProfileFormPost'=>'',
        '\Sourcelink\ResourceNavigator\Block\PartnerProfileFormBlock'=>'',
        '\Sourcelink\ResourceNavigator\Shortcode\PartnerProfileFormShortcode'=>'',
        '\Sourcelink\ResourceNavigator\Post\ResourceViewPost'=>'',
        '\Sourcelink\ResourceNavigator\Block\ResourceViewBlock'=>'',
        '\Sourcelink\ResourceNavigator\Shortcode\ResourceViewShortcode'=>'',
        '\Sourcelink\ResourceNavigator\Utility\ResponseData'=>'',
        '\Sourcelink\ResourceNavigator\Post\WebFormPost'=>'',
        '\Sourcelink\ResourceNavigator\Block\WebFormBlock'=>'',
        '\Sourcelink\ResourceNavigator\Shortcode\WebFormShortcode'=>'',
        '\Sourcelink\ResourceNavigator\InternalAPI\ServicesAPI'=>'',
        '\Sourcelink\ResourceNavigator\InternalAPI\ProviderAPI'=>'',
        '\Sourcelink\ResourceNavigator\InternalAPI\WebFormAPI'=>'',

    ];
    public $_maps = [
    ];
    private $_settings_classes = [

        '\Sourcelink\ResourceNavigator\Settings\MainSettings'=>'',
        '\Sourcelink\ResourceNavigator\Settings\ReferralRegions'=>'',
        '\Sourcelink\ResourceNavigator\Settings\APICacheSettings'=>'',
        //'\Sourcelink\ResourceNavigator\Settings\ApiTest'=>'',
        '\Sourcelink\ResourceNavigator\SettingsTabs'=>'',

        '\Sourcelink\ResourceNavigator\Settings\HelpSettings'=>'',
    ];
    private $_divi_classes = [
        '\Sourcelink\ResourceNavigator\Divi\ApiTest'=>'',
    ];
    /**
     * Call this method to get singleton
     *
     * @return ResourceNavigatorBase
    */
    public static function Instance(): ?ResourceNavigatorBase
    {
        static $inst = null;
        if ($inst === null) {
            $inst = new ResourceNavigatorBase();
        }
        return $inst;
    }

    public static function GetCacheVersion(){
        return '34tqgh7ogsfdw3gpipj432';
    }

    public function __construct() {

        add_action( 'admin_enqueue_scripts', array($this, 'enqueueAdmin') );

        add_action( 'wp_enqueue_scripts', array($this, 'enqueueFrontend') );
        add_action( 'enqueue_block_editor_assets', [$this, 'slrn_guten_scripts'] );
        add_action( 'admin_menu', [$this, 'app_settings_menu'] );
        add_action( 'slrn_cache_cron', [$this, 'ScheduleAPICaching'], 10, 2 );
        if(!wp_next_scheduled( 'slrn_cache_cron' )){
            $when = time();
            if( (date('H') >= 6) && (date('H') < 18) ){
                // between 1PM and 4PM
                $when += 12*60*60;
            }
            wp_schedule_event( $when , 'daily', 'slrn_cache_cron' );
        }
        add_filter( 'block_categories', function( $categories, $post ) {
            return array_merge(
                $categories,
                [[
                    'slug' => 'resource-navigator-category',
                    'title' => 'Resource Navigator Blocks',
                    'icon'  => '<svg width="24" height="24" viewBox="0 0 50 50" role="img" aria-hidden="true" focusable="false"><path d="M25.014 0C11.198 0 0 11.198 0 25.014c0 13.814 11.198 25.014 25.014 25.014 13.814 0 25.014-11.2 25.014-25.014C50.028 11.198 38.828 0 25.014 0zm6.497 35.204l-6.718-4.867-6.89 4.867 2.627-7.854-6.706-4.76H22.2l2.592-7.884 2.655 7.884h8.157l-6.642 4.76 2.548 7.854z" fill="#c00"></path></svg>',
                ]]
            );
        }, 10, 2 );

        add_action('wp_footer', [$this, 'loadMaps']);
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'WidgetsRegistered' ] );
        if ( class_exists( 'WPBakeryShortCode' ) && !class_exists( 'WebFormBakeryBlock' ) ) {
            $webformbakery = new WebFormBakeryBlock();
        }



    }
    public static function WidgetsRegistered(){
        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new WebFormEWidget() );
    }
    function ScheduleAPICaching(  ) {

        $login = new Login(get_option('slrn_api_key'));
        $login->DoLogin();
        $IntakeCache = new IntakeCache();
        update_option('slrn_cached_fields', DemographicCache::FilterFullArray());
        update_option('slrn_cached_services', ServiceCache::ServiceFullArray());
        $IntakeCache->CacheAll();
        update_option('slrn_cached_date', time());
    }

    public function slrn_guten_scripts() {
        wp_enqueue_script(
            'slrn-guten-script',
            ResourceNavigatorUtilityBase::GetAsset('js/slrn-guten.js'),
            array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-editor' )
        );
    }

    public function setupClasses($args = array()) {

        // Merge the passed classes into the classes.
        $args = wp_parse_args( $args, $this->_classes );
        foreach($args as $class=>$postsArgs) {
            if($postsArgs == -1) continue; // Force ignore classes if required
            $class::Bootstrap($postsArgs);
        }
    }
    public function setupSettingsClasses($args = array()) {

        // Merge the passed classes into the classes.
        $args = wp_parse_args( $args, $this->_settings_classes );
        foreach($args as $class=>$postsArgs) {
            if($postsArgs == -1) continue; // Force ignore classes if required
            $class::Bootstrap($postsArgs);
        }
    }

    public function enqueueAdmin(){
        wp_enqueue_script( 'jquery-ui-dialog' ); // jquery and jquery-ui should be dependencies, didn't check though...
        wp_enqueue_style( 'wp-jquery-ui-dialog' );
        wp_enqueue_script( 'media' );
//        $screen = get_current_screen();
//        if ( $screen->parent_base == 'edit' ) {
            wp_enqueue_editor();
        //}

        wp_enqueue_style( 'slrn-admin-ui', ResourceNavigatorUtilityBase::GetAsset('css/admin-style.min.css'), [], ResourceNavigatorBase::GetCacheVersion() );
        wp_enqueue_style( 'slrn-select2-ui', ResourceNavigatorUtilityBase::GetAsset('css/libs/select2.min.css'), [], ResourceNavigatorBase::GetCacheVersion() );
        wp_enqueue_script('slrn-google-maps', '//maps.googleapis.com/maps/api/js?key=' . get_option('slrn_gm_api_key') . '&callback=loadMaps&libraries=&v=weekly', [], false, ResourceNavigatorBase::GetCacheVersion());

        wp_enqueue_script('slrn-clipboard-js',  ResourceNavigatorUtilityBase::GetAsset('js/libs/clipboard.min.js'), [], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-boots-js',  ResourceNavigatorUtilityBase::GetAsset('js/libs/bootstrap4.min.js'), ['jquery'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-admin-js',  ResourceNavigatorUtilityBase::GetAsset('js/slrn.admin.js'), ['jquery-ui-dialog','slrn-clipboard-js','slrn-boots-js','media'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-settings-js',  ResourceNavigatorUtilityBase::GetAsset('js/slrn.settings.js'), ['slrn-admin-js'], ResourceNavigatorBase::GetCacheVersion());
        wp_add_inline_script(
            "slrn-settings-js",
            'jQuery(function(){window.ResourceNavigator.Settings.setBlogUrl("' . get_bloginfo("url") . '/");});'
        );
        wp_enqueue_script('slrn-service-js',  ResourceNavigatorUtilityBase::GetAsset('js/api/admin-service.js'), ['jquery', 'slrn-settings-js'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-select2-js',  ResourceNavigatorUtilityBase::GetAsset('js/libs/select2.min.js'), ['jquery', 'slrn-settings-js'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-questions-js',  ResourceNavigatorUtilityBase::GetAsset('js/api/questions.js'), ['jquery', 'slrn-settings-js'], ResourceNavigatorBase::GetCacheVersion());
    }
    public function enqueueFrontend(){
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'tiny_mce' );

        wp_enqueue_script( 'slrn-validate-js' ,  ResourceNavigatorUtilityBase::GetAsset('js/libs/pristine.min.js'), ['jquery'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-common-js',  ResourceNavigatorUtilityBase::GetAsset('js/frontend/common.js'), ['jquery'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-datepicker-js',  ResourceNavigatorUtilityBase::GetAsset('js/libs/datepicker-full.min.js'), ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-base-js',  ResourceNavigatorUtilityBase::GetAsset('js/slrn.admin.base.js'), ['jquery'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-settings-js',  ResourceNavigatorUtilityBase::GetAsset('js/slrn.settings.js'), ['slrn-base-js'], ResourceNavigatorBase::GetCacheVersion());


        wp_add_inline_script(
            "slrn-settings-js",
            'window.ResourceNavigator.Settings.setBlogUrl("' . get_bloginfo("url") . '/");'
        );


        $url_in_use = "https://api.joinsourcelink.com/api/";
        if(!empty(get_option('slrn_use_staging'))){
            $url_in_use = 'https://apitest.joinsourcelink.com/api/';
        }

        wp_add_inline_script(
            "slrn-settings-js",
            'window.ResourceNavigator.Settings.setAPIUrl("' . $url_in_use . '");'
        );
        wp_enqueue_script('slrn-service-js',  ResourceNavigatorUtilityBase::GetAsset('js/api/service.js'), ['jquery', 'slrn-settings-js'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_script('slrn-tracking-js',  ResourceNavigatorUtilityBase::GetAsset('js/api/track-activity.js'), ['slrn-settings-js'], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_style( 'slrn-datepicker-ui', ResourceNavigatorUtilityBase::GetAsset('css/libs/datepicker.min.css'), [], ResourceNavigatorBase::GetCacheVersion());
        wp_enqueue_style( 'slrn-main-ui', ResourceNavigatorUtilityBase::GetAsset('css/frontend-style.min.css'), [], ResourceNavigatorBase::GetCacheVersion());

    }
    public static function addMap($map , $callback) {
        global $base;
        $base->_maps[$map] = $callback;

    }
    public static function getMaps() {
        global $base;
        return $base->_maps;

    }
    public static function loadMaps() {
        global $base;
        echo '<script type="text/javascript">';
        echo 'function loadMaps(){';
        foreach($base->_maps as $map=>$callback){
            echo $callback . '();';
        }
        echo '}';
        echo '</script>';

    }
    public static function registeredPosts() {
        global $base;

        $rtn = [];
        foreach($base->_classes as $key=>$val) {
            if(preg_match('/Sourcelink\\\ResourceNavigator\\\Post/', $key) > 0) {
                $eachObj = new $key();
                $rtn[$eachObj->MachineName()] = $key;
            }
        }
        return $rtn;
    }
    public static function registeredSettings() {
        global $base;

        $rtn = [];
        foreach($base->_classes as $key=>$val) {
            if(preg_match('/Sourcelink\\\ResourceNavigator\\\Settings/', $key) > 0) {
                $eachObj = new $key();
                $rtn[$eachObj->MachineName()] = $key;
            }
        }
        return $rtn;
    }
    public static function registeredTaxonomies() {
        global $base;

        $rtn = [];
        foreach($base->_classes as $key=>$val) {
            if(preg_match('/Sourcelink\\\ResourceNavigator\\\Taxonomy/', $key) > 0) {
                $eachObj = new $key();
                $rtn[$eachObj->MachineName()] = $key;
            }
        }
        return $rtn;
    }
    public static function registeredMeta() {
        global $base;

        $rtn = [];
        foreach($base->_classes as $key=>$val) {
            $eachObj = new $key();
            if(preg_match('/Sourcelink\\\ResourceNavigator\\\Meta/', $key) > 0) {
                $rtn[$eachObj->MachineName()] = $key;
            }
        }
        $rtn['post'] = '\Sourcelink\ResourceNavigator\PostBase';
        return $rtn;
    }
    public static function registered() {
        global $base;

        $rtn = [];
        foreach($base->_classes as $key=>$val) {
            $eachObj = new $key();
            if(method_exists($eachObj, 'MachineName')) {
                $rtn[$eachObj->MachineName()] = $key;
            }
        }
        return $rtn;
    }
    /**
     * Register a custom menu page.
     */
    public function app_settings_menu() {
        add_menu_page(
            __( 'App Settings', 'textdomain' ),
            'SourceLink',
            'manage_options',
            'admin.php?page=resource_navigator',
            [$this, 'app_settings_menu_page'],
            'dashicons-list-view',
            40
        );
    }
    public function app_settings_menu_page(){
        echo '';
    }

}
