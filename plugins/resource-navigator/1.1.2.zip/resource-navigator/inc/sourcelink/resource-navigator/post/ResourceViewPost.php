<?php

namespace Sourcelink\ResourceNavigator\Post;


use phpDocumentor\Reflection\Types\This;
use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\API\Service;
use Sourcelink\ResourceNavigator\API\ServiceCategories;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\PostBase as PostBase;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\TwigManager;

class ResourceViewPost extends PostBase
{
    /**
     * Edit the default args for resource-navigator objects to add excerpt and change visibility.
     *
     * @param array $overrides
     *
     * @return array $overrides
     */
    public function GetArgs(array $overrides = array()): array
    {
        $overrides = array_merge($overrides, array(
            'supports'           => array('title', 'page_attributes'),
            'show_in_menu'       => 'admin.php?page=resource_navigator',
            'publicly_queryable' => false

        ));

        return parent::GetArgs($overrides);
    }

    public static function posts_columns($columns)
    {
        $columns['shortcode']    = 'Shortcode';
        $columns['view_type']    = 'View Type';
        $columns['default_view'] = 'Default View';
        $columns['note']         = 'Note';

        return $columns;
    }

    public static function posts_column_data($column, $post_id)
    {
        if ($column == 'shortcode') {
            echo '<pre>[resource_view id="' . $post_id . '"]</pre>';
        }
        if ($column == 'view_type') {
            $type = get_post_meta($post_id, 'resource_view_layout', true);
            switch ($type) {
                case 'search':
                    echo 'Independent Search Form (Homepage widget)';
                    break;
                case 'titles':
                    echo 'Titles Only';
                    break;
                case 'simple':
                    echo 'Simple Directory';
                    break;
                case 'directory':
                    echo 'Full Directory';
                    break;
                case 'full-search':
                    echo 'Search w/ Full Directory';
                    break;
                default:
                    break;
            }
        }
        if ($column == 'default_view') {
            $is_default = get_post_meta($post_id, 'resource_view_default_view', true);
            if ( ! empty($is_default)) {
                echo '<span class="dashicons dashicons-yes-alt"></span>';
            }
        }
        if ($column == 'note') {
            $note = get_post_meta($post_id, 'resource_view_admin_note', true);
            echo $note;
        }
    }

    /**
     * Name for the admin panel.
     *
     * @return string
     */
    public function Name(): string
    {
        return 'Resource View';
    }

    /**
     * Plural Name for the admin panel.
     *
     * @return string
     */
    public function PluralName(): string
    {
        return 'Resource Views';
    }

    /**
     * Name in wordpress DB for object.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'resource_view';
    }

    public function GetInputs()
    {
        //fetch demos
        $saved_demos = get_option('slrn_cached_fields');
        if (empty($saved_demos)) {
            $saved_demos = DemographicCache::FilterFullArray();
        }
        $filters = [];
        foreach ($saved_demos as $demo) {
            if ($demo['isActive'] === false) {
                continue;
            }
            $filters['demo_category_' . $demo['demographicCategoryId']] = [
                'type'         => 'filter',
                'value'        => '',
                'name_val'     => '',
                'text'         => $demo['demographicCategoryText'],
                'text_spanish' => $demo['demographicCategoryTextSpanish'],
                'size'         => 'col-12',
                'hint'         => '',
                'order'        => $demo['demographicCategoryId'],
                'options'      => DemographicCache::FilterArray($demo['demographicCategoryId']),
                'settings'     => [
                    'initalize' => [
                        'text' => 'Set Default Value'
                    ],
                    'required'  => [
                        'text' => 'Required'
                    ],
                    'enabled'   => [
                        'text'    => 'Enabled',
                        'default' => true
                    ]
                ]
            ];
        }

        return [
            [
                'type'      => 'panel',
                'id'        => 'general-section',
                'shortcode' => $this->MachineName(),
                'embed'     => true,
                'header'    => 'General Settings',
                'inputs'    => [
                    'layout'       => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => [
                            'search'      => 'Independent Search Form (Homepage widget)',
                            'titles'      => 'Titles Only',
                            'simple'      => 'Simple Directory',
                            'directory'   => 'Full Directory',
                            'full-search' => 'Search w/ Full Directory'
                        ],
                        'text'   => 'View Type',
                        'size'   => 'col-12',
                        'hint'   => 'Independent Search Form (Homepage Widget) - Search form only, intended to be used on a homepage or sidebar. Typically only 4 to 6 filters are used which will then direct users to a full directory view.<br>
Titles Only - Simple listing view with only the provider name<br>
Simple Directory - Limited directory view with profile listings (logo, name, and short description)<br>
Full Directory - Directory view with profile listings (logo, name, short description, and full contact information)<br>
Search w/ Full Directory - Directory view with search filters on the left and profile listings on the right (logo, name, short description, and full contact information)',
                    ],
                    'language'     => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'English', 'spanish' => 'Spanish'],
                        'text'   => 'Language',
                        'size'   => 'col-12',
                    ],
                    'target_page'  => [
                        'type'        => 'text',
                        'value'       => '',
                        'text'        => 'Independent Search Form - Results Page',
                        'size'        => 'col-12',
                        'hint'        => 'When View Type is "Independent Search Form", this URL is where users should be taken to view results.',
                        'conditional' => [
                            [
                                'field'    => $this->MachineName() . '_layout',
                                'value'    => 'search',
                                'operator' => '=='
                            ]
                        ],
                    ],
                    'default_view' => [
                        'type'        => 'checkbox',
                        'value'       => '',
                        'values'      => ['1' => 'Yes'],
                        'text'        => 'Use as Default Search Results View',
                        'size'        => 'col-12',
                        'hint'        => 'When searching from the Independent Search Form, set this view as the default view for displaying results if no "Independent Search Form - Results Page" is provided.',
                        'conditional' => [
                            [
                                'field'    => $this->MachineName() . '_layout',
                                'value'    => 'full-search',
                                'operator' => '=='
                            ]
                        ],
                    ],
                    'admin_note'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Note',
                        'size'  => 'col-12',
                        'hint'  => 'Add a note to the listing columns in the admin.',

                    ],
                    'header_code'  => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Header Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the header of the resource page.',
                    ],
                    'footer_code'  => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Footer Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the footer of the resource page.',
                    ],

                    'hide_optional_logo'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Logo - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_optional_description'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Description - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_optional_contact'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Contact Information - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_optional_dropdown'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Sort Dropdown - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_optional_distance'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Distance - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                    'hide_optional_services'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Provider Services - Hide on Provider Listing',
                        'size'   => 'col-12 col-lg-4 col-md-6',
                        'hint'   => '',
                    ],
                ]
            ],
            [
                'type'   => 'panel',
                'id'     => 'search-section',
                'header' => 'Search Filters',

                'sortable' => true,
                'inputs'   => [
                                  'zip_city_state'     => [
                                      'type'         => 'filter',
                                      'value'        => '',
                                      'name_val'     => '',
                                      'text'         => ' Zip Code or City, State',
                                      'text_spanish' => '',
                                      'size'         => 'col-12',
                                      'hint'         => '',
                                      'order'        => 0,
                                      'settings'     => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'distance'           => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' Distance (in miles)',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => 'Note: this field is based off of distance from the "Zip Code or City, State" or a combination of "City" "State" and "County" fields. If this field has a default value at least one of the others should be enabled and required.',
                                      'order'    => 0,
                                      'options'  => [
                                          '10'  => '10 mile radius',
                                          '25'  => '25 mile radius',
                                          '50'  => '50 mile radius',
                                          '100' => '100 mile radius'
                                      ],
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'state'              => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' State',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'options'  => ResourceNavigatorUtilityBase::StateArray(),
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'city'               => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' City',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'county'             => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' County (sublist from state)',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'keyword'            => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' Keyword',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'organization_name'  => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' Organization Name',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ],
                                  'area_of_assistance' => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' Area of Assistance',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      'options'  => ServiceCache::ServiceCategoryArray(),
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ],
                                  ],
                                  'specific_need'      => [
                                      'type'     => 'filter',
                                      'value'    => '',
                                      'name_val' => '',
                                      'text'     => ' Specific Need',
                                      'text_spanish' => '',
                                      'size'     => 'col-12',
                                      'hint'     => '',
                                      'order'    => 0,
                                      //'options'  => ResourceNavigatorUtilityBase::serviceArray(),
                                      'settings' => [
                                          'initalize' => [
                                              'text' => 'Set Default Value'
                                          ],
                                          'required'  => [
                                              'text' => 'Required'
                                          ],
                                          'enabled'   => [
                                              'text'    => 'Enabled',
                                              'default' => true
                                          ]
                                      ]
                                  ]
                              ] + $filters
            ],
            [
                'type'   => 'panel',
                'id'     => 'form-section',
                'header' => 'Additional Settings',
                'inputs' => [
                    'map_enabled'        => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Enable Map View',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'map_default'        => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Default to Map View',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'title_for_sponsors' => [
                        'type'    => 'text',
                        'value'   => '',
                        'text'    => 'Title for Sponsors',
                        'default' => 'Sponsor',
                        'size'    => 'col-12',
                        'hint'    => 'Default: ‘Sponsor’',
                    ],
                    'page_title'         => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Page Title',
                        'size'  => 'col-12',
                        'hint'  => 'Example: ‘Resource Navigator’',
                    ],
                    'sidebar_title'      => [
                        'type'    => 'text',
                        'value'   => '',
                        'text'    => 'Sidebar Title',
                        'default' => 'Narrow Your Search',
                        'size'    => 'col-12',
                        'hint'    => 'Default: ‘Narrow Your Search’',
                    ],
                    'search_button_text' => [
                        'type'    => 'text',
                        'value'   => '',
                        'text'    => 'Search Button Text',
                        'default' => 'Filter Resources',
                        'size'    => 'col-12',
                        'hint'    => 'Default: ‘Filter Resources’',
                    ],
                    'pagination'         => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'Use Paging', 'limit' => 'Use Limit', 'no_limit' => 'No Limit or Paging'],
                        'text'   => 'Paging',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'paging_limit'       => [
                        'type'    => 'number',
                        'value'   => '',
                        'text'    => 'Resources per Page or Limit Number',
                        'default' => '10',
                        'size'    => 'col-12',
                        'hint'    => '',
                    ],
                    'sort_by'            => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'Distance (closest first)', 'partner-asc' => 'Partner name (A-Z)', 'partner-desc' => 'Partner name (Z-A)'],
                        'text'   => 'Sort by',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'no_logo_display'    => [
                        'type'   => 'select',
                        'value'  => '',
                        'values' => ['' => 'Do Nothing', 'my-logo' => 'Use My Logo (Provided Below)', 'no-logo-image' => 'Use the No Logo Image Provided'],
                        'text'   => 'How to Handle Partners Without Logos',
                        'size'   => 'col-12',
                        'hint'   => '',
                    ],
                    'my_logo'            => [
                        'type'  => 'image',
                        'value' => '',
                        'text'  => 'My Logo',
                        'size'  => 'col-12 col-my-logo',
                        'hint'  => 'Used to hold the place of a missing partner logo',
                    ],
                    'log_origin'         => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Location for Log',
                        'size'  => 'col-12',
                        'hint'  => 'When viewing the search log, searches using this form will be identified by this label',
                    ],
                    'partners_include'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Partners Must Have This Tag',
                        'size'  => 'col-12',
                        'hint'  => '',
                    ],
                    'partners_exclude'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Partners Cannot Have This Tag',
                        'size'  => 'col-12',
                        'hint'  => '',
                    ],

                ]
            ],
            [
                'type'   => 'panel',
                'id'     => 'form-section',
                'header' => 'Detail and Update Page Settings',
                'inputs' => [
                    'magic_enabled'    => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Enable Magic Link',
                        'size'   => 'col-12',
                        'hint'   => 'Display the option for Resource Partners to send a one-time link to their email address on file to update their profile.',
                    ],
                    'feedback_enabled' => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Enable Partner Feedback Form',
                        'size'   => 'col-12',
                        'hint'   => 'Display the option allowing website visitors to submit feedback regarding the Partner’s profile on the Partner detail page.',
                    ],
                    'contact_enabled'  => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Enable Partner Contact Form',
                        'size'   => 'col-12',
                        'hint'   => 'Display the option allowing website visitors to submit a request to connect with a Partner through the Partner detail page.',
                    ],
                    'partner_update'   => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Partner Update Page',
                        'size'  => 'col-12',
                        'hint'  => 'The URL to send Resource Partners to through their Magic Link.',
                    ],
                    'hide_email'       => [
                        'type'   => 'checkbox',
                        'value'  => '',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Hide Partner’s Email Address',
                        'size'   => 'col-12',
                        'hint'   => 'When checked, the Resource Partner’s email address will not be displayed on their profile. Website visitors will need to submit a request to contact the organization through the Resource Navigator system (see Enable Partner Contact Form). SourceLink recommends checking this option and enabling the Partner Contact Form to best report on online referrals and avoid unwanted direct outreach to Partners.',
                    ],


                ]
            ]
        ];
    }

    public static function getfilterKey($key): ?string
    {
        $arr = [
            'zip_city_state'     => 'zipcode',
            'distance'           => 'distance',
            'state'              => 'state',
            'city'               => 'city',
            'county'             => 'county',
            'keyword'            => 'keyword',
            'organization_name'  => 'providerName',
            'area_of_assistance' => 'serviceCategoryIds',
            'specific_need'      => 'serviceIds',
        ];
        if (strpos($key, 'demo_category') !== false) {

            $key_arr = explode('_', $key);
            $key_num = array_pop($key_arr);

            if ($key_num != null) {

                return 'filter' . $key_num . 'Ids';
            }
        } elseif ( ! empty($arr[$key])) {
            return $arr[$key];
        }

        return null;
    }

    /**
     * @param array $attributes
     * @param array $data
     *
     * @return string
     */
    public static function Render(array $attributes = [], array $data = []): string
    {


        //Return nothing if no id provided
        if (empty($attributes['id'])) {
            return '';
        }

        //Get an instance of this post object class
        $staticClass = get_called_class();
        $obj         = new $staticClass();

        if (empty(get_option('slrn_api_key'))) {
            return '';
        }

        if (empty($_COOKIE['slrn_session'])) {
            $login       = new Login(get_option('slrn_api_key'));
            $loginResult = $login->DoLogin();
            if ((isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)) {
                return '';
            }
        }

        $uid                 = uniqid();
        $data['callback_id'] = 'MapInit' . $uid;
        $data['map_id']      = 'Map' . $uid;
        //get all data for this post
        $the_post = get_post($attributes['id']);

        if ($the_post == null) {
            return '<p><strong>This Navigator View is not available.</strong></p>';
        }

        if ($the_post->post_status != "publish") {
            if (ResourceNavigatorUtilityBase::CurrentUserHasRole('administrator')) {
                return '<p><strong>This Navigator View is not available. Please create or modify the page to use a published Navigator View.</strong></p>';
            } else {
                return '<p><strong>This Navigator View is not available.</strong></p>';
            }
        }

        $data['post'] = ResourceNavigatorUtilityBase::GetPostProperties($the_post, $staticClass);

        $data['no_logo'] = plugin_dir_url(__DIR__) . '../assets/images/placeholder.png';
        if (isset($attributes['chromeless'])) {
            $data['chromeless'] = $attributes['chromeless'];
        }
        //Determin layout file to use
        $alternateLayout = $attributes['layout'] ?? $data['post']['meta']['layout'] ?? '';

        $twig = ResourceNavigatorUtilityBase::FindVariant($obj->MachineName(), 'view', 'twig', $alternateLayout);

        $providers = new Provider(get_option('slrn_api_key'));

        //Spanish Filter Titles
        $ResourceViewPost = new ResourceViewPost();
        foreach ($data['post']['meta']['filters'] as &$filter) {
            if ($data['post']['meta']['language'] == "spanish" && !empty($ResourceViewPost->getInputs()[1]['inputs'][$filter['name']])) {
                $filter['title'] = $ResourceViewPost->getInputs()[1]['inputs'][$filter['name']]['text_spanish'];
            }
        }

        //on submit
        if (isset($_GET['slrn_submit'])) {
            $args = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
            if ( ! empty($args['sort_by'])) {
                $data['sorting'] = $args['sort_by'];

                unset($args['sort_by']);
            }
            if ( ! empty($args['user_sorted'])) {
                $data['user_sorted'] = $args['user_sorted'];

                unset($args['user_sorted']);
            }
            unset($args['slrn_submit']);
            //set form filters to match submitted filters
            foreach ($data['post']['meta']['filters'] as &$filter) {
                $filter_key = ResourceViewPost::getfilterKey($filter['name']);
                if (strpos($filter['name'], 'demo_category') !== false) {
                    $key_arr = explode('_', $filter['name']);
                    $key_num = array_pop($key_arr);
                    if ($key_num != null) {
                        $filter['default'] = $args['filter' . $key_num . 'Ids'];
                    }
                } elseif ( ! empty($filter_key) && isset($args[$filter_key])) {
                    $filter['default'] = $args[$filter_key];
                }
            }
            $args['liveSearch'] = true;
        } else {
            $args = [];
            //build default filters
            foreach ($data['post']['meta']['filters'] as &$filter) {
                $filter_key = ResourceViewPost::getfilterKey($filter['name']);
                if ($filter['settings']['initalize'] == 'initalize') {
                    if (strpos($filter['name'], 'demo_category') !== false) {
                        $key_arr = explode('_', $filter['name']);
                        $key_num = array_pop($key_arr);

                        if ($key_num != null) {
                            $args['filter' . $key_num . 'Ids'] = $filter['default'];
                        }
                    } else {
                        $args[$filter_key] = $filter['default'];
                    }
                } else {
                    $filter['default'] = "";
                }


            }
            $args['liveSearch'] = false;
        }

        $args['tagIdsInclude']     = $data['post']['meta']['partners_include'];
        $args['tagIdsExclude']     = $data['post']['meta']['partners_exclude'];
        $args['searchLogLocation'] = $data['post']['meta']['log_origin'];
        //$args['searchUrl'] = ResourceNavigatorUtilityBase::getCurrentUrl();
        $args['userIp'] = ResourceNavigatorUtilityBase::GetIP();


        $result          = ApiBase::ProcessResult($providers->GetProviders($args)["body"]);
        $has_specialties = false;
        $has_distance    = false;
        if ( ! empty($result)) {
            if ($result["isError"] == true) {
                $data['post']['results']['error'] = ["code" => $result["statusCode"], "message" => "There has been a communications error with the API, please try again soon."];
            } else {
                foreach ($result["result"] as $item) {
                    if ($item['Active'] == true) {
                        if ( ! empty($item['Specialities'])) {
                            $has_specialties = true;
                        }
                        if ($item['Distance'] != 9999) {
                            $has_distance = true;
                        }
                        $data['post']['results']['resources'][] = [
                            'id'              => $item['ProviderID'],
                            'logo'            => $item['LogoUrl'],
                            'title'           => $item['ProviderName'],
                            'description'     => $item['ShortDescription'],
                            'contact'         => [
                                'name'      => $item['ContactFirstName'] . ' ' . $item['ContactLastName'],
                                'address_1' => $item['Address'],
                                'address_2' => trim($item['Address2']),
                                'city'      => $item['City'],
                                'state'     => $item['State'],
                                'zip'       => $item['Zip'],
                                'email'     => $item['Email'],
                                'phone'     => $item['Phone'] . (! empty($item['PhoneExt']) ? ' Ext: ' . $item['PhoneExt'] : ''),
                                'website'   => $item['URL'],
                            ],
                            'lat'             => $item['Latitude'],
                            'long'            => $item['Longitude'],
                            'isSponsor'       => $item['IsSponsor'],
                            'specialityCount' => $item['SpecialityCount'],
                            'specialities'    => $item['Specialities'],
                            'distance'        => round($item['Distance'], 2)
                        ];
                    }
                }
            }
        }
        $data['hide_distance'] = false;
        if (empty($data['sorting']) || (empty($data['user_sorted']) && $data['sorting'] != $data['post']['meta']['sort_by'])) {
            $data['sorting'] = $data['post']['meta']['sort_by'];
        }
        if ( ! $has_distance) {
            $data['hide_distance'] = true;
        }
        if (($data['sorting'] == "distance" || $data['sorting'] == "") && ! $has_distance) {
            $data['sorting'] = "partner-asc";
        }
        if($data['post']['meta']['language'] == "spanish"){
            setlocale(LC_ALL, 'es_ES');
        }
        if ( ! empty($data['post']['results']['resources'])) {
            switch ($data['sorting']) {
                case 'distance':
                case '':
                    usort($data['post']['results']['resources'], function ($a, $b) use ($has_specialties) {
                        if ($has_specialties) {
                            return ($a['specialityCount'] <=> $b['specialityCount']) * -1000 + ($a['distance'] <=> $b['distance']);
                        } else {
                            return ($a['distance'] <=> $b['distance']);
                        }
                    });
                    break;
                case 'partner-asc':
                    if($data['post']['meta']['language'] == "spanish") {
                        array_multisort(array_column($data['post']['results']['resources'], 'key'), SORT_ASC, SORT_LOCALE_STRING, $data['post']['results']['resources']);
                    } else {
                        usort($data['post']['results']['resources'], function ($a, $b) use ($has_specialties) {
                            if ($has_specialties) {
                                return ($a['specialityCount'] <=> $b['specialityCount']) * -1000 + (strtolower($a['title']) <=> strtolower($b['title']));
                            } else {
                                return (strtolower($a['title']) <=> strtolower($b['title']));
                            }
                        });
                    }
                    break;
                case 'partner-desc':
                    if($data['post']['meta']['language'] == "spanish") {
                        array_multisort(array_column($data['post']['results']['resources'], 'key'), SORT_DESC, SORT_LOCALE_STRING, $data['post']['results']['resources']);
                    }else{
                        usort($data['post']['results']['resources'], function ($a, $b) use ($has_specialties) {
                            if ($has_specialties) {
                                return ($a['specialityCount'] <=> $b['specialityCount']) * -1000 + (strtolower($b['title']) <=> strtolower($a['title']));

                            } else {
                                return (strtolower($b['title']) <=> strtolower($a['title']));
                            }
                        });
                    }
                    break;
                default:
                    break;
            }
        }
        if($data['post']['meta']['language'] == "spanish" && $has_specialties) {
            $temp =[];
            foreach ($data['post']['results']['resources'] as $index=>$resource){
                if($resource['specialityCount'] > 0){
                    $temp[] = $resource;
                    unset($data['post']['results']['resources']);
                }
            }
            foreach ($temp as $index=>$resource){
                array_unshift($data['post']['results']['resources'], $resource);
            }
        }

        //fetch demos
        $saved_demos = get_option('slrn_cached_fields');
        if ( ! empty($saved_demos)) {
            $demoCats = $saved_demos;
        } else {
            $demoCats = DemographicCache::FilterFullArray();
        }


        if (isset($demoCats)) {
            if (is_array($demoCats)) {
                foreach ($demoCats as $cat) {
                    $tmp = [];
                    foreach ($cat['demographicValues'] as $value) {
                        if ($value['listOrder'] != null) {
                            $tmp[$value['listOrder']] = [
                                'label' => $data['post']['meta']['language'] == "spanish" ? $value['demographicSpanish'] : $value['demographic'],
                                'id'    => $value['demographicValueId'],
                            ];
                        } else {
                            $tmp[] = [
                                'label' => $data['post']['meta']['language'] == "spanish" ? $value['demographicSpanish'] : $value['demographic'],
                                'id'    => $value['demographicValueId'],
                            ];
                        }
                    }
                    ksort($tmp);
                    $data['demosCats'][$cat['demographicCategoryId']] = $tmp;
                }
            }
        }

//fetch services
//        $saved_services = get_option('slrn_cached_services');
//        if(!empty($saved_services)){
//            $data['services'] = $saved_services;
//        } else {
//            $data['services'] = ServiceCache::ServiceFullArray();
//        }
        $serviceCatsObj = new ServiceCategories();
        $serviceObj     = new Service();

        $serviceCatsRaw = $serviceCatsObj->GetServiceCategories();
        if (isset($args['serviceCategoryIds'])) {
            $serviceRaw = $serviceObj->GetServicesByCategoryId((int)$args['serviceCategoryIds']);
            $results3   = ApiBase::ProcessResult($serviceRaw['body']);
            $services   = $results3['result'];
            if (isset($services)) {
                if (is_array($services)) {
                    foreach ($services as $service) {
                        $tmp2['serviceByCategories'][] = [
                            'serviceLabel' => $data['post']['meta']['language'] == "spanish" ? $service['ServiceLabelSpanish'] : $service['ServiceLabel'],
                            'serviceId'    => $service['ServiceId'],
                        ];
                    }
                }
                if (isset($tmp2)) {
                    $data['service_items'] = $tmp2['serviceByCategories'];
                }
            }
        }

        $serviceCatList = ApiBase::ProcessResult($serviceCatsRaw['body']);

        if (is_array($serviceCatList)) {
            $serviceCats = $serviceCatList['result'];
            if ( ! empty($serviceCats[0]['serviceCategoryAndServices'])) {
                foreach ($serviceCats[0]['serviceCategoryAndServices'] as $serviceCat) {
                    $tmp2 = ['serviceCategoryId' => $serviceCat['ServiceCategoryId'] ?? 0, 'userOrgId' => $serviceCat['UserOrgId'] ?? 0, 'serviceCategoryLabel' => ($data['post']['meta']['language'] == "spanish" ? $serviceCat['ServiceCategoryLabelSpanish'] : $serviceCat['ServiceCategoryLabel']) ?? null,];


                    $data['services'][] = $tmp2;
                }
            }
        }
        $data['args'] = $args;
//render something... or nothing
        $scripts = [];
        if (empty($data['post']['meta']['pagiong'])) {
            $scripts['slrn-pagination'] = [
                'type'   => 'script',
                'src'    => ResourceNavigatorUtilityBase::GetAsset('js/frontend/pagination.js'),
                'deps'   => ['jquery'],
                'footer' => true,
                'ver'    => ResourceNavigatorBase::GetCacheVersion(),
            ];
        }

        if ( ! empty($data['post']['meta']['map_enabled'] || ! empty($data['post']['meta']['map_default']))) {
            $scripts['slrn-map-view']             = [
                'type'   => 'script',
                'src'    => ResourceNavigatorUtilityBase::GetAsset('js/frontend/mapview.js'),
                'deps'   => ['jquery'],
                'footer' => true,
                'ver'    => ResourceNavigatorBase::GetCacheVersion(),
            ];
            $scripts['slrn-google-maps-polyfill'] = [
                'type'   => 'script',
                'src'    => '//polyfill.io/v3/polyfill.min.js?features=default',
                'deps'   => [],
                'footer' => true,
                'ver'    => ResourceNavigatorBase::GetCacheVersion(),
            ];
            $scripts['slrn-google-maps']          = [
                'type'   => 'script',
                'src'    => '//maps.googleapis.com/maps/api/js?key=' . get_option('slrn_gm_api_key') . '&callback=loadMaps&libraries=&v=weekly&language=' . ($data['post']['meta']['language'] == 'spanish' ? 'es' : 'en'),
                'deps'   => ['slrn-google-maps-polyfill', 'slrn-map-view'],
                'footer' => true,
                'ver'    => ResourceNavigatorBase::GetCacheVersion(),
            ];
            ResourceNavigatorUtilityBase::EnqueueMaps($data['map_id'], $data['callback_id']);
        }


        ResourceNavigatorUtilityBase::EnqueueAdditional($scripts);

        return ! empty($twig) ? TwigManager::Twig()->Render($twig, $data) : '';
    }
}

