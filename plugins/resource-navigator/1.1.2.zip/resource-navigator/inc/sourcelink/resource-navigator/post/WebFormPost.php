<?php

namespace Sourcelink\ResourceNavigator\Post;

use Sourcelink\ResourceNavigator\API\Cache\DemographicCache;
use Sourcelink\ResourceNavigator\API\Cache\IntakeCache;
use Sourcelink\ResourceNavigator\API\Cache\ServiceCache;
use Sourcelink\ResourceNavigator\API\Intake;
use Sourcelink\ResourceNavigator\API\Login;
use Sourcelink\ResourceNavigator\API\Model\FundingCapital;
use Sourcelink\ResourceNavigator\API\Model\IntakeForm;
use Sourcelink\ResourceNavigator\API\Provider;
use Sourcelink\ResourceNavigator\ApiBase;
use Sourcelink\ResourceNavigator\Plugin\ResourceNavigatorBase;
use Sourcelink\ResourceNavigator\PostBase as PostBase;
use Sourcelink\ResourceNavigator\ResourceNavigatorUtilityBase;
use Sourcelink\ResourceNavigator\Settings\ReferralRegions;
use Sourcelink\ResourceNavigator\TwigManager;
use Sourcelink\ResourceNavigator\Utility\ResponseData;

class WebFormPost extends PostBase
{
    private static function Redirect($url)
    {
        echo '<script>location.href = "' . $url . '";</script>';
        die();
    }

    public static function posts_columns($columns)
    {
        $columns['shortcode'] = 'Shortcode';
        $columns['note']      = 'Note';

        return $columns;
    }

    public static function posts_column_data($column, $post_id)
    {
        if ($column == 'shortcode') {
            echo '<pre>[web_form id="' . $post_id . '"]</pre>';
        }

        if ($column == 'note') {
            $form      = get_post_meta($post_id, 'web_form_form', true);
            $intakeObj = new IntakeCache();
            $forms     = $intakeObj->GetCacheForEndpoint("GetWebForms");

            $the_form =  WebFormPost::FindForm($forms,intval($form));
            //$the_form  = $forms[intval($form)];
            echo $the_form['Description'];

        }
    }

    /**
     * Edit the default args for resource-navigator objects to add excerpt and change visibility.
     *
     * @param array $overrides
     *
     * @return array $overrides
     */
    public function GetArgs(array $overrides = array()): array
    {
        $overrides = array_merge($overrides, array(
            'supports'           => array('title', 'page_attributes'),
            'show_in_menu'       => 'admin.php?page=resource_navigator',
            'publicly_queryable' => false

        ));

        return parent::GetArgs($overrides);
    }

    /**
     * Name for the admin panel.
     *
     * @return string
     */
    public function Name(): string
    {
        return 'Web Form';
    }

    /**
     * Plural Name for the admin panel.
     *
     * @return string
     */
    public function PluralName(): string
    {
        return 'Web Forms';
    }

    /**
     * Name in WordPress DB for object.
     *
     * @return string
     */
    public function MachineName(): string
    {
        return 'web_form';
    }

    /**
     * Array used to build meta field inputs.
     *
     * @return array
     */

    public static function FindForm($forms,  $value):?array
    {
        foreach($forms as $key => $form)
        {
            if ( $form['IntakeSettingsId'] === intval($value) )
                return $form;
        }
        return null;
    }

    public function GetInputs(): array
    {
        global $post;


        $intakeObj     = new IntakeCache();
        $forms         = $intakeObj->GetCacheForEndpoint("GetWebForms");
        $contact_form               = WebFormPost::GetProviderContactFormID();
        $feedback_form               = WebFormPost::GetProviderFeedbackFormID();
        $form_list     = [];
        $old_form = "";
        if(!empty($post->ID)){
            $old_form= $this->getDBValue($post->ID, $this->prefix('form'));
        }
        $field_list = WebFormPost::GetFieldsForSort($post->ID);
        $using_old_form = true;
        foreach ($forms as $index => $form) {
            if($form['IntakeSettingsId'] == $old_form){
                $using_old_form = false;
            }
            //$form_list[$index] = $form['IntakeTitle'];
            if($form['IntakeSettingsId'] != $contact_form && $form['IntakeSettingsId'] != $feedback_form){
                $form_list[$form['IntakeSettingsId']] = $form['IntakeTitle'];
            }
        }
        if($using_old_form && $old_form != ""){
            $this->saveDBValue($post->ID, $this->prefix('form'), $forms[$old_form]['IntakeSettingsId']);
            header("Refresh:0");
            die;
        }
        $questions  = WebFormPost::GetQuestions($post->ID);



        $providers  = WebFormPost::GetProviders();
        $my_regions = get_option('referral_regions_regions');


        $rtn   = [
            [
                'type'      => 'panel',
                'id'        => 'general-section',
                'shortcode' => $this->MachineName(),
                'embed'     => true,
                'header'    => 'General Settings',
                'inputs'    => [

                    'form' => [
                        'type'   => 'select',
                        'values' => ['' => '-- Select --'] + $form_list,
                        'text'   => 'Web Form',
                        'size'   => 'col-12 ',
                        'hint'   => 'Form To Use from the API',
                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '!=',
                            ]
                        ],
                    ],
                    'instruction'=>[
                        'type'   => 'display-text',
                        'values' => ['' => '-- Select --'] + $form_list,
                        'text'   => 'Changing the Web Form has been disabled while the Referral & Response Logic is enabled',
                        'size'   => 'col-12 ',

                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '==',
                            ]
                        ],
                    ],

                    'header_code'   => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Header Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the header of the webform page.',
                    ],
                    'footer_code'   => [
                        'type'  => 'textarea',
                        'value' => '',
                        'text'  => 'Footer Code',
                        'size'  => 'col-12',
                        'hint'  => 'Script to embed in the footer of the webform page.',
                    ],

                ]
            ],
            [
                'type'   => 'repeater',
                'id'     => 'extra_fields',
                'prefix' => 'wfef',
                'header' => 'Additional Fields',
                'inputs' => [
                    'title'    => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Field Label',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => '',
                    ],
                    'type'     => [
                        'type'   => 'select',
                        'values' => ['' => '-- Select --', 'text' => 'Text Box', 'textarea' => 'Large Text Box', 'select' => 'Dropdown List', 'checkbox' => 'Checkbox List', 'radio' => 'Radio List',],
                        'text'   => 'Field Type',
                        'size'   => 'col-12  col-md-6',
                        'hint'   => 'Select a field type',
                    ],
                    'required' => [
                        'type'   => 'select',
                        'values' => ['' => 'No', '1' => 'Yes'],
                        'text'   => 'Required',
                        'size'   => 'col-12 col-md-6',
                        'hint'   => '',
                    ],
                    'notes'    => [
                        'type'  => 'text',
                        'value' => '',
                        'text'  => 'Field Note',
                        'size'  => 'col-12 col-md-6',
                        'hint'  => '',
                    ],
                    'options'  => [
                        'type'      => 'textarea',
                        'value'     => '',
                        'text'      => 'Options',
                        'size'      => 'col-12 col',
                        'hint'      => 'For dropdown, radio and checkbox lists. Separate items with a new line.',
                        'condition' => [['type' => 'select'], ['type' => 'checkbox'], ['type' => 'radio']] //conditions on which this field is visible [field => value]. if true show this.
                    ],

                ]
            ],
            [
                'type'   => 'panel',
                'id'     => 'fi',
                'header' => 'Form Inputs',

                'sortable' => true,
                'inputs'   => $field_list
            ],
            [
                'type'   => 'panel',
                'id'     => 'referral-section',
                'header' => 'Referral & Response Settings',
                'inputs' => [

                    'enable_rr' => [
                        'type'   => 'checkbox',
                        'values' => ['1' => 'Yes'],
                        'text'   => 'Add Referral & Response Logic?',
                        'size'   => 'col-12 ',
                        'hint'   => 'Referral & Response Logic is an optional function for a web form in which a user is presented with information dependent on their answers in this web form.',
                    ],
                    'rr_title'  => [
                        'type'        => 'text',
                        'value'       => '',
                        'text'        => 'Referral & Response Title',
                        'size'        => 'col-12',
                        'hint'        => 'give a title for the responses',
                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '==',
                            ]
                        ],
                    ],
                    'rr_text'   => [
                        'type'        => 'textarea',
                        'value'       => '',
                        'text'        => 'Referral & Response intro text',
                        'size'        => 'col-12',
                        'wysiwyg'     => true,
                        'hint'        => 'inform the user what these responses are for',
                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '==',
                            ]
                        ],
                    ],
                    'rr_provider_title'  => [
                        'type'        => 'text',
                        'value'       => '',
                        'text'        => 'Referral & Response Provider Title',
                        'size'        => 'col-12',
                        'hint'        => 'give a title for the providers listed',
                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '==',
                            ]
                        ],
                    ],
                    'rr_provider_text'   => [
                        'type'        => 'textarea',
                        'value'       => '',
                        'text'        => 'Referral & Response Provider intro text',
                        'size'        => 'col-12',
                        'wysiwyg'     => true,
                        'hint'        => 'Displays information to introduce the providers after the text responses.',
                        'conditional' => [
                            [
                                'field'    => 'web_form_enable_rr[]',
                                'value'    => '1',
                                'checkbox' => true,
                                'operator' => '==',
                            ]
                        ],
                    ],


                ]

            ],
        ];
        $rtn[] = WebFormPost::GetRegionRepeater([
            'id'        => 'referral-options-0',
            'prefix'    => 'rop_0',
            'header'    => "Default Referral Responses",
            'questions' => $questions ?? [],
            'providers' => $providers ?? []
        ]);
        //add a section for each region in the settings
        foreach ($my_regions as $index => $region) {
            $rtn[] = WebFormPost::GetRegionRepeater([
                'id'        => 'referral-options-' . ($index + 1),
                'prefix'    => 'rop_' . ($index + 1),
                'header'    => $region['title'] . " Referral Responses",
                'questions' => $questions ?? [],
                'providers' => $providers ?? []
            ]);
        }

        return $rtn;
    }

    public static function GetRegionRepeater($atts)
    {
        return [
            'type'        => 'repeater',
            'id'          => $atts['id'],
            'prefix'      => $atts['prefix'],
            'conditional' => [
                [
                    'field'    => 'web_form_enable_rr[]',
                    'value'    => '1',
                    'checkbox' => true,
                    'operator' => '==',
                ]
            ],
            'header'      => $atts['header'],
            'inputs'      => [
                'title'       => [
                    'type'  => 'text',
                    'value' => '',
                    'text'  => 'Title',
                    'size'  => 'col-12 ',
                    'hint'  => 'Title of the response.',
                ],
                'condition_1' => [
                    'type'   => 'api_question',
                    'values' => $atts['questions'],
                    'text'   => 'Question 1',
                    'size'   => 'col-12 col-md-6',
                    'hint'   => 'optional',
                ],
                'condition_2' => [
                    'type'   => 'api_question',
                    'values' => $atts['questions'],
                    'text'   => 'Question 2',
                    'size'   => 'col-12 col-md-6',
                    'hint'   => 'optional',
                ],
                'provider'    => [
                    'type'     => 'select',
                    'values'   => $atts['providers'],
                    'text'     => 'Provider(s)',
                    'size'     => 'col-12 col-md-6',
                    'hint'     => 'Provider(s) to attach to the response. Add as many as you need from the available ',
                    'multiple' => true
                ],
                'text'        => [
                    'type'    => 'textarea',
                    'value'   => '',
                    'wysiwyg' => true,
                    'text'    => 'Text',
                    'size'    => 'col-12 col-md-6',
                    'hint'    => 'Text to attach to the response.',
                ],
            ]
        ];
    }

    /**
     * RenderProvider - Call Render with required info for Contact form for provider
     *
     * @param int $provider_id
     *
     * @return string
     */
    public static function RenderProviderFeedback(int $provider_id = 0, $args = []): string
    {
        return WebFormPost::Render(["is_feedback" => true, 'provider_id' => $provider_id], $args);
    }

    /**
     * RenderProvider - Call Render with required info for Contact form for provider
     *
     * @param int $provider_id
     *
     * @return string
     */
    public static function RenderProviderContact(int $provider_id = 0, $args = []): string
    {
        return WebFormPost::Render(["is_provider" => true, 'provider_id' => $provider_id], $args);
    }

    public static function GetProviderContactFormID()
    {
        $intakeObj = new IntakeCache();
        $the_form  = $intakeObj->GetCacheForEndpoint("GetProviderContactForm");

        return $the_form['IntakeSettingsId'];
    }

    public static function GetProviderFeedbackFormID()
    {

        $intakeObj = new IntakeCache();
        $the_form  = $intakeObj->GetCacheForEndpoint("GetProviderFeedbackForm");

        return $the_form['IntakeSettingsId'];
    }

    public static function SortFields($fields, $meta)
    {
        $nosort = false;
        foreach ($fields as &$field) {
            if (isset($meta['web_form_' . $field['id'] . '_order'])) {
                $field['order'] = intval($meta['web_form_' . $field['id'] . '_order'][0]);
            } else {
                $nosort = true;
            }
            if ( ! empty(trim($meta['web_form_' . $field['id']][0]))) {
                $field['label'] = $meta['web_form_' . $field['id']][0];
            }
        }
        if ( ! $nosort) {
            usort($fields, function ($a, $b) {
                if ( ! isset($a['order']) || ! isset($b['order'])) {
                    return 0;
                }

                return $a['order'] <=> $b['order'];
            });
        }

        return $fields;
    }

    /**
     * render - Gather data and determine what to display
     *
     * @param array $attributes
     * @param array $data
     *
     * @return string
     */
    public static function Render(array $attributes = [], array $data = []): string
    {

        //Return nothing if no id provided
        if (empty($attributes['id']) && empty($attributes['is_feedback']) && empty($attributes['is_provider'])) {
            return '';
        }

        //Get an instance of this post object class
        $staticClass = get_called_class();
        $obj         = new $staticClass();

        if ( ! empty($attributes['id'])) {
            $the_post = get_post($attributes['id']);
            if (($the_post === null || $the_post->post_type != "web_form") && empty($attributes['is_feedback']) && empty($attributes['is_provider'])) {
                return '';
            }
        }
        $intakeObj    = new IntakeCache();
        $all_meta     = [];
        $extra_fields = [];
        if ( ! empty($attributes['id'])) {
            $forms        = $intakeObj->GetCacheForEndpoint("GetWebForms");
            $all_meta     = get_post_meta($attributes['id']);
            $data['post'] = ResourceNavigatorUtilityBase::GetPostProperties($the_post, $staticClass);
            $extra_fields = $data['post']['meta_lists']['extra_fields'];
            $the_form     = WebFormPost::FindForm($forms,$data['post']['meta']['form']); //$forms[intval($data['post']['meta']['form'])];

        } elseif ( ! empty($attributes['is_feedback'])) {
            $the_form               = $intakeObj->GetCacheForEndpoint("GetProviderFeedbackForm");
            $the_form['isFeedback'] = true;
            $the_form['providerId'] = $attributes['provider_id'];
            $the_form               = WebFormPost::ParseTokens($the_form, $data);
        } elseif ( ! empty($attributes['is_provider'])) {
            $the_form               = $intakeObj->GetCacheForEndpoint("GetProviderContactForm");
            $the_form['isContact']  = true;
            $the_form['providerId'] = $attributes['provider_id'];
            $the_form               = WebFormPost::ParseTokens($the_form, $data);
        }

        $data['grc_site_key'] = get_option('slrn_grc_api_key');


        $data['fields'] = WebFormPost::GetAllFields($the_form, $extra_fields);
        foreach($data['fields'] as &$echVal) {

            $newVal = get_post_meta($attributes['id'], 'web_form_'.$echVal['id'].'_notes', true);

            if(!empty($newVal)) {
                $echVal['hint'] = $newVal;
            }
        }

        if ( ! empty($all_meta)) {
            $data['fields'] = WebFormPost::SortFields($data['fields'], $all_meta);
        }


        $data['form']["UserOrgId"]                            = $the_form['UserOrgId'];
        $data['form']['IntakeTitle']                          = $the_form['IntakeTitle'];
        $data['form']['Description']                          = $the_form['Description'];
        $data['form']["IntakeSettingsId"]                     = $the_form['IntakeSettingsId'];
        $data['form']["HeaderText"]                           = $the_form['HeaderText'];
        $data['form']["SubmitText"]                           = $the_form['SubmitText'];
        $data['form']["IntroText"]                            = $the_form['IntroText'];
        $data['form']["OutroText"]                            = $the_form['OutroText'];
        $data['form']["messages"]["ThankYouText"]             = $the_form['ThankYouText'];
        $data['form']["SubmissionRestriction"]                = $the_form['SubmissionRestriction'];
        $data['form']["messages"]["LblSpamProtectionError"]   = $the_form['LblSpamProtectionError'];
        $data['form']["messages"]["LblEmailRestrictionError"] = $the_form['LblEmailRestrictionError'];
        $data['form']["messages"]["LblIPRestrictionError"]    = $the_form['LblIPRestrictionError'];
        $data['form']["ConfirmationRedirectUrl"]              = $the_form['ConfirmationRedirectUrl'] ?? '';
        $data['form']["UseCaptcha"]                           = $the_form['UseCaptcha'];
        $data['form']["LblSpamProtection"]                    = $the_form['LblSpamProtection'];
        $data['form']["FormLanguageId"]                       = $the_form['FormLanguageId'];
        $login                                                = new Login(get_option('slrn_api_key'));
        if (empty($_COOKIE['slrn_session'])) {
            $loginResult = $login->DoLogin();
            if ((isset($loginResult['response']['code']) && $loginResult['response']['code'] != 200)) {
                return '';
            }
        }


        //Form Submit Processing


        //Determine layout file to use
        $alternateLayout = $attributes['layout'] ?? $data['post']['meta']['layout'] ?? '';

        $twig = ResourceNavigatorUtilityBase::FindVariant($obj->MachineName(), 'view', 'twig', $alternateLayout);

        //Form Submit Processing
        if (isset($_POST['slrn-submit-wf']) && ! empty(filter_var($_POST['slrn-submit-wf'], FILTER_SANITIZE_NUMBER_INT)) && $_POST['slrn-submit-wf'] == $data['form']["IntakeSettingsId"]) {
            if ( ! empty($_POST['fullname'])) {
                $data['form_response'] = ['code' => '200', 'message' => 'Thank you for contacting us.'];
            } else {
                if ($data['form']["UseCaptcha"] != 0) {
                    if ( ! empty($data['grc_site_key'])) {
                        $validated_grc = self::ValidateGoogleRecaptcha($_POST['g-recaptcha-response']);
                    } else {
                        $validated_grc = true;
                    }
                } else {
                    $validated_grc = true;
                }

                //Google Recaptcha is Valid
                if ($validated_grc) {

                    $post_data      = WebFormPost::ProcessWebFormData($data['form'], $data['post']);
                    $post_responses = [];
                    $response_url   = "";

                    if ( ! empty($data['post']['meta']['enable_rr'])) {
                        //Handle refferal response logic
                        $post_responses = WebFormPost::ProcessWebFormResponses($post_data, $data['post']);
                        $ref_ids        = [];
                        foreach ($post_responses as $res) {
                            if(!empty($res['provider']) ){
                                $providers = explode(',', $res['provider']);

                                $ref_ids = array_unique(array_merge($ref_ids, array_map('intval', $providers)));

                            }
                        }
                        $post_data->setProvidersToRefer($ref_ids);

                        $response_url = ResponseData::SaveResponse($data['post']['ID'], $post_responses);
                        $post_data->setDestinationUrl(get_bloginfo('url') . '/resource-navigator/responses/' . $response_url . '/');

                    }
                    else{
                        $ref_ids = !empty($the_form['providerId']) ? [$the_form['providerId']] : [];
                        $post_data->setProvidersToRefer($ref_ids);
                    }
                    global $wpdb;
                    $results = $wpdb->get_results("select post_id from {$wpdb->prefix}postmeta where meta_value != '' AND meta_key = 'resource_view_default_view'", ARRAY_A);
                    $viewID  = $results[0]['post_id'];

                    $view         = get_post($viewID);
                    $data['view'] = ResourceNavigatorUtilityBase::GetPostProperties($view, 'Sourcelink\ResourceNavigator\Post\ResourceViewPost');
                    //Nonce Verification
                    $valid = wp_verify_nonce($_POST['_slrn_nonce'], 'create_webform');

                    //Generate Response
                    if ($valid === false) {
                        $data['form_response'] = ['code' => '401', 'message' => $data['form']["messages"]["LblSpamProtectionError"]];
                    } else {
                        if (( ! empty($the_form['isContact']) || ! empty($the_form['isFeedback'])) && ! empty($the_form['providerId'])) {
                            $providerApi = new Provider(get_option('slrn_api_key'));
                            if ( ! empty($_SERVER['HTTP_CLIENT_IP'])) {
                                $ip = $_SERVER['HTTP_CLIENT_IP'];
                            } elseif ( ! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                            } else {
                                $ip = $_SERVER['REMOTE_ADDR'];
                            }


                            $protocol     = (( ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                            $url          = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
                            $trackingArgs = [
                                'clientId'     => $the_form['providerId'],
                                'activityType' => $the_form['isContact'] ? 'Contact Form Submit' : 'Feedback Form Submit',
                                'activityUrl'  => $url,
                                'referralUrl'  => '',
                                'ip'           => $ip
                            ];

                            $trackingResults = $providerApi->SaveNavigatorActivity($trackingArgs);
                        }
                        $data['form_response'] = WebFormPost::HandleFormPost($post_data, $data['form']["messages"], $post_responses, $data);


                        if ($data['form_response']["code"] == 200) {
                            if ( ! empty($response_url)) {
//                                if ( ! empty($post_data->GetEmail())) {
//                                    ResponseData::EmailLink($post_data->GetEmail(), get_bloginfo('url') . '/resource-navigator/responses/' . $response_url . '/');
//                                }
                                //echo $post_data->toJSON();
                                WebFormPost::Redirect(get_bloginfo('url') . '/resource-navigator/responses/' . $response_url . '/');
                                die();
                            } elseif ( ! empty($data['form']["ConfirmationRedirectUrl"])) {
                                WebFormPost::Redirect($data['form']["ConfirmationRedirectUrl"]);
                                die();
                            }
                        }
                    }
                } else {
                    $data['form_response'] = ['code' => '402', 'message' => $data['form']["messages"]["LblSpamProtectionError"]];
                }
            }
        }

        //enqueue ppf specific JS file
        $scripts['slrn-web-form-js'] = [
            'type'   => 'script',
            'src'    => ResourceNavigatorUtilityBase::GetAsset('js/frontend/wf-validate.js'),
            'deps'   => ['slrn-validate-js'],
            'footer' => true,
            'ver'    => ResourceNavigatorBase::GetCacheVersion(),
        ];
        ResourceNavigatorUtilityBase::EnqueueAdditional($scripts);

        //render something... or nothing
        return ! empty($twig) ? TwigManager::Twig()->Render($twig, $data) : '';
    }

    /**
     * HandleFormPost - post form to API and process a response to return to the calling method.
     *
     * @param IntakeForm $form_data
     * @param array|null $messages
     * @param array|null $responses
     * @param null $post
     *
     * @return array
     */
    public static function HandleFormPost(IntakeForm $form_data, array $messages = null, array $responses = null, array $post = null): ?array
    {

        if ( ! empty($responses) && ! empty($post)) {
            $notes                              = $form_data->getNotes();
            $post['form_response']['responses'] = $responses;
            $ref_ids = [];
            foreach ($responses as $res) {
                if(!empty($res['provider']) ){
                    $providers = explode(',', $res['provider']);

                    $ref_ids = array_unique(array_merge($ref_ids, array_map('intval', $providers)));

                }
            }
            $post['no_logo'] =  plugin_dir_url( __DIR__ ).'../assets/images/placeholder.png';
            $post['providers'] = $ref_ids;
            $rendered_response                  = TwigManager::Twig()->Render('components/form-response.twig', $post);
            $notes                              .= $rendered_response;

            $form_data->setNotes($notes);

        }
        $intakeApi = new Intake(get_option('slrn_api_key'));
        $response  = json_decode((string)$intakeApi->SaveWebForm($form_data)['body'], true);
        if ( ! isset($response["isError"])) { //isError is only set in the api response when the response is not an error.
            $response["isError"] = true;
            $response['message'] = $response['Detail'] ?? "An unspecified error has occurred in the SourceLink API.";
            $response['result']  = '';
        }

        return ['code' => $response["isError"] == false ? '200' : '500', 'message' => $response["isError"] == false ? $messages['ThankYouText'] : $response['message'], "response" => $response, 'responses' => $responses];
    }


    /**
     * @param $form
     * @param $args
     *
     * @return mixed
     */
    public static function ParseTokens($form, $args)
    {
        $tokens = ['{{Organization Name}}', '{{OrganizationName}}', '{{ProviderName}}', '{{ContactFirstName}}', '{{ContactLastName}}'];
        foreach ($form as $idx => $field) {
            foreach ($tokens as $t) {
                if (strpos($field, $t) !== false) {
                    switch ($t) {
                        case '{{Organization Name}}':
                        case '{{OrganizationName}}':
                        case '{{ProviderName}}':
                            $form[$idx] = str_replace($t, $args['providerName'], $field);
                            break;
                        case '{{ContactFirstName}}':
                            $form[$idx] = str_replace($t, $args['contactFirstName'], $field);
                            break;
                        case '{{ContactLastName}}':
                            $form[$idx] = str_replace($t, $args['contactLastName'], $field);
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        return $form;
    }

    /**
     * @return array
     */
    public static function GetProviders()
    {
        $rtn       = [];
        $providers = new Provider(get_option('slrn_api_key'));
        $result    = ApiBase::ProcessResult($providers->GetProviders([])["body"]);
        if ( ! empty($result)) {
            if ( ! empty($result["isError"]) && $result["isError"] == true) {

            } else {
                if ( ! empty($result["result"])) {
                    foreach ($result["result"] as $item) {
                        if ($item['Active'] == true) {
                            $rtn[$item['ProviderID']] = $item['ProviderName'];
                        }
                    }
                }
            }
        }

        return $rtn;
    }

    public static function GetQuestions($id)
    {
        $staticClass  = get_called_class();
        $data         = [];
        $intakeObj    = new IntakeCache();
        $extra_fields = [];
        if ( ! empty($id)) {
            $forms        = $intakeObj->GetCacheForEndpoint("GetWebForms");
            $the_form     = WebFormPost::FindForm($forms,get_post_meta($id, 'web_form_form', true));
//            $the_form     = $forms[get_post_meta($id, 'web_form_form', true)] ?? null;
            $extra_fields = get_post_meta($id, 'web_form_extra_fields', true);
        }


        $data['fields'] = WebFormPost::GetAllFields($the_form, $extra_fields);
        $tmp            = ['' => 'None'];
        foreach ($data['fields'] as $key => $field) {
            $tmp[$field['id']] = $field['label'];
        }

        return $tmp;
    }

    public static function GetQuestionDetailsByID($id, $question)
    {
        $staticClass  = get_called_class();
        $data         = [];
        $intakeObj    = new IntakeCache();
        $extra_fields = [];
        if ( ! empty($id) && ! empty($question)) {
            $forms        = $intakeObj->GetCacheForEndpoint("GetWebForms");
            $the_form     = WebFormPost::FindForm($forms,get_post_meta($id, 'web_form_form', true));
            $extra_fields = get_post_meta($id, 'web_form_extra_fields', true);


            $data['fields'] = WebFormPost::GetAllFields($the_form, $extra_fields);
            $question       = array_search($question, array_column($data['fields'], 'id'));


            return $data['fields'][$question];
        } else {
            return $data;
        }

    }

    public static function GetFieldsForSort($id)
    {
        $staticClass  = get_called_class();
        $data         = [];
        $intakeObj    = new IntakeCache();
        $extra_fields = [];
        $tmp          = [];
        if ( ! empty($id)) {
            $forms      = $intakeObj->GetCacheForEndpoint("GetWebForms");
            $form_index = get_post_meta($id, 'web_form_form', true);
            if (empty($form_index) && $form_index !== "0") {
                return $tmp;
            }
            $the_form     = WebFormPost::FindForm($forms,$form_index);
            $extra_fields = get_post_meta($id, 'web_form_extra_fields', true);
        }

//        var_dump($the_form);
//        exit();


        $data['fields'] = WebFormPost::GetAllFields($the_form, $extra_fields);
        foreach ($data['fields'] as $key => $field) {

            $tmp[$field['id']] = [
                'type'  => 'form_field',
                'value' => '',
                'text'  => $field['label'],
                'size'  => 'col-12',
                'hint'  => 'override the field label from the api',
                'order' => 0,
                'enable_notes' => true
            ];
        }

        return $tmp;
    }

    public static function GetAllFields($form_data, $extra_fields = []): array
    {
        $language = $form_data["FormLanguageId"] ?? 1; //1 = english
        $cache    = new IntakeCache();
        $fields   = [];

        $business_stages       = $cache->GetListValuesArray('Business Stage', $language);
        $entity_types          = $cache->GetListValuesArray('Entity Type', $language);
        $gender_types          = $cache->GetListValuesArray('Gender', $language);
        $race_types            = $cache->GetListValuesArray('Race', $language);
        $disability_statuses   = $cache->GetListValuesArray('Disabled Status', $language);
        $education_backgrounds = $cache->GetListValuesArray('Education Background', $language);
        $ethnicity_types       = $cache->GetListValuesArray('Ethnicity', $language);
        $interact_types        = $cache->GetListValuesArray('Interaction Type', $language);
        $referral_entities     = $cache->GetListValuesArray('Referral Entity Type', $language);
        $service_types         = $cache->GetListValuesArray('Assistance Requested', $language);
        $counselors            = $cache->GetListValuesArray('Counselor', $language);
        $time_spent            = $cache->GetListValuesArray('Time Spent', $language);
        $yes_nos               = $cache->GetListValuesArray('Yes No', $language);
        $client_statuses       = $cache->GetListValuesArray('Client Status Limited', $language);
        $countries             = $cache->GetListValuesArray('Country', $language);
        $military              = $cache->GetListValuesArray('Military Status', $language);
        $yes_no_only           = $cache->GetListValuesArray('Yes No Only', $language);
        $capital_types         = $cache->GetListValuesArray('Capital Type', $language);
        $capital_sources       = $cache->GetListValuesArray('Capital Source', $language);
        $rural_urban           = $cache->GetListValuesArray('Rural or Urban', $language);
        $form_skeleton         = [];
        if ($form_data == null) {
            return $fields;
        }
        if ( ! empty($form_data['providerId'])) {
            $form_skeleton['providerId'] = ['type' => 'hidden', 'id' => 'providerId', 'value' => $form_data['providerId']];
        }
        $form_skeleton['BasicInfoTitle']            = ['type' => "heading", 'label' => $form_data["BasicInfoTitle"]];
        $form_skeleton['SetCompanyName']            = ['type' => 'text', 'id' => 'companyName', 'label' => $form_data['LblCompanyName']];
        $form_skeleton['SetFirstName']              = ['type' => 'text', 'id' => 'firstName', 'label' => $form_data['LblFirstName']];
        $form_skeleton['SetLastName']               = ['type' => 'text', 'id' => 'lastName', 'label' => $form_data['LblLastName']];
        $form_skeleton['SetWorkTitle']              = ['type' => 'text', 'id' => 'workTitle', 'label' => $form_data['LblWorkTitle']];
        $form_skeleton['SetGender']                 = ['type' => 'select', 'id' => 'genderId', 'values' => $gender_types, 'label' => $form_data['LblGender']];
        $form_skeleton['SetRace']                   = ['type' => 'checkbox', 'id' => 'raceId', 'values' => $race_types, 'label' => $form_data['LblRace'], 'unique_name' => true];
        $form_skeleton['SetEthnicity']              = ['type' => 'select', 'id' => 'ethnicityId', 'values' => $ethnicity_types, 'label' => $form_data['LblEthnicity']];
        $form_skeleton['SetLgbtq']                  = ['type' => 'select', 'id' => 'lgbtqId', 'values' => $yes_nos, 'label' => $form_data['LblIdentifyAsLgbtq']];
        $form_skeleton['SetEducationalBackground']  = ['type' => 'select', 'id' => 'educationBackgroundId', 'values' => $education_backgrounds, 'label' => $form_data['LblEducationalBackground']];
        $form_skeleton['SetDisabled']               = ['type' => 'select', 'id' => 'disabledId', 'values' => $disability_statuses, 'label' => $form_data['LblDisabilityStatus']];
        $form_skeleton['SetMilitary']               = ['type' => 'select', 'id' => 'militaryStatusId', 'values' => $military, 'label' => $form_data['LblMilitaryStatus']];
        $form_skeleton['SetEntityType']             = ['type' => 'select', 'id' => 'entityId', 'values' => $entity_types, 'label' => $form_data['LblLegalEntityType']];
        $form_skeleton['SetInBusiness']             = ['type' => 'select', 'id' => 'inBusiness', 'values' => $yes_nos, 'label' => $form_data['LblInBusiness']];
        $form_skeleton['SetMonthYearStarted']       = ['type' => 'date', 'id' => 'monthYearStarted', 'label' => $form_data['LblMonthYearStarted'], 'args' => ['format' => "mm/yyyy", 'pickLevel' => 1, 'startView' => 1]];
        $form_skeleton["SetAddress"]                = ['type' => 'text', 'id' => 'address1', 'label' => $form_data['LblAddress']];
        $form_skeleton["SetAddress2"]               = ['type' => 'text', 'id' => 'address2', 'label' => $form_data['LblAddress2']];
        $form_skeleton["SetZip"]                    = ['type' => 'text', 'id' => 'zip', 'label' => $form_data['LblZipCode']];
        $form_skeleton["SetCountry"]                = ['type' => 'select', 'id' => 'countryIso', 'values' => $countries, 'label' => $form_data['LblCountry']];
        $form_skeleton["SetRuralUrban"]             = ['type' => 'select', 'id' => 'ruralUrbanId', 'values' => $rural_urban, 'label' => $form_data['LblRuralUrban']];
        $form_skeleton["SetLegalState"]             = ['type' => 'text', 'id' => 'legalState', 'label' => $form_data['LblLegalState']];
        $form_skeleton["SetWebsite"]                = ['type' => 'text', 'id' => 'webUrl', 'label' => $form_data['LblWebsite']];
        $form_skeleton["SetFacebookUrl"]            = ['type' => 'text', 'id' => 'facebookUrl', 'label' => $form_data['LblFacebookUrl']];
        $form_skeleton["SetTwitterUrl"]             = ['type' => 'text', 'id' => 'twitterUrl', 'label' => $form_data['LblTwitterUrl']];
        $form_skeleton['SetEmail']                  = ['type' => 'email', 'id' => 'email', 'label' => $form_data['LblEmail']];
        $form_skeleton['WorkPhone']                 = ['type' => 'tel', 'id' => 'workPhone', 'label' => $form_data['LblWorkPhone'], 'parent' => "SetPhone"];
        $form_skeleton['HomePhone']                 = ['type' => 'tel', 'id' => 'homePhone', 'label' => $form_data['LblHomePhone'], 'parent' => "SetHomePhone"];
        $form_skeleton['SetCellPhone']              = ['type' => 'tel', 'id' => 'cellPhone', 'label' => $form_data['LblMobilePhone']];
        $form_skeleton['SetFax']                    = ['type' => 'tel', 'id' => 'fax', 'label' => $form_data['LblFax']];
        $form_skeleton['SetBirthDate']              = ['type' => 'date', 'id' => 'birthDate', 'label' => $form_data['LblDateOfBirth'], ''];
        $form_skeleton['SetTargetMarket']           = ['type' => 'text', 'id' => 'targetMarket', 'label' => $form_data['LblTargetMarket']];
        $form_skeleton['SetTaxIdNum']               = ['type' => 'text', 'id' => 'taxIdNum', 'label' => $form_data['LblBusinessId']];
        $form_skeleton['SetNaics']                  = ['type' => 'text', 'id' => 'naicsId', 'label' => $form_data['LblNAICS'], 'hint' => $form_data['LblNAICSNote']];
        $form_skeleton['SetClientStatus']           = ['type' => 'select', 'id' => 'clientStatusId', 'values' => $client_statuses, 'label' => $form_data['LblClientStatus']];
        $form_skeleton['SetReferralEntity']         = ['type' => 'select', 'id' => 'referralEntityTypeId', 'values' => $referral_entities, 'label' => $form_data['LblReferralEntityType']];
        $form_skeleton['SetInteractionType']        = ['type' => 'select', 'id' => 'interactTypeId', 'values' => $interact_types, 'label' => $form_data['LblInteractionType']];
        $form_skeleton['SetServiceType']            = ['type' => 'select', 'id' => 'serviceTypeId', 'values' => $service_types, 'label' => $form_data['LblServiceType']];
        $form_skeleton['SetInteractionDate']        = ['type' => 'date', 'id' => 'interactionDate', 'label' => $form_data['LblInteractionDate']];
        $form_skeleton['SetInteractionContactTime'] = ['type' => 'select', 'id' => 'timeSpentId', 'values' => $time_spent, 'label' => $form_data['LblContactTime']];
        $form_skeleton['SetInteractionPrepTime']    = ['type' => 'select', 'id' => 'prepTimeId', 'values' => $time_spent, 'label' => $form_data['LblPrepTime']];
        $form_skeleton['SetInteractionTravelTime']  = ['type' => 'select', 'id' => 'travelTimeId', 'values' => $time_spent, 'label' => $form_data['LblTravelTime']];
        $form_skeleton['SetCounselor']              = ['type' => 'select', 'id' => 'counselorId', 'values' => $counselors, 'label' => $form_data['LblCounselorName']];


        //Extra fields from WP
        foreach ($extra_fields as $idx => $field) {
            if (empty($field['type']) || empty($field['title'])) {
                continue;
            }
            $field_vals = preg_split('/\r\n|\r|\n/', $field["options"]);

            $val_array = [];
            foreach ($field_vals as $idx2 => $field_val) {
                $val_array[$idx2] = [
                    'value' => $field_val,
                    'label' => $field_val,
                ];
            }
            $form_skeleton['extra_field_' . $idx] = ['type' => $field["type"], 'label' => $field["title"], 'required' => $field["required"] ?? 2, 'values' => $val_array, 'custom_field' => true, 'hint' => $field["notes"]];
        }

        //BACK TO API FIELDS
        $form_skeleton['SetNote']                  = ['type' => 'textarea', 'id' => 'notes', 'label' => $form_data['NoteTitle']];
        $form_skeleton['CompanySnapshotTitle']     = ['type' => "heading", 'label' => $form_data["CompanySnapshotTitle"]];
        $form_skeleton['SetBusinessStage']         = ['type' => 'select', 'id' => 'busStageId', 'values' => $business_stages, 'label' => $form_data['LblBusinessStage']];
        $form_skeleton['SetFullTimeEmployees']     = ['type' => 'text', 'id' => 'fullTimeEmployees', 'label' => $form_data['LblFTEmployees']];
        $form_skeleton['SetPartTimeEmployees']     = ['type' => 'text', 'id' => 'partTimeEmployees', 'label' => $form_data['LblPTEmployees']];
        $form_skeleton['SetLoanAmount']            = ['type' => 'money', 'id' => 'loanAmount', 'label' => $form_data['LblLoanAmount']];
        $form_skeleton['SetEquityAmount']          = ['type' => 'money', 'id' => 'equityAmount', 'label' => $form_data['LblEquityAmount']];
        $form_skeleton['SetGrantAmount']           = ['type' => 'money', 'id' => 'grantAmount', 'label' => $form_data['LblGrantAmount']];
        $form_skeleton['SetRevenueAmount']         = ['type' => 'money', 'id' => 'revenueAmount', 'label' => $form_data['LblRevenueAmount']];
        $form_skeleton['SetBondingCapacityAmount'] = ['type' => 'money', 'id' => 'bondingCapacityAmount', 'label' => $form_data['LblBondingCapacityAmount']];
        $form_skeleton['SetContractAmount']        = ['type' => 'money', 'id' => 'contractAmount', 'label' => $form_data['LblContractsAmount']];

        $form_skeleton["SalesScope"]                  = ['type' => "heading", 'label' => $form_data["LblSalesScope"], 'parent' => 'SetSalesScope'];
        $form_skeleton["SalesScopeLocally"]           = ['type' => 'radio', 'id' => 'sellLocally', 'values' => $yes_no_only, 'label' => $form_data['LblSellLocally'], 'parent' => 'SetSalesScope'];
        $form_skeleton["SalesScopeRegionally"]        = ['type' => 'radio', 'id' => 'sellRegionally', 'values' => $yes_no_only, 'label' => $form_data['LblSellRegionally'], 'parent' => 'SetSalesScope'];
        $form_skeleton["SalesScopeNationally"]        = ['type' => 'radio', 'id' => 'sellNationally', 'values' => $yes_no_only, 'label' => $form_data['LblSellNationally'], 'parent' => 'SetSalesScope'];
        $form_skeleton["SalesScopeInternational"]     = ['type' => 'radio', 'id' => 'sellInternationally', 'values' => $yes_no_only, 'label' => $form_data['LblSellInternationally'], 'parent' => 'SetSalesScope'];
        $form_skeleton["SalesScopeFederalGovernment"] = ['type' => 'radio', 'id' => 'sellFedGovt', 'values' => $yes_no_only, 'label' => $form_data['LblSellFedGovt'], 'parent' => 'SetSalesScope'];

        $form_skeleton["CapitalRequested"]         = ['type' => "heading", 'label' => $form_data["CapitalRequestedTitle"], 'parent' => 'SetCapitalRequested', 'layout' => 'indent'];
        $form_skeleton["CapitalRequestedRepeater"] = [
            'type'            => "capital",
            'label'           => $form_data["CapitalRequestedTitle"] . ' (repeater)',
            'labels'          => [
                'type'   => $form_data["LblCapitalType"],
                'source' => $form_data["LblCapitalSource"],
                'amount' => $form_data["LblCapitalAmount"],
                'add'    => $form_data["LblCapitalAddAnother"],
                'error'  => $form_data["LblCapitalAddAnotherError"],
            ],
            'capital_types'   => $capital_types,
            'capital_sources' => $capital_sources,
            'parent'          => 'SetCapitalRequested'
        ];

        $form_skeleton["CapitalSecured"]         = ['type' => "heading", 'label' => $form_data["CapitalSecuredTitle"], 'parent' => 'SetCapitalSecured', 'layout' => 'indent'];
        $form_skeleton["CapitalSecuredRepeater"] = [
            'type'            => "capital",
            'label'           => $form_data["CapitalRequestedTitle"] . ' (repeater)',
            'labels'          => [
                'type'   => $form_data["LblCapitalType"],
                'source' => $form_data["LblCapitalSource"],
                'amount' => $form_data["LblCapitalAmount"],
                'add'    => $form_data["LblCapitalAddAnother"],
                'error'  => $form_data["LblCapitalAddAnotherError"],
            ],
            'capital_types'   => $capital_types,
            'capital_sources' => $capital_sources,
            'parent'          => 'SetCapitalSecured'
        ];


        $form_skeleton["AdtlDemographicsTitle"]                = ['type' => "heading", 'label' => $form_data["AdtlDemographicsTitle"]];
        $form_skeleton["CertifiedWomanOwned"]                  = ['type' => 'radio', 'id' => 'certWomenOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedWomanOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedMinorityOwned"]               = ['type' => 'radio', 'id' => 'certMinorityOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedMinorityOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedDisadvantagedOwned"]          = ['type' => 'radio', 'id' => 'certDisadvantagedOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedDisadvantagedOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedDisabledOwned"]               = ['type' => 'radio', 'id' => 'certDisabledOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedDisabledOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedVeteranOwned"]                = ['type' => 'radio', 'id' => 'certVetOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedVeteranOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedServiceDisabledVeteranOwned"] = ['type' => 'radio', 'id' => 'certSerDisabledVetOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedServiceDisabledVeteranOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedLGBTQOwned"]                  = ['type' => 'radio', 'id' => 'certLGBTQOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedLGBTQOwned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedHUDSection3Owned"]            = ['type' => 'radio', 'id' => 'certHUDSec3Owned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedHUDSection3Owned'], 'parent' => 'SetCertification'];
        $form_skeleton["CertifiedSBA8aOwned"]                  = ['type' => 'radio', 'id' => 'cert8aOwned', 'values' => $yes_no_only, 'label' => $form_data['LblCertifiedSBA8aOwned'], 'parent' => 'SetCertification'];

        $form_skeleton["WomanOwned"]                     = ['type' => 'radio', 'id' => 'womenOwned', 'values' => $yes_no_only, 'label' => $form_data['LblWomanOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["MinorityOwned"]                  = ['type' => 'radio', 'id' => 'minorityOwned', 'values' => $yes_no_only, 'label' => $form_data['LblMinorityOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["VeteranOwned"]                   = ['type' => 'radio', 'id' => 'veteranOwned', 'values' => $yes_no_only, 'label' => $form_data['LblVeteranOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["DisabledOwned"]                  = ['type' => 'radio', 'id' => 'disabledOwned', 'values' => $yes_no_only, 'label' => $form_data['LblDisabledOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["ImmigrantOwned"]                 = ['type' => 'radio', 'id' => 'immigrantOwned', 'values' => $yes_no_only, 'label' => $form_data['LblImmigrantOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["InternallyDisplacedPersonOwned"] = ['type' => 'radio', 'id' => 'internallyDisplPerOwned', 'values' => $yes_no_only, 'label' => $form_data['LblInternallyDisplacedPersonOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["JusticeInvolvedCitizenOwned"]    = ['type' => 'radio', 'id' => 'justiceInvCitizenOwned', 'values' => $yes_no_only, 'label' => $form_data['LblJusticeInvolvedCitizenOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["RefugeeOwned"]                   = ['type' => 'radio', 'id' => 'refugeeOwned', 'values' => $yes_no_only, 'label' => $form_data['LblRefugeeOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["LGBTQOwned"]                     = ['type' => 'radio', 'id' => 'lgbtqOwned', 'values' => $yes_no_only, 'label' => $form_data['LblLGBTQOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["YouthOwned"]                     = ['type' => 'radio', 'id' => 'youthOwned', 'values' => $yes_no_only, 'label' => $form_data['LblYouthOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["LowToModerateIncomeOwned"]       = ['type' => 'radio', 'id' => 'lowIncomeOwned', 'values' => $yes_no_only, 'label' => $form_data['LblLowToModerateIncomeOwned'], 'parent' => 'SetClassification'];
        $form_skeleton["NonEnglishBusiness"]             = ['type' => 'radio', 'id' => 'nonEnglishBusinessOwned', 'values' => $yes_no_only, 'label' => $form_data['LblNonEnglishBusiness'], 'parent' => 'SetClassification'];

        $form_skeleton["HomeBasedBusiness"]     = ['type' => 'radio', 'id' => 'homeBased', 'values' => $yes_no_only, 'label' => $form_data['LblHomeBasedBusiness'], 'parent' => 'SetBusinessChannel'];
        $form_skeleton["SellingOnlineBusiness"] = ['type' => 'radio', 'id' => 'eCommerce', 'values' => $yes_no_only, 'label' => $form_data['LblSellingOnlineBusiness'], 'parent' => 'SetBusinessChannel'];
        $form_skeleton["CommercialLocation"]    = ['type' => 'radio', 'id' => 'hasCommercialLocation', 'values' => $yes_no_only, 'label' => $form_data['LblCommercialLocation'], 'parent' => 'SetBusinessChannel'];
        $form_skeleton["MobileBusiness"]        = ['type' => 'radio', 'id' => 'hasMobileBusiness', 'values' => $yes_no_only, 'label' => $form_data['LblMobileBusiness'], 'parent' => 'SetBusinessChannel'];

        $count = 0;

        $fields_since_header = 0;
        foreach ($form_skeleton as $field_id => $data) {

            if ((isset($form_data[$field_id]) && $form_data[$field_id] !== 0) || (isset($data['parent']) && isset($form_data[$data['parent']]) && $form_data[$data['parent']] !== 0)) {

                $status = isset($data['parent']) ? $form_data[$data['parent']] : $form_data[$field_id];
                $res    = self::GetField($field_id, $data, $status, $form_data['IntakeSettingsId']);


                if ($res == null) {
                    continue;
                }
                if ($count > 0) {
                    if ($data['type'] == 'heading') {
                        if ($fields_since_header == 0) {
                            continue;
                        }
                        $fields_since_header = 0;
                    } else {
                        $fields_since_header++;
                    }
                }

                $count++;
                $fields[] = $res;
            }
            if (isset($data['custom_field']) && $data['custom_field'] == true) {

                $res      = self::GetField($field_id, $data, ! empty($data['required']) ? 1 : 2, $form_data['IntakeSettingsId']);
                $fields[] = $res;
                $fields_since_header++;
                $count++;
            }

        }
        $last = array_pop($fields);
        if ($last['type'] != 'heading') {
            $fields[] = $last;
        }

        return $fields;
    }

    public static function GetField($field_id, $data, $required, $intake_settings_id): ?array
    {
        if (empty($field_id) || empty($data) || empty($required) || empty($data['type'])) {
            return null;
        }
        //trim the set off of every field id if it exists
        if (substr($field_id, 0, strlen("Set")) == "Set") {
            $field_id = substr($field_id, strlen('Set'));
        }


        $rtn = null;
        switch ($data['type']) {
            case 'text':
            case 'email':
            case 'money':
            case 'textarea':
            case 'tel':
                $rtn = [
                    'type'     => $data['type'],
                    'id'       => $data['id'] ?? $field_id,
                    'required' => $required == 1,
                    'label'    => $data['label'],
                    'hint'     => $data['hint'] ?? "",
                    'prefix'   => $intake_settings_id

                ];
                break;
            case 'date':
                $rtn = [
                    'type'     => $data['type'],
                    'id'       => $data['id'] ?? $field_id,
                    'required' => $required == 1,
                    'label'    => $data['label'],
                    'hint'     => $data['hint'] ?? "",
                    'prefix'   => $intake_settings_id,
                    'args'     => $data['args'] ?? []

                ];
                break;
            case 'heading':
                $rtn = [
                    'type'     => $data['type'],
                    'id'       => $field_id,
                    'required' => $required == 1,
                    'label'    => $data['label'] ?? "",
                    'layout'   => $data['layout'] ?? "",
                    'prefix'   => $intake_settings_id

                ];
                break;
            case 'select':
            case 'checkbox':
            case 'radio':
                $rtn = [
                    'type'        => $data['type'],
                    'values'      => $data['values'] ?? [],
                    'id'          => $data['id'] ?? $field_id ?? "",
                    'required'    => $required == 1,
                    'label'       => $data['label'] ?? "",
                    'prefix'      => $intake_settings_id,
                    'hint'        => $data['hint'] ?? "",
                    'unique_name' => $data['unique_name'] ?? false
                ];
                break;
            case 'capital':
                $rtn = [
                    'type'            => $data['type'],
                    'id'              => $field_id ?? "",
                    'required'        => $required == 1,
                    'label'           => $data['label'] ?? "",
                    'labels'          => $data['labels'],
                    'capital_types'   => $data['capital_types'],
                    'capital_sources' => $data['capital_sources'],
                    'prefix'          => $intake_settings_id
                ];
                break;
            case 'hidden':
                $rtn = [
                    'type'   => $data['type'],
                    'id'     => $field_id ?? "",
                    'value'  => $data['value'] ?? "",
                    'prefix' => $intake_settings_id
                ];
                break;
            default:
                break;
        }

        return $rtn;
    }

    public static function ProcessWebFormData($form_data, $post_data): IntakeForm
    {
        $validation    = [
            'intakeStagingId'         => FILTER_SANITIZE_NUMBER_INT,
            'intakeSettingsId'        => FILTER_SANITIZE_NUMBER_INT,
            'counselorId'             => FILTER_SANITIZE_NUMBER_INT,
            'companyName'             => FILTER_SANITIZE_STRING,
            'firstName'               => FILTER_SANITIZE_STRING,
            'lastName'                => FILTER_SANITIZE_STRING,
            'email'                   => FILTER_SANITIZE_EMAIL,
            'workTitle'               => FILTER_SANITIZE_STRING,
            'webUrl'                  => FILTER_SANITIZE_URL,
            'facebookUrl'             => FILTER_SANITIZE_URL,
            'twitterUrl'              => FILTER_SANITIZE_URL,
            'address1'                => FILTER_SANITIZE_STRING,
            'address2'                => FILTER_SANITIZE_STRING,
            'zip'                     => FILTER_SANITIZE_STRING,
            'countryIso'              => FILTER_SANITIZE_STRING,
            'ruralUrbanId'            => FILTER_SANITIZE_NUMBER_INT,
            'legalState'              => FILTER_SANITIZE_STRING,
            'workPhone'               => FILTER_SANITIZE_STRING,
            'cellPhone'               => FILTER_SANITIZE_STRING,
            'homePhone'               => FILTER_SANITIZE_STRING,
            'fax'                     => FILTER_SANITIZE_STRING,
            'targetMarket'            => FILTER_SANITIZE_STRING,
            'naicsId'                 => FILTER_SANITIZE_NUMBER_INT,
            'entityId'                => FILTER_SANITIZE_NUMBER_INT,
            'taxIdNum'                => FILTER_SANITIZE_STRING,
            'referralEntityTypeId'    => FILTER_SANITIZE_NUMBER_INT,
//            'providerId'              => FILTER_SANITIZE_NUMBER_INT,
            'womenOwned'              => FILTER_SANITIZE_NUMBER_INT,
            'minorityOwned'           => FILTER_SANITIZE_NUMBER_INT,
            'veteranOwned'            => FILTER_SANITIZE_NUMBER_INT,
            'immigrantOwned'          => FILTER_SANITIZE_NUMBER_INT,
            'internallyDisplPerOwned' => FILTER_SANITIZE_NUMBER_INT,
            'justiceInvCitizenOwned'  => FILTER_SANITIZE_NUMBER_INT,
            'refugeeOwned'            => FILTER_SANITIZE_NUMBER_INT,
            'lgbtqOwned'              => FILTER_SANITIZE_NUMBER_INT,
            'youthOwned'              => FILTER_SANITIZE_NUMBER_INT,
            'lowIncomeOwned'          => FILTER_SANITIZE_NUMBER_INT,
            'disabledOwned'           => FILTER_SANITIZE_NUMBER_INT,
            'nonEnglishBusinessOwned' => FILTER_SANITIZE_NUMBER_INT,
            'certWomenOwned'          => FILTER_SANITIZE_NUMBER_INT,
            'certMinorityOwned'       => FILTER_SANITIZE_NUMBER_INT,
            'certDisadvantagedOwned'  => FILTER_SANITIZE_NUMBER_INT,
            'certLGBTQOwned'          => FILTER_SANITIZE_NUMBER_INT,
            'certSerDisabledVetOwned' => FILTER_SANITIZE_NUMBER_INT,
            'certVetOwned'            => FILTER_SANITIZE_NUMBER_INT,
            'certHUDSec3Owned'        => FILTER_SANITIZE_NUMBER_INT,
            'certDisabledOwned'       => FILTER_SANITIZE_NUMBER_INT,
            'cert8aOwned'             => FILTER_SANITIZE_NUMBER_INT,
            'homeBased'               => FILTER_SANITIZE_NUMBER_INT,
            'eCommerce'               => FILTER_SANITIZE_NUMBER_INT,
            'hasCommercialLocation'   => FILTER_SANITIZE_NUMBER_INT,
            'hasMobileBusiness'       => FILTER_SANITIZE_NUMBER_INT,
            'genderId'                => FILTER_SANITIZE_NUMBER_INT,
            'ethnicityId'             => FILTER_SANITIZE_NUMBER_INT,
            'educationBackgroundId'   => FILTER_SANITIZE_NUMBER_INT,
            'disabledId'              => FILTER_SANITIZE_NUMBER_INT,
            'militaryStatusId'        => FILTER_SANITIZE_NUMBER_INT,
            'veteranStatusId'         => FILTER_SANITIZE_NUMBER_INT,
            'lgbtqId'                 => FILTER_SANITIZE_NUMBER_INT,
            'birthDate'               => FILTER_SANITIZE_STRING,
            'clientTypeId'            => FILTER_SANITIZE_NUMBER_INT,
            'clientStatusId'          => FILTER_SANITIZE_NUMBER_INT,
            'inBusiness'              => FILTER_SANITIZE_NUMBER_INT,
            'yearStarted'             => FILTER_SANITIZE_NUMBER_INT,
            'monthStarted'            => FILTER_SANITIZE_NUMBER_INT,
            'interactTypeId'          => FILTER_SANITIZE_NUMBER_INT,
            'serviceTypeId'           => FILTER_SANITIZE_NUMBER_INT,
            'interactionDate'         => FILTER_SANITIZE_STRING,
            'timeSpentId'             => FILTER_SANITIZE_NUMBER_INT,
            'prepTimeId'              => FILTER_SANITIZE_NUMBER_INT,
            'travelTimeId'            => FILTER_SANITIZE_NUMBER_INT,
            'notes'                   => FILTER_SANITIZE_STRING,
            'busStageId'              => FILTER_SANITIZE_NUMBER_INT,
            'fullTimeEmployees'       => FILTER_SANITIZE_NUMBER_INT,
            'partTimeEmployees'       => FILTER_SANITIZE_NUMBER_INT,
            'loanAmount'              => FILTER_SANITIZE_NUMBER_INT,
            'equityAmount'            => FILTER_SANITIZE_NUMBER_INT,
            'grantAmount'             => FILTER_SANITIZE_NUMBER_INT,
            'revenueAmount'           => FILTER_SANITIZE_NUMBER_INT,
            'bondingCapacityAmount'   => FILTER_SANITIZE_NUMBER_INT,
            'contractAmount'          => FILTER_SANITIZE_NUMBER_INT,
            'sellLocally'             => FILTER_SANITIZE_NUMBER_INT,
            'sellRegionally'          => FILTER_SANITIZE_NUMBER_INT,
            'sellNationally'          => FILTER_SANITIZE_NUMBER_INT,
            'sellInternationally'     => FILTER_SANITIZE_NUMBER_INT,
            'sellFedGovt'             => FILTER_SANITIZE_NUMBER_INT,
            'userIPAddress'           => FILTER_SANITIZE_STRING,
            'submissionUrl'           => FILTER_SANITIZE_STRING,

        ];
        $form_skeleton = [];
        //Extra fields from WP
        foreach ($post_data['meta_lists']['extra_fields'] as $idx => $field) {
            if (empty($field['type']) || empty($field['title'])) {
                continue;
            }
            $field_vals = preg_split('/\r\n|\r|\n/', $field["options"]);

            $val_array = [];
            foreach ($field_vals as $idx2 => $field_val) {
                $val_array[$idx2] = [
                    'value' => $field_val,
                    'label' => $field_val,
                ];
            }
            $form_skeleton['extra_field_' . $idx] = ['label' => $field["title"], 'values' => $val_array, 'custom_field' => true];
        }
        $post_data_filtered            = filter_input_array(INPUT_POST, $validation);
        $race_ids                      = $_POST['raceId'] ?? null;
        $post_data_filtered['raceId1'] = false;
        $post_data_filtered['raceId2'] = false;
        $post_data_filtered['raceId3'] = false;
        $post_data_filtered['raceId4'] = false;
        $post_data_filtered['raceId5'] = false;
        if ( ! empty($race_ids)) {
            foreach ($race_ids as $race) {
                $post_data_filtered['raceId' . intval($race)] = true;
            }
        }

        //Note
        if ( ! empty($post_data_filtered['notes'])) {
            $post_data_filtered['notes'] = "<div class='sl-form-response-notes'>\r\n" . $post_data_filtered['notes'] . "</div>\r\n";
        }

        //Additional fields
        $add_fields = "";
        foreach ($_POST as $key => $raw_field) {
            if (strpos($key, 'extra_field_') !== false) {
                $add_fields .= "<p class='addtl-field-question' data-field='" . $key . "'>" . $form_skeleton[$key]['label'] . "</p>\r\n";
                if (is_array($raw_field)) {
                    $add_fields .= "<p class='addtl-field-response' data-field='" . $key . "'>";
                    foreach ($raw_field as $item) {
                        $add_fields .= $form_skeleton[$key]['values'][$item]['label'] . '<br>';
                    }
                    $add_fields .= "</p>\r\n";
                } else {
                    $add_fields .= "<p class='addtl-field-response' data-field='" . $key . "'>" . filter_var($raw_field, FILTER_SANITIZE_STRING) . "</p>\r\n";
                }
            }
        }

        if ( ! empty($add_fields)) {
            $post_data_filtered['notes'] .= "\n\r <div class='sl-form-response-addtl-fields'>\r\n";
            $post_data_filtered['notes'] .= " <p class='addtl-fields-header'>Additional Fields</p>\r\n";
            $post_data_filtered['notes'] .= $add_fields;
            $post_data_filtered['notes'] .= "\n\r </div>\r\n";
        }

        //Month/Year Started
        if ( ! empty($_POST['monthYearStarted']) && ! empty(filter_var($_POST['monthYearStarted'], FILTER_SANITIZE_STRING))) {
            $date  = filter_var($_POST['monthYearStarted'], FILTER_SANITIZE_STRING);
            $parts = explode('/', $date);
            if ( ! empty($parts)) {
                $post_data_filtered['monthStarted'] = intval($parts[0]);
                if ( ! empty($parts[1])) {
                    $post_data_filtered['yearStarted'] = intval($parts[1]);
                }
            }
        }
        $intake_form = new IntakeForm(json_encode($post_data_filtered));

        //Static data
        $intake_form->setIntakeSettingsId(intval($form_data['IntakeSettingsId']));
        $intake_form->setUserIPAddress($_SERVER['REMOTE_ADDR']);
        $intake_form->setsubmissionUrl((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");

        //Race

        //Capital Requested
        if ( ! empty($_POST['CapitalRequestedRepeater_type'])) {
            foreach ($_POST['CapitalRequestedRepeater_type'] as $idx => $capital) {
                if (filter_var($_POST['CapitalRequestedRepeater_amount'][$idx], FILTER_SANITIZE_NUMBER_FLOAT) != 0) {
                    $fc = new FundingCapital();
                    $fc->setCapitalTypeId((int)filter_var($_POST['CapitalRequestedRepeater_type'][$idx], FILTER_SANITIZE_NUMBER_INT));
                    $fc->setCapitalSourceId((int)filter_var($_POST['CapitalRequestedRepeater_source'][$idx], FILTER_SANITIZE_NUMBER_INT));
                    $fc->setCapitalAmount((float)filter_var($_POST['CapitalRequestedRepeater_amount'][$idx], FILTER_SANITIZE_NUMBER_FLOAT));

                    $intake_form->addCapitalRequested($fc);
                }
            }
        }

        //Capital Secured
        if ( ! empty($_POST['CapitalSecuredRepeater_type'])) {
            foreach ($_POST['CapitalSecuredRepeater_type'] as $idx => $capital) {
                if (filter_var($_POST['CapitalSecuredRepeater_amount'][$idx], FILTER_SANITIZE_NUMBER_FLOAT) != 0) {
                    $fc = new FundingCapital();
                    $fc->setCapitalTypeId((int)filter_var($_POST['CapitalSecuredRepeater_type'][$idx], FILTER_SANITIZE_NUMBER_INT));
                    $fc->setCapitalSourceId((int)filter_var($_POST['CapitalSecuredRepeater_source'][$idx], FILTER_SANITIZE_NUMBER_INT));
                    $fc->setCapitalAmount((float)filter_var($_POST['CapitalSecuredRepeater_amount'][$idx], FILTER_SANITIZE_NUMBER_FLOAT));

                    $intake_form->addCapitalSecured($fc);
                }
            }
        }

        return $intake_form;
    }

    /**
     * ProcessWebFormResponses - get responses for choices made by the user.
     *
     * @param IntakeForm $form_data
     * @param array|null $the_post
     *
     * @return array
     */
    public static function ProcessWebFormResponses($form_data, $the_post): ?array
    {
        //compile address
        $address = $form_data->getZip();

        $state = empty($form_data->getLegalState()) ? ResourceNavigatorUtilityBase::GetStateByZip($address)['abbr'] : $form_data->getLegalState();

        $rtn        = [];
        $my_regions = get_option('referral_regions_regions');
        foreach ($the_post['meta_lists'] as $id => $repeater) {
            if (strpos($id, 'referral-options-') !== false && $id != '') {
                foreach ($repeater as $item) {
                    $failed = false;
                    //everything but the default
                    if ($id != 'referral-options-0') {
                        //Check condition match
                        if ( ! empty($item['condition_1'])) {
                            if (strpos($item['condition_1'], 'extra_field_') !== false) {
                                $notes = $form_data->getNotes();

                                preg_match("/<p class='addtl-field-response' data-field='" . $item['condition_1'] . "'>(.*?)<\/p>/is", $notes, $matches);
                                if (isset($matches[1])) {
                                    $value = trim(strip_tags($matches[1]));
                                    if ($value != $item['condition_1_answer']) {
                                        $failed = true;
                                    }
                                } else {
                                    $failed = true;
                                }
                            } else {
                                if($item['condition_1'] == "raceId"){
                                    $answers = explode(',', $item['condition_1_answer']);
                                    $failed = true;
                                    foreach ($answers as $answer){

                                        $the_condition = 'isRaceId' . $answer;
                                        if ($form_data->$the_condition() == true) {
                                            $failed = false;
                                        }
                                    }
                                } else {
                                    $the_condition = 'get' . ucfirst($item['condition_1']);

                                    if ($form_data->$the_condition() != $item['condition_1_answer']) {
                                        $failed = true;
                                    }
                                }
                            }

                            if ( ! empty($item['condition_2'])) {
                                if (strpos($item['condition_2'], 'extra_field_') !== false) {
                                    $notes = $form_data->getNotes();

                                    preg_match("/<p class='addtl-field-response' data-field='" . $item['condition_2'] . "'>(.*?)<\/p>/is", $notes, $matches);
                                    if (isset($matches[1])) {
                                        $value = trim(strip_tags($matches[1]));
                                        if ($value != $item['condition_2_answer']) {
                                            $failed = true;
                                        }
                                    } else {
                                        $failed = true;
                                    }
                                } else {
                                    if($item['condition_2'] == "raceId"){
                                        $answers = explode(',', $item['condition_2_answer']);
                                        $failed = true;
                                        foreach ($answers as $answer){

                                            $the_condition = 'isRaceId' . $answer;
                                            if ($form_data->$the_condition() == true) {
                                                $failed = false;
                                            }
                                        }
                                    } else {
                                        $the_condition = 'get' . ucfirst($item['condition_2']);
                                        if ($form_data->$the_condition() != $item['condition_2_answer']) {
                                            $failed = true;
                                        }
                                    }
                                }

                            }
                        }

                        //Check region match
                        $region_index = (intval(str_replace('referral-options-', '', $id)) - 1);
                        if ($region_index != -1) {
                            if ($my_regions[$region_index]['type'] == 'state' && $my_regions[$region_index]['state'] != $state) {
                                $failed = true;
                            } elseif ($my_regions[$region_index]['type'] == 'zip') {
                                if (strpos($my_regions[$region_index]['zip'], $address) === false) {
                                    $failed = true;
                                }
                            }
                        }
                    } else {
                        $failed = true;
                    }
                    if ($failed) {
                        continue;
                    }

                    $rtn[] = $item;
                }
            }
        }
        //the default only if there are no other responses
        if(empty($rtn)){
            foreach ($the_post['meta_lists']['referral-options-0'] as $item) {
                $failed = false;

                //Check condition match
                if ( ! empty($item['condition_1'])) {
                    if (strpos($item['condition_1'], 'extra_field_') !== false) {
                        $notes = $form_data->getNotes();

                        preg_match("/<p class='addtl-field-response' data-field='" . $item['condition_1'] . "'>(.*?)<\/p>/is", $notes, $matches);
                        if (isset($matches[1])) {
                            $value = trim(strip_tags($matches[1]));
                            if ($value != $item['condition_1_answer']) {
                                $failed = true;
                            }
                        } else {
                            $failed = true;
                        }
                    } else {
                        $the_condition = 'get' . ucfirst($item['condition_1']);

                        if ($form_data->$the_condition() != $item['condition_1_answer']) {
                            $failed = true;
                        }
                    }

                    if ( ! empty($item['condition_2'])) {
                        if (strpos($item['condition_2'], 'extra_field_') !== false) {
                            $notes = $form_data->getNotes();

                            preg_match("/<p class='addtl-field-response' data-field='" . $item['condition_2'] . "'>(.*?)<\/p>/is", $notes, $matches);
                            if (isset($matches[1])) {
                                $value = trim(strip_tags($matches[1]));
                                if ($value != $item['condition_2_answer']) {
                                    $failed = true;
                                }
                            } else {
                                $failed = true;
                            }
                        } else {
                            $the_condition = 'get' . ucfirst($item['condition_2']);
                            if ($form_data->$the_condition() != $item['condition_2_answer']) {
                                $failed = true;
                            }
                        }

                    }
                }

                if ($failed) {
                    continue;
                }

                $rtn[] = $item;
            }
        }
        return $rtn;
    }

    public static function geocode($address): ?array
    {
        // url encode the address
        if (empty($address)) {
            return null;
        }
        $address = urlencode($address);

        // google map geocode api url
        $url = "https://geocode.search.hereapi.com/v1/geocode?q={$address}&apiKey=eLh0_mTxyY02tVoM1RAvBjiYeRuCu3-tdoTLb1w92M0";

        // get the json response
        $resp_json = file_get_contents($url);

        // decode the json
        $resp = json_decode($resp_json, true);

        return $resp;
        // response status will be 'OK', if able to geocode given address
    }

    public static function ValidateGoogleRecaptcha($res)
    {
        $url             = 'https://www.google.com/recaptcha/api/siteverify';
        $data            = array(
            'secret'   => get_option('slrn_grc_api_key_2'),
            'response' => $res
        );
        $query           = http_build_query($data);
        $options         = array(
            'http' => array(
                'header'  => "Content-Type: application/x-www-form-urlencoded\r\n" . "Content-Length: " . strlen($query) . "\r\n" . "User-Agent:MyAgent/1.0\r\n",
                'method'  => 'POST',
                'content' => $query
            )
        );
        $context         = stream_context_create($options);
        $verify          = file_get_contents($url, false, $context);
        $captcha_success = json_decode($verify);

        return $captcha_success->success;
    }


}